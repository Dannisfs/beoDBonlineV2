#include "stdafx.h"

#include "NaviSourceObjectProcess.h"

#include "NtlCamera.h"
#include "NaviProject.h"


CNaviSourceObjectProcess::CNaviSourceObjectProcess( CWnd* pWnd )
: CNaviRenderingProcess( eNAVI_PROCESS_ID_SOURCE_OBJECT_PROCESS, pWnd )
{
}


CNaviSourceObjectProcess::~CNaviSourceObjectProcess( void )
{
	Delete();
}


bool CNaviSourceObjectProcess::Create( void )
{
	if ( !CNaviRenderingProcess::Create() )
	{
		return false;
	}

	RwD3D9CameraAttachWindow( m_pCamera->GetCamera(), m_pWnd->GetSafeHwnd() );
}


void CNaviSourceObjectProcess::Delete( void )
{
	CNaviRenderingProcess::Delete();
}


LRESULT CNaviSourceObjectProcess::WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{
	return CNaviRenderingProcess::WindowProc( hWnd, uiMsg, wParam, lParam );
}


void CNaviSourceObjectProcess::OnDeviceRestore( void )
{
	CNaviRenderingProcess::OnDeviceRestore();
}


void CNaviSourceObjectProcess::OnDeviceRelease( void )
{
	CNaviRenderingProcess::OnDeviceRelease();
}


void CNaviSourceObjectProcess::OnUpdate( float fTime, float fElapsedTime )
{
	CNaviRenderingProcess::OnUpdate( fTime, fElapsedTime );

	if ( CNaviProject::GetInstance()->m_pWorld )
	{
		RwRGBA BkColor;
		BkColor.red = 0; BkColor.green = 0; BkColor.blue  = 0; BkColor.alpha = 255;

		m_pCamera->CameraClear( &BkColor, rwCAMERACLEARZ|rwCAMERACLEARIMAGE );

		if ( RwCameraBeginUpdate( m_pCamera->GetCamera() ) )
		{
			CNaviProject::GetInstance()->m_pWorld->Update( fTime, fElapsedTime );
			CNaviProject::GetInstance()->m_pWorld->Render( m_pCamera->GetCamera(), NULL );

			RwCameraEndUpdate( m_pCamera->GetCamera() );
		}

		RwCameraShowRaster( m_pCamera->GetCamera(), m_pWnd->GetSafeHwnd(), 0 );
	}
}
