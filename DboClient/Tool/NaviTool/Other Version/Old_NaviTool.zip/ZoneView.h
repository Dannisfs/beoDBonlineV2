#pragma once


// CZoneView ��ũ�� �������Դϴ�

#include "ximage.h"


//////////////////////////////////////////////////////////////////////////
//
//	X, Z ��ǥ��
//
//				z(+)
//		.(End)	|
//				|
//				|
//	 x(+) ----------------
//				|
//				|	.(Begin)
//				|
//
//////////////////////////////////////////////////////////////////////////


typedef std::map<DWORD, CRect> mapdef_FieldList;

class CZoneAttr
{
public:
	struct SBitmap
	{
		CString strName;
		CxImage* pImpage;

		SBitmap( void ) { pImpage = NULL; }
		~SBitmap( void ) { if ( pImpage ) delete pImpage; }
	};

protected:
	// ������ ����
	static const float s_fDefaultWorldSize;
	static const float s_fFieldSize;
	static const int s_nPixelPerGrid;

	// �⺻ �Է� ����
	float m_fBeginX, m_fBeginZ;
	float m_fEndX, m_fEndZ;
	mapdef_FieldList m_defFieldList;
	CString m_strMinimapName;

	// �Է� ������ �������� ���Ǵ� ����
	int m_nGridCntX, m_nGridCntZ;
	CSize m_TotoalSize;
	SBitmap* m_pMiniMap;

public:
	CZoneAttr( void )
	{
		m_fBeginX = 0.f;
		m_fBeginZ = 0.f;

		m_fEndX = s_fFieldSize * s_fDefaultWorldSize;
		m_fEndZ = s_fFieldSize * s_fDefaultWorldSize;

		m_pMiniMap = NULL;

		Update();
	}

	CZoneAttr( const CZoneAttr& clVal )
	{
		m_fBeginX = clVal.m_fBeginX;
		m_fBeginZ = clVal.m_fBeginZ;

		m_fEndX = clVal.m_fEndX;
		m_fEndZ = clVal.m_fEndZ;

		m_defFieldList = clVal.m_defFieldList;

		m_strMinimapName = clVal.m_strMinimapName;

		m_pMiniMap = NULL;

		Update();
	}

	~CZoneAttr( void )
	{
		if ( m_pMiniMap )
		{
			delete m_pMiniMap;
		}
	}

	void Clear( void )
	{
		m_fBeginX = 0.f;
		m_fBeginZ = 0.f;

		m_fEndX = s_fFieldSize * s_fDefaultWorldSize;
		m_fEndZ = s_fFieldSize * s_fDefaultWorldSize;

		m_defFieldList.clear();
		m_strMinimapName.Empty();

		Update();
	}

	void operator = ( const CZoneAttr& clVal )
	{
		m_fBeginX = clVal.m_fBeginX;
		m_fBeginZ = clVal.m_fBeginZ;

		m_fEndX = clVal.m_fEndX;
		m_fEndZ = clVal.m_fEndZ;

		m_defFieldList = clVal.m_defFieldList;

		m_strMinimapName = clVal.m_strMinimapName;

		Update();
	}

	void Update( void )
	{
		float fCX = abs( m_fEndX - m_fBeginX );
		float fCY = abs( m_fEndZ - m_fBeginZ );

		m_nGridCntX = (int)(fCX / s_fFieldSize + 1.f);
		m_nGridCntZ = (int)(fCY / s_fFieldSize + 1.f);

		m_TotoalSize.cx = (m_nGridCntX - 1) * s_nPixelPerGrid;
		m_TotoalSize.cx = m_TotoalSize.cx < 0 ? 0 : m_TotoalSize.cx;
		m_TotoalSize.cy = (m_nGridCntZ - 1) * s_nPixelPerGrid;
		m_TotoalSize.cy = m_TotoalSize.cy < 0 ? 0 : m_TotoalSize.cy;

		if ( m_strMinimapName.IsEmpty() )
		{
			if ( m_pMiniMap )
			{
				delete m_pMiniMap;
				m_pMiniMap = NULL;
			}
		}
		else
		{
			if ( NULL == m_pMiniMap )
			{
				m_pMiniMap = new SBitmap;
			}

			if ( m_pMiniMap->strName != m_strMinimapName )
			{
				// ���� ��Ʈ�� ����
				if ( m_pMiniMap->pImpage )
				{
					delete m_pMiniMap->pImpage;
					m_pMiniMap->pImpage = NULL;
				}

				// ���ο� ��Ʈ�� ����
				m_pMiniMap->pImpage = new CxImage;
				if ( !m_pMiniMap->pImpage->Load( m_strMinimapName ) )
				{
					CString strMsg; strMsg.Format( "[%s] �׸����� ���� ����", m_strMinimapName );
					AfxMessageBox( strMsg );

					m_strMinimapName.Empty();

					delete m_pMiniMap;
					m_pMiniMap = NULL;
				}
				else
				{
					m_pMiniMap->strName = m_strMinimapName;
				}
			}
		}
	}

	friend class CZoneView;
};


class CZoneView : public CScrollView
{
	DECLARE_DYNCREATE(CZoneView)

protected:
	CZoneAttr m_ZoneAttr;

public:
	CZoneView();
	virtual ~CZoneView();

public:
	void SetWorldRegion( float fBeginX, float fBeginZ, float fEndX, float fEndZ );

	void SetMinimap( const CString& strMinimapName );

	BOOL HasField( DWORD dwFieldID );
	void AddField( DWORD dwFieldID );
	void RemoveField( DWORD dwFieldID );

	void ClearAllZoneAttr( void );

	void UpdateZoneView( void );

protected:
	CRect GetGridRgnFromFieldId( DWORD dwFieldID );
	DWORD GetFieldIdFromGridIndex( int nX, int nZ );
	CPoint GetGridIndexFromGridRgn( const CPoint& ptPos );

#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

public:
	virtual void OnDraw(CDC* pDC);      // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual void OnInitialUpdate();     // ������ �� ó���Դϴ�.

	DECLARE_MESSAGE_MAP()
};


