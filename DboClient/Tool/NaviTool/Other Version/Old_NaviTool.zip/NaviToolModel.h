#ifndef _NAVI_TOOL_MODEL_H_
#define _NAVI_TOOL_MODEL_H_


#include "NaviToolObject.h"


class CNaviToolWorldProperty;


class CNaviToolModel : public CNaviToolObject
{

// Declarations
public:
	struct sModelAtomic
	{
		RwMatrix							m_matLocal;
		unsigned int						m_uiVertexCnt;
		RwIm3DVertex*						m_pVertexList;
		unsigned int						m_uiIndexCnt;
		RwImVertexIndex*					m_pIndexList;
	};
	typedef std::map< unsigned int, sModelAtomic* > mapdef_ModelAtomicList;


// Member variables
protected:
	// Attributes
	CNaviToolWorldProperty*				m_pWorldProperty;
	CString								m_strModelName;
	unsigned int						m_uiModelProperty;

	// Updated values
	unsigned int						m_uiModelAtomicID;
	mapdef_ModelAtomicList				m_defModelAtomicList;


// Constructions and Destructions
protected:
	CNaviToolModel( void );
	virtual ~CNaviToolModel( void );


// Operations
public:
	CNaviToolWorldProperty*				GetWorldProperty( void );
	void								SetWorldProperty( CNaviToolWorldProperty* pWorldProperty );

	const CString&						GetModelName( void ) const;
	void								SetModelName( const CString& strModelName );

	unsigned int						GetModelProperty( void ) const;
	void								SetModelProperty( unsigned int uiModelProperty );

	unsigned int						GetModelAtomicCount( void ) const;
	sModelAtomic*						GetModelAtomic( unsigned int uiModelAtomicID );
	unsigned int						CreateModelAtomic( unsigned int uiVertexCnt, unsigned int uiIndexCnt, const RwMatrix& matLocal );
	void								DeleleteModelAtomic( unsigned int uiModelAtomicID );
	void								DeleteAllModelAtomics( void );

	unsigned int						GetVertexCount( unsigned int uiModelAtomicID );
	const RwIm3DVertex*					GetVertex( unsigned int uiModelAtomicID, RwImVertexIndex VertIdx );
	void								SetVertex( unsigned int uiModelAtomicID, RwImVertexIndex VertIdx, const RwIm3DVertex& Vertex );

	unsigned int						GetIndexCount( unsigned int uiModelAtomicID );
	const RwImVertexIndex*				GetIndex( unsigned int uiModelAtomicID, unsigned int uiIndexIdx );
	void								SetIndex( unsigned int uiModelAtomicID, unsigned int uiIndexIdx, const RwImVertexIndex& Index );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );
	virtual void						Render( RwCamera* pCamera, const RwMatrix* pParentMatrix );


	friend class CNaviToolObjectFactory;

};


inline CNaviToolWorldProperty* CNaviToolModel::GetWorldProperty( void )
{
	return m_pWorldProperty;
}


inline void CNaviToolModel::SetWorldProperty( CNaviToolWorldProperty* pWorldProperty )
{
	m_pWorldProperty = pWorldProperty;
}


inline const CString& CNaviToolModel::GetModelName( void ) const
{
	return m_strModelName;
}


inline void CNaviToolModel::SetModelName( const CString& strModelName )
{
	m_strModelName = strModelName;
}


inline unsigned int CNaviToolModel::GetModelProperty( void ) const
{
	return m_uiModelProperty;
}


inline void CNaviToolModel::SetModelProperty( unsigned int uiModelProperty )
{
	m_uiModelProperty = uiModelProperty;
}


inline unsigned int CNaviToolModel::GetModelAtomicCount( void ) const
{
	return (unsigned int)m_defModelAtomicList.size();
}


inline unsigned int CNaviToolModel::GetVertexCount( unsigned int uiModelAtomicID )
{
	return m_defModelAtomicList[uiModelAtomicID]->m_uiVertexCnt;
}


inline const RwIm3DVertex* CNaviToolModel::GetVertex( unsigned int uiModelAtomicID, RwImVertexIndex VertIdx )
{
	if ( (unsigned int)VertIdx >= m_defModelAtomicList[uiModelAtomicID]->m_uiVertexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s, %d, %d] �ε����� ���ؽ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_strModelName, m_defModelAtomicList[uiModelAtomicID]->m_uiVertexCnt, VertIdx );
		return NULL;
	}

	return &m_defModelAtomicList[uiModelAtomicID]->m_pVertexList[VertIdx];
}


inline void CNaviToolModel::SetVertex( unsigned int uiModelAtomicID, RwImVertexIndex VertIdx, const RwIm3DVertex& Vertex )
{
	if ( (unsigned int)VertIdx >= m_defModelAtomicList[uiModelAtomicID]->m_uiVertexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s, %d, %d] �ε����� ���ؽ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_strModelName, m_defModelAtomicList[uiModelAtomicID]->m_uiVertexCnt, VertIdx );
		return;
	}

	m_defModelAtomicList[uiModelAtomicID]->m_pVertexList[VertIdx] = Vertex;
}


inline unsigned int CNaviToolModel::GetIndexCount( unsigned int uiModelAtomicID )
{
	return m_defModelAtomicList[uiModelAtomicID]->m_uiIndexCnt;
}


inline const RwImVertexIndex* CNaviToolModel::GetIndex( unsigned int uiModelAtomicID, unsigned int uiIndexIdx )
{
	if ( (unsigned int)uiIndexIdx >= m_defModelAtomicList[uiModelAtomicID]->m_uiIndexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s, %d, %d] �ε����� ���ؽ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_strModelName, m_defModelAtomicList[uiModelAtomicID]->m_uiIndexCnt, uiIndexIdx );
		return NULL;
	}

	return &m_defModelAtomicList[uiModelAtomicID]->m_pIndexList[uiIndexIdx];
}


inline void CNaviToolModel::SetIndex( unsigned int uiModelAtomicID, unsigned int uiIndexIdx, const RwImVertexIndex& Index )
{
	if ( (unsigned int)uiIndexIdx >= m_defModelAtomicList[uiModelAtomicID]->m_uiIndexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s, %d, %d] �ε����� ���ؽ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_strModelName, m_defModelAtomicList[uiModelAtomicID]->m_uiIndexCnt, uiIndexIdx );
		return;
	}

	m_defModelAtomicList[uiModelAtomicID]->m_pIndexList[uiIndexIdx] = Index;
}


#endif