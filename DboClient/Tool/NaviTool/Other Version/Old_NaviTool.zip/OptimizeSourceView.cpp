// OptimizeSourceView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "OptimizeSourceView.h"

#include "NaviSourceObjectProcess.h"


// COptimizeSourceView

IMPLEMENT_DYNCREATE(COptimizeSourceView, CView)

COptimizeSourceView::COptimizeSourceView()
{
	m_pProcess = new CNaviSourceObjectProcess( this );
}

COptimizeSourceView::~COptimizeSourceView()
{
	if ( m_pProcess )
	{
		delete m_pProcess;
		m_pProcess = NULL;
	}
}

BEGIN_MESSAGE_MAP(COptimizeSourceView, CView)
END_MESSAGE_MAP()


// COptimizeSourceView �׸����Դϴ�.

void COptimizeSourceView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.
}


// COptimizeSourceView �����Դϴ�.

#ifdef _DEBUG
void COptimizeSourceView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void COptimizeSourceView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// COptimizeSourceView �޽��� ó�����Դϴ�.
void COptimizeSourceView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	m_pProcess->Create();
}

BOOL COptimizeSourceView::PreTranslateMessage(MSG* pMsg)
{
	if ( m_pProcess )
	{
		m_pProcess->WindowProc( pMsg->hwnd, pMsg->message, pMsg->wParam, pMsg->lParam );
	}

	return CView::PreTranslateMessage(pMsg);
}
