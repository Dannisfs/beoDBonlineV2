#ifndef _NAVI_TOOL_WORLD_H_
#define _NAVI_TOOL_WORLD_H_


#include "NaviToolObject.h"


class CNaviToolWorldProperty;


class CNaviToolWorld : public CNaviToolObject
{

// Member variables
protected:
	// Attributes
	CNaviToolWorldProperty*				m_pWorldProperty;
	unsigned int						m_uiWorldTblIdx;


// Constructions and Destructions
protected:
	CNaviToolWorld( void );
	virtual ~CNaviToolWorld( void );


// Operations
public:
	CNaviToolWorldProperty*				GetWorldProperty( void );
	void								SetWorldProperty( CNaviToolWorldProperty* pWorldProperty );

	unsigned int						GetWorldTblIdx( void ) const;
	void								SetWorldTblIdx( unsigned int uiWorldTblIdx );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );


	friend class CNaviToolObjectFactory;

};


inline CNaviToolWorldProperty* CNaviToolWorld::GetWorldProperty( void )
{
	return m_pWorldProperty;
}


inline void CNaviToolWorld::SetWorldProperty( CNaviToolWorldProperty* pWorldProperty )
{
	m_pWorldProperty = pWorldProperty;
}


inline unsigned int CNaviToolWorld::GetWorldTblIdx( void ) const
{
	return m_uiWorldTblIdx;
}


inline void CNaviToolWorld::SetWorldTblIdx( unsigned int uiWorldTblIdx )
{
	m_uiWorldTblIdx = uiWorldTblIdx;
}


#endif