#include "stdafx.h"
#include "NaviPathEngine.h"

#include "NaviToolDefine.h"

#include "NaviToolZone.h"


//////////////////////////////////////////////////////////////////////////
class CZoneMesh : public iFaceVertexMesh
{
protected:
	CNaviToolZone* pZone;
	int nVertexCnt;
	int nIndexCnt;

public:
	CZoneMesh( CNaviToolZone* pZone ) : pZone( pZone ) { Build(); }

public:
	void Build( void )
	{
		nVertexCnt = pZone->GetVertexCount();
		nIndexCnt = pZone->GetIndexCount();
	}

public:
	virtual tSigned32 faces() const
	{
		return nIndexCnt / 3;
	}

	virtual tSigned32 vertices() const
	{
		return nVertexCnt;
	}

	virtual tSigned32 vertexIndex(tSigned32 face, tSigned32 vertexInFace) const
	{
		return (tSigned32)pZone->GetIndex( face * 3 + vertexInFace );
	}

	virtual tSigned32 vertexX(tSigned32 vertex) const
	{
		const RwIm3DVertex* pVert = pZone->GetVertex( (unsigned short)vertex );
		return (int) (pVert->objVertex.x * 100.f);
	}

	virtual tSigned32 vertexY(tSigned32 vertex) const
	{
		const RwIm3DVertex* pVert = pZone->GetVertex( (unsigned short)vertex );
		return (int) (pVert->objVertex.z * 100.f);
	}

	virtual float vertexZ(tSigned32 vertex) const
	{
		const RwIm3DVertex* pVert = pZone->GetVertex( (unsigned short)vertex );
		return pVert->objVertex.y;
	}

	virtual tSigned32 faceAttribute(tSigned32 face, tSigned32 attributeIndex) const
	{
		return 0;
	}
};


class CProgressCallBack : public iProgressCallBack
{
public:
	virtual void updateProgress(const char* operationDescription, float percent)
	{
		static char buf[50];
		static int npercent = 0;

		if ( npercent != (int)percent )
		{
			npercent = (int)percent;

			sprintf( buf, "%f\n", percent );
			OutputDebugString( buf );
		}
	}
};


//////////////////////////////////////////////////////////////////////////


CNaviPathEngine CNaviPathEngine::s_clEngine;


CNaviPathEngine* CNaviPathEngine::GetInstance( void )
{
	return &s_clEngine;
}


CNaviPathEngine::CNaviPathEngine( void )
{
	m_hInstance = NULL;
	m_pPE = NULL;
	m_pCP3D = NULL;
}


CNaviPathEngine::~CNaviPathEngine( void )
{
	Delete();
}


bool CNaviPathEngine::Create( void )
{
	CString strLibraryName;

	strLibraryName = NAVI_TOOL_PATH_ENGINE_WORKIGN_FOLDER;
	strLibraryName += NAVI_TOOL_3D_CONTENT_NAME;

	if ( !LoadLibrary( strLibraryName,
					   &m_hInstance,
					   &m_pPE,
					   &m_pCP3D ) )
	{
		return false;
	}

	return true;
}


void CNaviPathEngine::Delete( void )
{
	if ( m_pCP3D )
	{
		m_pCP3D = NULL;
	}

	if ( m_pPE )
	{
		m_pPE = NULL;
	}

	if ( m_hInstance )
	{
		FreeLibrary( m_hInstance );
		m_hInstance = NULL;
	}
}


bool CNaviPathEngine::LoadLibrary( const CString& strLoadDllName,
								   HINSTANCE* pInst,
								   iPathEngine** ppPE,
								   iContentProcessing3D** ppCP3D )
{
	typedef iContentProcessing3D* ( __stdcall* tGetInterfaceFunction )( iErrorHandler* );

	*pInst = ::LoadLibrary( strLoadDllName );

	if ( !*pInst )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] ���̺귯�� �ε� ����", __FILE__, __FUNCTION__, __LINE__, strLoadDllName );
		return false;
	}

	FARPROC procAddress = GetProcAddress( *pInst, (LPCSTR)1 );

	if ( !procAddress )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �ش� ���̺귯������ Entry-point ã�� ����", __FILE__, __FUNCTION__, __LINE__, strLoadDllName );
		return false;
	}

	tGetInterfaceFunction getInterfaceFunction = (tGetInterfaceFunction)procAddress;

	*ppCP3D = getInterfaceFunction( &m_clErrorHandler );

	*ppPE = (*ppCP3D)->getPathEngine();

	return true;
}
