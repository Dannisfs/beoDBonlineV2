#include "stdafx.h"

#include "NaviOptimizedObjectProcess.h"

#include "NtlCamera.h"
#include "NaviProject.h"


CNaviOptimizedObjectProcess::CNaviOptimizedObjectProcess( CWnd* pWnd )
: CNaviRenderingProcess( eNAVI_PROCESS_ID_OPTIMIZED_OBJECT_PROCESS, pWnd )
{
}


CNaviOptimizedObjectProcess::~CNaviOptimizedObjectProcess( void )
{
	Delete();
}


bool CNaviOptimizedObjectProcess::Create( void )
{
	if ( !CNaviRenderingProcess::Create() )
	{
		return false;
	}

	RwD3D9CameraAttachWindow( m_pCamera->GetCamera(), m_pWnd->GetSafeHwnd() );
}


void CNaviOptimizedObjectProcess::Delete( void )
{
	CNaviRenderingProcess::Delete();
}


LRESULT CNaviOptimizedObjectProcess::WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{
	return CNaviRenderingProcess::WindowProc( hWnd, uiMsg, wParam, lParam );
}


void CNaviOptimizedObjectProcess::OnDeviceRestore( void )
{
	CNaviRenderingProcess::OnDeviceRestore();
}


void CNaviOptimizedObjectProcess::OnDeviceRelease( void )
{
	CNaviRenderingProcess::OnDeviceRelease();
}


void CNaviOptimizedObjectProcess::OnUpdate( float fTime, float fElapsedTime )
{
	CNaviRenderingProcess::OnUpdate( fTime, fElapsedTime );

	if ( CNaviProject::GetInstance()->m_pWorld )
	{
		RwRGBA BkColor;
		BkColor.red = 0; BkColor.green = 0; BkColor.blue  = 0; BkColor.alpha = 255;

		m_pCamera->CameraClear( &BkColor, rwCAMERACLEARZ|rwCAMERACLEARIMAGE );

		if ( RwCameraBeginUpdate( m_pCamera->GetCamera() ) )
		{
			CNaviProject::GetInstance()->m_pWorld->Update( fTime, fElapsedTime );
			CNaviProject::GetInstance()->m_pWorld->Render( m_pCamera->GetCamera(), NULL );

			RwCameraEndUpdate( m_pCamera->GetCamera() );
		}

		RwCameraShowRaster( m_pCamera->GetCamera(), m_pWnd->GetSafeHwnd(), 0 );
	}
}
