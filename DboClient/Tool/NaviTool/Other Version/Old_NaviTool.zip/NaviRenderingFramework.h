#ifndef _NAVI_RENDERINGFRAMEWORK_H_
#define _NAVI_RENDERINGFRAMEWORK_H_


#include "NtlDeviceRestoreHandler.h"
#include "NtlApplication.h"
#include "NaviToolDefine.h"


class CNaviRenderingProcess;


class CNaviRenderingFramework : public CNtlApplication
{

// Declarations
public:
	typedef std::map< eNAVI_PROCESS_ID, CNaviRenderingProcess* > mapdef_ProcessList;
	typedef std::map< eNAVI_PROCESS_ID, CNaviRenderingProcess* >::iterator mapdef_ProcessListIT;


// Static
protected:
	static CNaviRenderingFramework		s_clFrameWork;


public:
	static CNaviRenderingFramework*		GetInstance( void );


// Member variables
protected:

	// Device ���� ������
	DEVICE_RESTORE_HANDLE				m_hRestore;
	DEVICE_RESTORE_HANDLE				m_hRelease;

	// Process list
	mapdef_ProcessList					m_defProcessList;


// Constructions and Destructions
public:

	CNaviRenderingFramework( void );
	virtual ~CNaviRenderingFramework( void );


// Operations
public:

	bool								CreateRenderingSystem( HWND hWnd );
	void								DeleteRenderingSystem( void );
	void								UpdateRenderingSystem( void );

	CNaviRenderingProcess*				FindProcess( eNAVI_PROCESS_ID eID );
	mapdef_ProcessListIT				BeginProcess( void );
	mapdef_ProcessListIT				EndProcess( void );
	void								AttachProcessList( eNAVI_PROCESS_ID eID, CNaviRenderingProcess* pProcess );
	void								DetachProcessList( eNAVI_PROCESS_ID eID );

	int									OnDeviceRestore( void );
	int									OnDeviceRelease( void );
	void								OnUpdate( float fTime, float fElapsedTime );


// Implementations
protected:

	// DBO project ���� ���� �Լ���
	virtual RwBool						AttachPlugin( void );
	virtual RwBool						Update( RwReal fTime, RwReal fElapsedTime );
};


inline CNaviRenderingFramework::mapdef_ProcessListIT CNaviRenderingFramework::BeginProcess( void )
{
	return m_defProcessList.begin();
}


inline CNaviRenderingFramework::mapdef_ProcessListIT CNaviRenderingFramework::EndProcess( void )
{
	return m_defProcessList.end();
}

#endif