#include "stdafx.h"
#include "NaviToolStatic.h"


char g_szWorkingFolder[4096] = { 0, };
