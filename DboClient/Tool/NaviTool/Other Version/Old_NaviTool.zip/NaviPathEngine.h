#ifndef _NAVI_PATHENGINE_H_
#define _NAVI_PATHENGINE_H_


#include "i_pathengine.h"
#include "i_contentprocessing3d.h"


class CNaviPathEngine
{

// Declarations
public:
	class CNaviPathEngineErrorHandler : public iErrorHandler
	{
	public:
		virtual eAction handle( const char* error_type, const char* error_string, const char* const* attributes )
		{
			CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s, %s] Path engine", __FILE__, __FUNCTION__, __LINE__, error_type, error_string );
			return CONTINUE;
		}
	};


// Static
protected:
	static CNaviPathEngine				s_clEngine;


public:
	static CNaviPathEngine*				GetInstance( void );


// Member variables
protected:
	CNaviPathEngineErrorHandler			m_clErrorHandler;

	HINSTANCE							m_hInstance;
	iPathEngine*						m_pPE;
	iContentProcessing3D*				m_pCP3D;


// Constructions and Destructions
public:
	CNaviPathEngine( void );
	~CNaviPathEngine( void );


// Operations
public:
	bool								Create( void );
	void								Delete( void );


// Implementations
protected:
	bool								LoadLibrary( const CString& strLoadDllName,
													 HINSTANCE* pInst,
													 iPathEngine** ppPE,
													 iContentProcessing3D** ppCP3D );

};


#endif