#include "stdafx.h"
#include "NaviToolObjectFactory.h"


CNaviToolObjectFactory::CNaviToolObjectFactory( void )
{
}


CNaviToolObjectFactory::~CNaviToolObjectFactory( void )
{
	DeleteAllObjects();
	DeleteAllModels();
}


CNaviToolObject* CNaviToolObjectFactory::FindObject( const char* pID )
{
	mapdef_ObjectList::iterator it = m_defObjList.find( pID );
	if ( it != m_defObjList.end() ) return it->second;
	return NULL;
}


void CNaviToolObjectFactory::DeleteObject( const char* pID )
{
	mapdef_ObjectList::iterator it = m_defObjList.find( pID );
	if ( it != m_defObjList.end() )
	{
		CNaviToolObject* pObj = it->second;

		if ( pObj->ReleaseRef() <= 0 )
		{
			m_defObjList.erase( it );

			delete pObj;
		}
	}
}


void CNaviToolObjectFactory::DeleteAllObjects( void )
{
	mapdef_ObjectList::iterator it = m_defObjList.begin();
	for ( ; it != m_defObjList.end(); ++it )
	{
		delete it->second;
	}
	m_defObjList.clear();
}


CNaviToolModel* CNaviToolObjectFactory::FindModel( const char* pModelName )
{
	mapdef_ModelList::iterator it = m_defModelList.find( pModelName );
	if ( it != m_defModelList.end() ) return it->second;
	return NULL;
}


CNaviToolModel* CNaviToolObjectFactory::CreateModel( const char* pModelName )
{
	if ( NULL == pModelName )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %d] NULL �̸��� ���� ���� ������ �� �����ϴ�", __FILE__, __FUNCTION__, __LINE__ );
		return NULL;
	}

	CNaviToolModel* pModel = FindModel( pModelName );

	if ( pModel )
	{
		pModel->AddRef();
	}
	else
	{
		pModel = new CNaviToolModel;

		pModel->SetID( pModel->GenerateID() );
		CString strID = pModel->IDToString( pModel->GetID() );

		pModel->AddRef();

		m_defModelList[pModelName] = pModel;
	}

	return pModel;
}


void CNaviToolObjectFactory::DeleteModel( const char* pModelName )
{
	mapdef_ModelList::iterator it = m_defModelList.find( pModelName );
	if ( it != m_defModelList.end() )
	{
		CNaviToolModel* pModel = it->second;

		if ( pModel->ReleaseRef() <= 0 )
		{
			m_defModelList.erase( it );
			delete pModel;
		}
	}
}


void CNaviToolObjectFactory::DeleteAllModels( void )
{
	mapdef_ModelList::iterator it = m_defModelList.begin();
	for ( ; it != m_defModelList.end(); ++it )
	{
		delete it->second;
	}
	m_defModelList.clear();
}


