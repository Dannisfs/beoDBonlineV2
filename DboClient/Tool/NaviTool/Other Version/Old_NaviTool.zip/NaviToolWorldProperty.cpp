#include "stdafx.h"
#include "NaviToolWorldProperty.h"


CNaviToolWorldProperty::CNaviToolWorldProperty( void )
{
	m_uiWorldTblIdx = 0xffffffff;

	m_v3WorldBegin.x = m_v3WorldBegin.y = m_v3WorldBegin.z = FLT_MAX;
	m_v3WorldEnd.x = m_v3WorldEnd.y = m_v3WorldEnd.z = -FLT_MAX;

	m_uiFieldCnt = 0;
	m_fFieldSize = 256.f;

	m_uiTileCnt = 0;
	m_fTileSize = 4.f;

	m_pFieldProperty = NULL;
	m_pTileProperty = NULL;
}


CNaviToolWorldProperty::~CNaviToolWorldProperty( void )
{
	Delete();
}


bool CNaviToolWorldProperty::Create( CNaviToolAttrs* pAttrs )
{
	if ( m_bCreated ) return true;

	CNaviToolAttrs_WorldProperty* pWorldPropAttr = dynamic_cast< CNaviToolAttrs_WorldProperty* > ( pAttrs );
	if ( NULL == pWorldPropAttr )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �߸��� �Ӽ� ������ �ԷµǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pAttrs ? typeid(pAttrs).name() : "NULL") );
		return false;
	}

	m_uiWorldTblIdx = pWorldPropAttr->uiWorldTblIdx;
	m_v3WorldBegin = pWorldPropAttr->v3WorldBegin;
	m_v3WorldEnd = pWorldPropAttr->v3WorldEnd;
	m_uiFieldCnt = pWorldPropAttr->uiFieldCnt;
	m_fFieldSize = pWorldPropAttr->fFieldSize;
	m_uiTileCnt = pWorldPropAttr->uiTileCnt;
	m_fTileSize = pWorldPropAttr->fTileSize;

	m_pFieldProperty = new unsigned int[m_uiFieldCnt];
	if ( NULL == m_pFieldProperty )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d] New ����", __FILE__, __FUNCTION__, __LINE__, m_uiFieldCnt );
		return false;
	}

	m_pTileProperty = new unsigned int[m_uiTileCnt];
	if ( NULL == m_pTileProperty )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d] New ����", __FILE__, __FUNCTION__, __LINE__, m_uiTileCnt );
		return false;
	}

	return CNaviToolObject::Create( pAttrs );
}


void CNaviToolWorldProperty::Delete( void )
{
	if ( m_pTileProperty )
	{
		delete [] m_pTileProperty;
		m_pTileProperty = NULL;
	}

	if ( m_pFieldProperty )
	{
		delete [] m_pFieldProperty;
		m_pFieldProperty = NULL;
	}

	m_fTileSize = 4.f;
	m_uiTileCnt = 0;

	m_fFieldSize = 256.f;
	m_uiFieldCnt = 0;

	m_v3WorldEnd.x = m_v3WorldEnd.y = m_v3WorldEnd.z = -FLT_MAX;
	m_v3WorldBegin.x = m_v3WorldBegin.y = m_v3WorldBegin.z = FLT_MAX;

	m_uiWorldTblIdx = 0xffffffff;

	CNaviToolObject::Delete();
}