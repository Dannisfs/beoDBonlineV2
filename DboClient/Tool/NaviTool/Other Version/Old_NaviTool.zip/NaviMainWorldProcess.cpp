#include "stdafx.h"

#include "NaviMainWorldProcess.h"

#include "NaviToolStatic.h"

#include "NaviRenderingFramework.h"

#include <direct.h>

#include "NtlClientNet.h"
#include "PCTable.h"
#include "WorldTable.h"
#include "MobTable.h"

#include "NtlAtomic.h"
#include "NtlPLMaterialExtWrapper.h"
#include "NtlDebug.h"
#include "NtlCharsetPrint.h"
#include "NtlText.h"
#include "NtlEventQueue.h"
#include "NtlCoreUtil.h"
#include "NtlCoreApi.h"

#include "gui_precomp.h"
#include "guicore_precomp.h"
#include "gui_componenttokenizer.h"

#include "NtlSoundManager.h"

#include "NtlPLSceneManagerFactory.h"
#include "NtlPLPropertyContainer.h"
#include "NtlPLGlobal.h"
#include "NtlPLApi.h"
#include "NtlPLGuiManager.h"
#include "NtlResourceEffect.h"
#include "NtlEffectSystemFreeList.h"
#include "guicore_precomp.h"
#include "gui_precomp.h"
#include "ntlworldinterface.h"
#include "ntlworldplugin.h"
#include "ntlplworldentity.h"
#include "NtlWorldMaterialPlugin.h"
#include "NtlPLSceneManager.h"
#include "NtlPostEffectCamera.h"
#include "NtlPLObject.h"
#include "NtlPLResourcePack.h"
#include "NtlDefaultItemData.h"

#include "NtlCameraManager.h"
#include "NtlSLApi.h"
#include "TableContainer.h"
#include "NtlSLEventFunc.h"
#include "NtlDTProp.h"
#include "NtlSobProxy.h"
#include "NtlSLLogic.h"
#include "NtlNetSender.h"


CNaviMainWorldProcess::CNaviMainWorldProcess( CWnd* pWnd )
: CNaviRenderingProcess( eNAVI_PROCESS_ID_MAIN_PROCESS, pWnd, true )
{
	m_pPLEventHandler = NULL;
	m_pPropContainter = NULL;
	m_pVisualManager = NULL;

	m_pWorldEntity = NULL;
}


CNaviMainWorldProcess::~CNaviMainWorldProcess( void )
{
	Delete();
}


bool CNaviMainWorldProcess::Create( void )
{
	CNaviRenderingProcess::Create();

	//////////////////////////////////////////////////////////////////////////
	// Camera �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	CNtlPLGlobal::SetActiveCamera( m_pCamera->GetCamera() ); 

	//////////////////////////////////////////////////////////////////////////
	// Event handler �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	m_pPLEventHandler = NTL_NEW CNtlPLEventHandler;
	if ( !m_pPLEventHandler->Create() )
	{
		ASSERT( !"Failed : m_pPLEventHandler->Create()" );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// Core layer �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	if ( !API_CoreInit() )
	{
		ASSERT( !"Failed : API_CoreInit()" );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// Presentation layer �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	API_PLInit();

	//////////////////////////////////////////////////////////////////////////
	// Property container �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	m_pPropContainter = NTL_NEW CNtlPLPropertyContainer;

	if ( !m_pPropContainter->Load() )
	{
		ASSERT( !"Failed : m_pPropContainter->Load()" );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// Visual manager �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	m_pVisualManager = NTL_NEW CNtlPLVisualManager;

	if ( !m_pVisualManager->Create() )
	{
		ASSERT( !"Failed : m_pVisualManager->Create()" );
		return FALSE;
	}

	CNtlPLSceneManagerFactory::ActiveSceneManager( m_pVisualManager );

	//////////////////////////////////////////////////////////////////////////
	// Simulation layer �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	if ( !API_SLInit( TRUE, m_pCamera, CTable::LOADING_METHOD_BINARY ) )
	{
		ASSERT( !"Failed : API_SLInit()" );
		return FALSE;
	}

	return true;
}


void CNaviMainWorldProcess::Delete( void )
{
	DeleteWorld();

	API_SLTerminate();

	if ( m_pVisualManager )
	{
		m_pVisualManager->Destroy();
		NTL_DELETE( m_pVisualManager );
		m_pVisualManager = NULL;
	}

	if ( m_pPropContainter )
	{
		m_pPropContainter->Destroy();
		NTL_DELETE( m_pPropContainter );
	}

	API_PLTerminate();

	API_CoreTerminate();

	if ( m_pPLEventHandler )
	{
		m_pPLEventHandler->Destroy();
		NTL_DELETE( m_pPLEventHandler );
	}

	CNaviRenderingProcess::Delete();
}


LRESULT CNaviMainWorldProcess::WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{
	if ( uiMsg == WM_KEYDOWN )
	{
		if ( wParam == 'Q' )
		{
			RwV3d v3WorldPos;
			v3WorldPos.x = 4992.f;
			v3WorldPos.y = 30.f;
			v3WorldPos.z = 2688.f;

			MoveCamera( v3WorldPos );
		}
	}

	return CNaviRenderingProcess::WindowProc( hWnd, uiMsg, wParam, lParam );
}


bool CNaviMainWorldProcess::CreateWorld( unsigned int uiWorldTblIdx )
{
	sWORLD_TBLDAT* pWorldTbl = (sWORLD_TBLDAT*)API_GetTableContainer()->GetWorldTable()->FindData( uiWorldTblIdx );

	SetCurrentDirectory( g_szWorkingFolder );

	// set texture folder path
	strcpy( dGET_WORLD_PARAM()->CurWorkingFolderName, g_szWorkingFolder );
	strcpy( dGET_WORLD_PARAM()->CurDefaultTexPath, g_szWorkingFolder );
	strcat( dGET_WORLD_PARAM()->CurDefaultTexPath, NAVI_GAME_WORLD_DATA_TEXTURE_FOLDER );

	// set mesh folder path
	std::string strWorldWorkingFolder = g_szWorkingFolder;
	strWorldWorkingFolder += NAVI_GAME_WORLD_FOLDER;
	strWorldWorkingFolder += "\\";
	strWorldWorkingFolder += pWorldTbl->szName;

	strcat( dGET_WORLD_PARAM()->WorldProjectFolderName, strWorldWorkingFolder.c_str() );

	std::string strWorldFileName = strWorldWorkingFolder;
	strWorldFileName += "\\";
	strWorldFileName += NAVI_GAME_WORLD_DATA_PROP_FILE;

	FILE* pFile = NULL;
	pFile = fopen( strWorldFileName.c_str(), "rb" );

	// create a global world param
	if ( pFile )
	{
		RwChar WorldVer[10];
		fread(WorldVer,	10, 1, pFile);

		//if(strcmp(dGET_WORLD_PARAM()->WorldVer, WorldVer))
		//{
		//}

		fread(&dGET_WORLD_PARAM()->WorldHeightfieldNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorTileSize,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorTileNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorVertNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorSize,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorNum,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorHalfNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSectorPolyNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldFieldSectorNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldFieldSize,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldFieldNum,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldFieldHalfNum,		sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSize,				sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldSizeHalf,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldValueMax,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldValueMin,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldTexAddr,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldPolyCnt,			sizeof(RwInt32),	1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldNearPlane,			sizeof(RwReal),		1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldFarPlane,			sizeof(RwReal),		1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldCamSpeedPerSec,		sizeof(RwReal),		1, pFile);
		fread(dGET_WORLD_PARAM()->WorldRAW,					64,					1, pFile);
		fread(&dGET_WORLD_PARAM()->WorldTriggerSerialID,	sizeof(RwUInt32),	1, pFile);
		//fread(&dGET_WORLD_PARAM()->IdxSkyType,				sizeof(RwInt32),	1, pFile);
		fclose(pFile);
	}

	dGET_WORLD_PARAM()->LODEnable				= FALSE;
	dGET_WORLD_PARAM()->NumBrushRadiusInTile	= 3.0f;
	dGET_WORLD_PARAM()->FieldGuideLine			= FALSE;
	dGET_WORLD_PARAM()->FlgHeightValueShow		= FALSE;
	dGET_WORLD_PARAM()->FlgObjInfoShow			= FALSE;
	dGET_WORLD_PARAM()->ClrDayAndNight			= 0x00000000;
	dGET_WORLD_PARAM()->ClrDiffuserPicker		= 0x00000000;
	dGET_WORLD_PARAM()->ClrBaseAmbient[0]		= 100;
	dGET_WORLD_PARAM()->ClrBaseAmbient[1]		= 100;
	dGET_WORLD_PARAM()->ClrBaseAmbient[2]		= 100;
	dGET_WORLD_PARAM()->ClrShadow				= 0xff777777;

	// temporary
	dGET_WORLD_PARAM()->IdxSkyType = eSTI_HEMISPHERE;

	RwV3d v3WorldPos;
	v3WorldPos.x = v3WorldPos.y = v3WorldPos.z = 0.f;

	m_pWorldEntity = static_cast<CNtlPLWorldEntity*>(GetSceneManager()->CreateEntity(PLENTITY_WORLD, "NtlWorld"));
	m_pWorldEntity->CreateWorld( v3WorldPos );

	RpWorldAddCamera( CNtlPLGlobal::m_pRpWorld, CNtlPLGlobal::m_RwCamera );

	return true;
}


void CNaviMainWorldProcess::DeleteWorld( void )
{
	if ( m_pWorldEntity )
	{
		RpWorldRemoveCamera( CNtlPLGlobal::m_pRpWorld, CNtlPLGlobal::m_RwCamera );
		m_pVisualManager->DeleteEntity( m_pWorldEntity );
		m_pWorldEntity = NULL;
	}
}

void CNaviMainWorldProcess::UpdateWorld( void )
{
	if ( m_pCamera && m_pWorldEntity )
	{
		RwMatrix* prwMatrix = RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) );
		m_pWorldEntity->SetPlayerPosition( prwMatrix->pos );
	}
}

void CNaviMainWorldProcess::OnDeviceRestore( void )
{
	CNaviRenderingProcess::OnDeviceRestore();
}


void CNaviMainWorldProcess::OnDeviceRelease( void )
{
	CNaviRenderingProcess::OnDeviceRelease();
}


void CNaviMainWorldProcess::OnUpdate( float fTime, float fElapsedTime )
{
	CNaviRenderingProcess::OnUpdate( fTime, fElapsedTime );

	API_CoreUpdate( fElapsedTime );

	if ( m_pCamera && m_pWorldEntity )
	{
		UpdateWorld();

		m_pVisualManager->UpdateBeforeCamera( fElapsedTime );

		RwRGBA BkColor;
		BkColor.red = 100; BkColor.green = 100; BkColor.blue  = 100; BkColor.alpha = 0;

		m_pCamera->CameraClear( &BkColor, rwCAMERACLEARZ|rwCAMERACLEARIMAGE );

		if ( m_pCamera->PostCameraBeginUpdate( fElapsedTime ) )
		{
			m_pVisualManager->Update(fElapsedTime);

			m_pVisualManager->Render(); 

			m_pCamera->PostCameraEndUpdate();
		}

		m_pCamera->UpdatePostEffectFilter(); 
		m_pCamera->UpdateMotionBlur( fElapsedTime );

		if ( m_pCamera->MainCameraBeginUpdate( fElapsedTime ) )
		{
			m_pVisualManager->PostRender();

			m_pCamera->MainCameraEndUpdate();
		}

		m_pCamera->CameraShowRaster( m_pWnd->GetSafeHwnd(), 0 );
	}
}
