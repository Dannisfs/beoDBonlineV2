// ZoneView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "ZoneView.h"


// CZoneAttr

const float CZoneAttr::s_fDefaultWorldSize = 64.f;
const float CZoneAttr::s_fFieldSize = 256.f;
const int CZoneAttr::s_nPixelPerGrid = 50;


// CZoneView


IMPLEMENT_DYNCREATE(CZoneView, CScrollView)


CZoneView::CZoneView()
{
	m_ZoneAttr.Clear();
}

CZoneView::~CZoneView()
{
}

void CZoneView::SetWorldRegion( float fBeginX, float fBeginZ, float fEndX, float fEndZ )
{
	m_ZoneAttr.m_fBeginX = fBeginX;
	m_ZoneAttr.m_fBeginZ = fBeginZ;

	m_ZoneAttr.m_fEndX = fEndX;
	m_ZoneAttr.m_fEndZ = fEndZ;

	m_ZoneAttr.m_defFieldList.clear();

	m_ZoneAttr.m_strMinimapName.Empty();

	m_ZoneAttr.Update();

	ScrollToPosition( CPoint( 0, 0 ) );

	UpdateZoneView();
}

void CZoneView::SetMinimap( const CString& strMinimapName )
{
	m_ZoneAttr.m_strMinimapName = strMinimapName;

	m_ZoneAttr.Update();

	UpdateZoneView();
}

BOOL CZoneView::HasField( DWORD dwFieldID )
{
	mapdef_FieldList::iterator it = m_ZoneAttr.m_defFieldList.find( dwFieldID );
	if ( it == m_ZoneAttr.m_defFieldList.end() ) return FALSE;
	return TRUE;
}

void CZoneView::AddField( DWORD dwFieldID )
{
	m_ZoneAttr.m_defFieldList[dwFieldID] = GetGridRgnFromFieldId( dwFieldID );

	UpdateZoneView();
}

void CZoneView::RemoveField( DWORD dwFieldID )
{
	mapdef_FieldList::iterator it = m_ZoneAttr.m_defFieldList.find( dwFieldID );
	if ( it != m_ZoneAttr.m_defFieldList.end() )
	{
		m_ZoneAttr.m_defFieldList.erase( it );
	}

	UpdateZoneView();
}

void CZoneView::ClearAllZoneAttr( void )
{
	m_ZoneAttr.Clear();

	m_ZoneAttr.Update();

	ScrollToPosition( CPoint( 0, 0 ) );

	UpdateZoneView();
}

void CZoneView::UpdateZoneView( void )
{
	SetScrollSizes( MM_TEXT, m_ZoneAttr.m_TotoalSize );

	InvalidateRect( NULL );
}

CRect CZoneView::GetGridRgnFromFieldId( DWORD dwFieldID )
{
	int nTotalFieldIdCnt = (m_ZoneAttr.m_nGridCntX - 1) * (m_ZoneAttr.m_nGridCntZ - 1);

	dwFieldID = nTotalFieldIdCnt - 1 - dwFieldID;

	CRect rtRgn;

	rtRgn.left = (dwFieldID % (m_ZoneAttr.m_nGridCntX - 1)) * m_ZoneAttr.s_nPixelPerGrid;
	rtRgn.right = rtRgn.left + CZoneAttr::s_nPixelPerGrid;

	rtRgn.top = (dwFieldID / (m_ZoneAttr.m_nGridCntX - 1)) * m_ZoneAttr.s_nPixelPerGrid;
	rtRgn.bottom = rtRgn.top + CZoneAttr::s_nPixelPerGrid;

	return rtRgn;
}

DWORD CZoneView::GetFieldIdFromGridIndex( int nX, int nZ )
{
	int nTotalFieldIdCnt = (m_ZoneAttr.m_nGridCntX - 1) * (m_ZoneAttr.m_nGridCntZ - 1);
	int nGridFieldId = nX + nZ * (m_ZoneAttr.m_nGridCntX - 1);
	return nTotalFieldIdCnt - 1 - nGridFieldId;
}

CPoint CZoneView::GetGridIndexFromGridRgn( const CPoint& ptPos )
{
	CPoint ptRet;

	ptRet.x = (ptPos.x % GetTotalSize().cx) / CZoneAttr::s_nPixelPerGrid;
	ptRet.y = (ptPos.y % GetTotalSize().cy) / CZoneAttr::s_nPixelPerGrid;

	return ptRet;
}


BEGIN_MESSAGE_MAP(CZoneView, CScrollView)
END_MESSAGE_MAP()


// CZoneView �׸����Դϴ�.

void CZoneView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	UpdateZoneView();
}

void CZoneView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();

	CRect rtViewRgn;
	GetClientRect( rtViewRgn );
	rtViewRgn.OffsetRect( GetScrollPosition() );

	pDC->SetBkMode( TRANSPARENT );

	//////////////////////////////////////////////////////////////////////////
	// �̴ϸ��� ������ �Ѵ�
	//////////////////////////////////////////////////////////////////////////

	if ( m_ZoneAttr.m_pMiniMap && m_ZoneAttr.m_pMiniMap->pImpage )
	{
		CRect rtRgn( CPoint(0, 0), m_ZoneAttr.m_TotoalSize );
		m_ZoneAttr.m_pMiniMap->pImpage->Draw( pDC->GetSafeHdc(), rtRgn );
	}

	//////////////////////////////////////////////////////////////////////////
	// ���õ� �ʵ带 ������ �Ѵ�
	//////////////////////////////////////////////////////////////////////////

	CBrush clBrush( RGB( 255, 0, 0 ) );
	CGdiObject* pOld = pDC->SelectObject( &clBrush );

	mapdef_FieldList::iterator it = m_ZoneAttr.m_defFieldList.begin();
	for ( ; it != m_ZoneAttr.m_defFieldList.end(); ++it )
	{
		CRect& rtRgn = it->second;

		pDC->Rectangle( rtRgn );
	}

	pDC->SelectObject( pOld );

	//////////////////////////////////////////////////////////////////////////
	// �ʵ� �׸��带 �������Ѵ�
	//////////////////////////////////////////////////////////////////////////

	int i, j;
	CPoint ptStartPos, ptEndPos;

	ptStartPos.x = 0;
	ptStartPos.y = 0;
	ptEndPos.x = 0;
	ptEndPos.y = m_ZoneAttr.m_TotoalSize.cy;
	for ( i = 0; i < m_ZoneAttr.m_nGridCntX; ++i )
	{
		pDC->MoveTo( ptStartPos );
		pDC->LineTo( ptEndPos );

		ptStartPos.Offset( CZoneAttr::s_nPixelPerGrid, 0 );
		ptEndPos.Offset( CZoneAttr::s_nPixelPerGrid, 0 );
	}

	ptStartPos.x = 0;
	ptStartPos.y = 0;
	ptEndPos.x = m_ZoneAttr.m_TotoalSize.cx;
	ptEndPos.y = 0;
	for ( i = 0; i < m_ZoneAttr.m_nGridCntZ; ++i )
	{
		pDC->MoveTo( ptStartPos );
		pDC->LineTo( ptEndPos );

		ptStartPos.Offset( 0, CZoneAttr::s_nPixelPerGrid );
		ptEndPos.Offset( 0, CZoneAttr::s_nPixelPerGrid );
	}

	//////////////////////////////////////////////////////////////////////////
	// �ʵ� ���̵� �������Ѵ�
	//////////////////////////////////////////////////////////////////////////

	for ( j = 0; j < m_ZoneAttr.m_nGridCntZ; ++j )
	{
		for ( i = 0; i < m_ZoneAttr.m_nGridCntX; ++i )
		{
			DWORD dwFieldId = GetFieldIdFromGridIndex( i, j );
			CRect rtRgn = GetGridRgnFromFieldId( dwFieldId );

			CString strMsg; strMsg.Format( "%d", dwFieldId );

			pDC->DrawText( strMsg, rtRgn, DT_SINGLELINE|DT_VCENTER|DT_CENTER );
		}
	}
}


// CZoneView �����Դϴ�.

#ifdef _DEBUG
void CZoneView::AssertValid() const
{
	CScrollView::AssertValid();
}

#ifndef _WIN32_WCE
void CZoneView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif
#endif //_DEBUG


// CZoneView �޽��� ó�����Դϴ�.
