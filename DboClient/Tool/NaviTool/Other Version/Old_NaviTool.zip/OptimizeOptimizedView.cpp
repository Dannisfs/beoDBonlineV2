// OptimizeOptimizedView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "OptimizeOptimizedView.h"

#include "NaviOptimizedObjectProcess.h"


// COptimizeOptimizedView

IMPLEMENT_DYNCREATE(COptimizeOptimizedView, CView)

COptimizeOptimizedView::COptimizeOptimizedView()
{
	m_pProcess = new CNaviOptimizedObjectProcess( this );
}

COptimizeOptimizedView::~COptimizeOptimizedView()
{
	if ( m_pProcess )
	{
		delete m_pProcess;
		m_pProcess = NULL;
	}
}

BEGIN_MESSAGE_MAP(COptimizeOptimizedView, CView)
END_MESSAGE_MAP()


// COptimizeOptimizedView �׸����Դϴ�.

void COptimizeOptimizedView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.
}


// COptimizeOptimizedView �����Դϴ�.

#ifdef _DEBUG
void COptimizeOptimizedView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void COptimizeOptimizedView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// COptimizeOptimizedView �޽��� ó�����Դϴ�.
void COptimizeOptimizedView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	m_pProcess->Create();
}

BOOL COptimizeOptimizedView::PreTranslateMessage(MSG* pMsg)
{
	if ( m_pProcess )
	{
		m_pProcess->WindowProc( pMsg->hwnd, pMsg->message, pMsg->wParam, pMsg->lParam );
	}

	return CView::PreTranslateMessage(pMsg);
}
