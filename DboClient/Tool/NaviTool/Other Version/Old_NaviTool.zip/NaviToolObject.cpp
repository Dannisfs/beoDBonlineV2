#include "stdafx.h"
#include "NaviToolObject.h"


CNaviToolObject::CNaviToolObject( void )
{
	m_nRef = 0;
	m_pParent = NULL;
	m_ID = GUID_NULL;
	m_bCreated = false;
}


CNaviToolObject::~CNaviToolObject( void )
{
	Delete();
}


CNaviToolObject::vecdef_ChildListIT CNaviToolObject::BeginChild( void )
{
	return m_defChilds.begin();
}


CNaviToolObject::vecdef_ChildListIT CNaviToolObject::EndChild( void )
{
	return m_defChilds.end();
}


CNaviToolObject::vecdef_ChildListCIT CNaviToolObject::BeginChild( void ) const
{
	return m_defChilds.begin();
}


CNaviToolObject::vecdef_ChildListCIT CNaviToolObject::EndChild( void ) const
{
	return m_defChilds.end();
}


void CNaviToolObject::AddChild( CNaviToolObject* pChild )
{
	m_defChilds.push_back( pChild );
}


void CNaviToolObject::RemoveChild( CNaviToolObject* pChild )
{
	vecdef_ChildListIT it = std::find( m_defChilds.begin(), m_defChilds.end(), pChild );
	if ( it != m_defChilds.end() )
	{
		m_defChilds.erase( it );
	}
}


void CNaviToolObject::RemoveAllChild( void )
{
	m_defChilds.clear();
}


GUID CNaviToolObject::GenerateID( void )
{
	GUID ID = GUID_NULL;
	::CoCreateGuid( &ID );

	if ( GUID_NULL == ID )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] ID ������ �����߽��ϴ�", __FILE__, __FUNCTION__, __LINE__ );
		return GUID_NULL;
	}

	return ID;
}


CString CNaviToolObject::IDToString( const GUID& ID )
{
	if ( IsEqualGUID( ID, GUID_NULL) )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] NULL ID�� ���ڿ��� ��ȯ�� �� �����ϴ�", __FILE__, __FUNCTION__, __LINE__ );
		return CString();
	}

	CString strID;
	strID.Format( "%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d",
				  ID.Data1,
				  ID.Data2,
				  ID.Data3,
				  ID.Data4[0],
				  ID.Data4[1],
				  ID.Data4[2],
				  ID.Data4[3],
				  ID.Data4[4],
				  ID.Data4[5],
				  ID.Data4[6],
				  ID.Data4[7] );
	return strID;
}


GUID CNaviToolObject::StringToID( const CString& strID )
{
	int nInputCnt = 0;
	GUID ID;

	int nPos = 0;
	CString strToken = strID.Tokenize( "_", nPos );
	while ( strToken != "" )
	{
		switch ( nInputCnt )
		{
		case 0:
			ID.Data1 = (unsigned long)atoi( strToken );
			break;
		case 1:
			ID.Data2 = (unsigned short)atoi( strToken );
			break;
		case 2:
			ID.Data3 = (unsigned short)atoi( strToken );
			break;
		case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:
			ID.Data4[nInputCnt - 4] = (unsigned char)atoi( strToken );
			break;
		default:
			break;
		}

		++nInputCnt;
		strToken = strID.Tokenize( "-", nPos );
	};

	if ( 11 == nInputCnt )
	{
		return ID;
	}
	else
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] ID�� ��ȯ�ϱ⿡ �������� ���ڿ��Դϴ�", __FILE__, __FUNCTION__, __LINE__, strID );
		return GUID_NULL;
	}
}


bool CNaviToolObject::Create( CNaviToolAttrs* pAttrs )
{
	m_bCreated = true;

	return true;
}

void CNaviToolObject::Delete( void )
{
	m_bCreated = false;
	m_ID = GUID_NULL;
	m_pParent = NULL;
	m_defChilds.clear();
	m_nRef = 0;
}


void CNaviToolObject::Update( float fTime, float fElapsedTime )
{
	vecdef_ChildListIT it = m_defChilds.begin();
	for ( ; it != m_defChilds.end(); ++it )
	{
		(*it)->Update( fTime, fElapsedTime );
	}
}


void CNaviToolObject::Render( RwCamera* pCamera, const RwMatrix* pParentMatrix )
{
	vecdef_ChildListIT it = m_defChilds.begin();
	for ( ; it != m_defChilds.end(); ++it )
	{
		(*it)->Render( pCamera, pParentMatrix );
	}
}
