// NaviToolView.cpp : implementation of the CNaviToolView class
//

#include "stdafx.h"
#include "NaviTool.h"

#include "NaviToolDoc.h"
#include "NaviToolView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CNaviToolView

IMPLEMENT_DYNCREATE(CNaviToolView, CView)

BEGIN_MESSAGE_MAP(CNaviToolView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CNaviToolView construction/destruction

CNaviToolView::CNaviToolView()
{
	// TODO: add construction code here

}

CNaviToolView::~CNaviToolView()
{
}

BOOL CNaviToolView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CNaviToolView drawing

void CNaviToolView::OnDraw(CDC* /*pDC*/)
{
	CNaviToolDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
}


// CNaviToolView printing

BOOL CNaviToolView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNaviToolView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNaviToolView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CNaviToolView diagnostics

#ifdef _DEBUG
void CNaviToolView::AssertValid() const
{
	CView::AssertValid();
}

void CNaviToolView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CNaviToolDoc* CNaviToolView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNaviToolDoc)));
	return (CNaviToolDoc*)m_pDocument;
}
#endif //_DEBUG


// CNaviToolView message handlers
