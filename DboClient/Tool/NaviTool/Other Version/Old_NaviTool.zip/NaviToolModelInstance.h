#ifndef _NAVI_TOOL_MODELINSTANCE_H_
#define _NAVI_TOOL_MODELINSTANCE_H_


#include "NaviToolObject.h"


class CNaviToolWorldProperty;


class CNaviToolModelInstance : public CNaviToolObject
{

// Member variables
protected:
	// Attributes
	CNaviToolWorldProperty*				m_pWorldProperty;
	RwMatrix							m_matLocal;


// Constructions and Destructions
protected:
	CNaviToolModelInstance( void );
	virtual ~CNaviToolModelInstance( void );


// Operations
public:
	CNaviToolWorldProperty*				GetWorldProperty( void );
	void								SetWorldProperty( CNaviToolWorldProperty* pWorldProperty );

	const RwMatrix&						GetLocalMatrix( void ) const;
	void								SetLocalMatrix( const RwMatrix& matLocal );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );
	virtual void						Render( RwCamera* pCamera, const RwMatrix* pParentMatrix );


	friend class CNaviToolObjectFactory;

};


inline CNaviToolWorldProperty* CNaviToolModelInstance::GetWorldProperty( void )
{
	return m_pWorldProperty;
}


inline void CNaviToolModelInstance::SetWorldProperty( CNaviToolWorldProperty* pWorldProperty )
{
	m_pWorldProperty = pWorldProperty;
}


inline const RwMatrix& CNaviToolModelInstance::GetLocalMatrix( void ) const
{
	return m_matLocal;
}


inline void CNaviToolModelInstance::SetLocalMatrix( const RwMatrix& matLocal )
{
	RwMatrixCopy( &m_matLocal, &matLocal );
}


#endif