#ifndef _NAVI_MAINWORLDPROCESS_H_
#define _NAVI_MAINWORLDPROCESS_H_


#include <rtcharse.h>

#include "NtlApplication.h"
#include "NtlCamera.h"
#include "NtlLogic.h"

#include "NtlPLVisualManager.h"
#include "NtlPLPropertyContainer.h"
#include "NtlPLEventHandler.h"

#include "NtlSLGlobal.h"
#include "NtlSLEventHandler.h"
#include "NtlSobAvatar.h"
#include "NtlSobManager.h"
#include "NtlFSMLookAtManager.h"
#include "InputHandler.h"
#include "InputActionMap.h"

#include "NaviRenderingProcess.h"


class CNaviMainWorldProcess : public CNaviRenderingProcess
{

// Member variables
protected:
	// DBO project ���� ������
	CNtlPLEventHandler*					m_pPLEventHandler;
	CNtlPLPropertyContainer*			m_pPropContainter;
	CNtlPLVisualManager*				m_pVisualManager;

	// Game world
	CNtlPLWorldEntity*					m_pWorldEntity;


// Constructions and Destructions
public:
	CNaviMainWorldProcess( CWnd* pWnd );
	virtual ~CNaviMainWorldProcess( void );


// Methods
public:
	// Create and Delete
	virtual bool						Create( void );
	virtual void						Delete( void );
	virtual LRESULT						WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam );

	CNtlPLWorldEntity*					GetWorldEntity( void );
	bool								CreateWorld( unsigned int uiWorldTblIdx );
	void								DeleteWorld( void );
	void								UpdateWorld( void );


// Implementations
protected:
	virtual void						OnDeviceRestore( void );
	virtual void						OnDeviceRelease( void );
	virtual void						OnUpdate( float fTime, float fElapsedTime );

};


inline CNtlPLWorldEntity* CNaviMainWorldProcess::GetWorldEntity( void )
{
	return m_pWorldEntity;
}


#endif