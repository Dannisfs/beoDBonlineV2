#include "stdafx.h"
#include "NaviToolZone.h"

#include "NaviToolWorldProperty.h"
#include "NaviToolField.h"


CNaviToolZone::CNaviToolZone( void )
{
	m_pWorldProperty = NULL;
	m_uiZoneID = 0xffffffff;

	m_v3ZoneBegin.x = m_v3ZoneBegin.y = m_v3ZoneBegin.z = FLT_MAX;
	m_v3ZoneEnd.x = m_v3ZoneEnd.y = m_v3ZoneEnd.z = -FLT_MAX;

	m_fTileSize = 4.f;

	m_nVertexCnt = 0;
	m_nVertexWidthCnt = 0;
	m_pVertexList = NULL;

	m_defIndexList.reserve( 65 * 65 * 2 * 3 );
}


CNaviToolZone::~CNaviToolZone( void )
{
	Delete();
}


void CNaviToolZone::AddChild( CNaviToolObject* pChild )
{
	CNaviToolObject::AddChild( pChild );

	UpdateZoneRgn();
}


void CNaviToolZone::RemoveChild( CNaviToolObject* pChild )
{
	CNaviToolObject::RemoveChild( pChild );

	UpdateZoneRgn();
}


void CNaviToolZone::RemoveAllChild( void )
{
	CNaviToolObject::RemoveAllChild();

	UpdateZoneRgn();
}


bool CNaviToolZone::Create( CNaviToolAttrs* pAttrs )
{
	if ( m_bCreated ) return true;

	CNaviToolAttrs_Zone* pZoneAttr = dynamic_cast< CNaviToolAttrs_Zone* > ( pAttrs );
	if ( NULL == pZoneAttr )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �߸��� �Ӽ� ������ �ԷµǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pAttrs ? typeid(pAttrs).name() : "NULL") );
		return false;
	}

	m_pWorldProperty = pZoneAttr->pWorldProperty;
	m_uiZoneID = pZoneAttr->uiZoneID;

	m_fTileSize = m_pWorldProperty->GetTileSize();

	return CNaviToolObject::Create( pAttrs );
}


void CNaviToolZone::Delete( void )
{
	if ( m_pVertexList )
	{
		delete [] m_pVertexList;
		m_pVertexList = NULL;
	}
	m_nVertexWidthCnt = 0;
	m_nVertexCnt = 0;

	m_fTileSize = 4.f;

	m_v3ZoneEnd.x = m_v3ZoneEnd.y = m_v3ZoneEnd.z = -FLT_MAX;
	m_v3ZoneBegin.x = m_v3ZoneBegin.y = m_v3ZoneBegin.z = FLT_MAX;

	m_uiZoneID = 0xffffffff;
	m_pWorldProperty = NULL;

	CNaviToolObject::Delete();
}


void CNaviToolZone::Render( RwCamera* pCamera, const RwMatrix* pParentMatrix )
{
	if ( !m_bCreated ) return;

	RwMatrix matWorld;

	if ( pParentMatrix )
	{
		RwMatrixCopy( &matWorld, pParentMatrix );
	}
	else
	{
		RwMatrixSetIdentity( &matWorld );
	}

	CNaviToolObject::Render( pCamera, &matWorld );
}


void CNaviToolZone::UpdateZoneRgn( void )
{
	m_v3ZoneBegin.x = m_v3ZoneBegin.y = m_v3ZoneBegin.z = FLT_MAX;
	m_v3ZoneEnd.x = m_v3ZoneEnd.y = m_v3ZoneEnd.z = -FLT_MAX;

	RwV3d v3FieldBegin, v3FieldEnd;

	vecdef_ChildListIT it = BeginChild();
	for ( ; it != EndChild(); ++it )
	{
		CNaviToolField* pField = dynamic_cast< CNaviToolField* > ( *it );

		if ( pField )
		{
			pField->GetFieldRgn( v3FieldBegin, v3FieldEnd );

			m_v3ZoneBegin.x = (m_v3ZoneBegin.x > v3FieldBegin.x ? v3FieldBegin.x : m_v3ZoneBegin.x);
			m_v3ZoneBegin.y = (m_v3ZoneBegin.y > v3FieldBegin.y ? v3FieldBegin.y : m_v3ZoneBegin.y);
			m_v3ZoneBegin.z = (m_v3ZoneBegin.z > v3FieldBegin.z ? v3FieldBegin.z : m_v3ZoneBegin.z);

			m_v3ZoneEnd.x = (m_v3ZoneEnd.x < v3FieldEnd.x ? v3FieldEnd.x : m_v3ZoneEnd.x);
			m_v3ZoneEnd.y = (m_v3ZoneEnd.y < v3FieldEnd.y ? v3FieldEnd.y : m_v3ZoneEnd.y);
			m_v3ZoneEnd.z = (m_v3ZoneEnd.z < v3FieldEnd.z ? v3FieldEnd.z : m_v3ZoneEnd.z);
		}
		else
		{
			CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] Zone�� �߸��� �ڽ��� ��ϵǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pField ? typeid(pField).name() : "NULL") );
		}
	}
}


bool CNaviToolZone::BuildDataForPath( void )
{
	if ( m_pVertexList )
	{
		delete [] m_pVertexList;
	}

	m_nVertexWidthCnt = (int)((m_v3ZoneEnd.x - m_v3ZoneBegin.x) / m_fTileSize + 1.f);
	m_nVertexCnt = m_nVertexWidthCnt * (int)((m_v3ZoneEnd.z - m_v3ZoneBegin.z) / m_fTileSize + 1.f);

	m_pVertexList = new LPRWIM3DVERTEX[m_nVertexCnt];
	memset( m_pVertexList, 0, sizeof(LPRWIM3DVERTEX) * m_nVertexCnt );

	if ( NULL == m_pVertexList )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d] �޸� �Ҵ� ����", __FILE__, __FUNCTION__, __LINE__, m_nVertexCnt );
		return false;
	}

	m_defIndexList.clear();

	vecdef_ChildListIT it = BeginChild();
	for ( ; it != EndChild(); ++it )
	{
		CNaviToolField* pField = dynamic_cast< CNaviToolField* > ( *it );

		if ( pField )
		{
			int nVertexCnt = pField->GetVertexCount();
			for ( RwImVertexIndex i = 0; i < nVertexCnt; ++i )
			{
				LPRWIM3DVERTEX pVert = pField->GetVertex( i );
				m_pVertexList[ConvertFieldPosToVertexIndex(pVert->objVertex)] = pVert;
			}

			int nIndexCnt = pField->GetIndexCount();
			for ( int i = 0; i < nIndexCnt; ++i )
			{
				int nIndex = ConvertFieldPosToVertexIndex( pField->GetVertex( pField->GetIndex( i ) )->objVertex );
				m_defIndexList.push_back( nIndex );
			}
		}
		else
		{
			CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] Zone�� �߸��� �ڽ��� ��ϵǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pField ? typeid(pField).name() : "NULL") );
		}
	}

	return true;
}
