#include "stdafx.h"
#include "NaviToolObjectBuilder.h"

#include "NtlWorldField.h"
#include "NtlWorldSectorManager.h"
#include "NtlWorldFieldManager.h"
#include "NtlPLWorldEntity.h"
#include "NtlPLObject.h"


CNaviToolObjectBuilder::CNaviToolObjectBuilder( void )
{
}


CNaviToolObjectBuilder::~CNaviToolObjectBuilder( void )
{
}


CNaviToolObject* CNaviToolObjectBuilder::BuildFromWorldData( unsigned int uiWorldTblIdx,
															 unsigned int uiZoneID,
															 unsigned int uiFieldCnt,
															 unsigned int aruiFieldProperty[],
															 unsigned int uiTileCnt,
															 unsigned int aruiTileProperty[],
															 sNtlWorldParam* pWorldParam,
															 CNtlPLWorldEntity* pWorldEntity )
{
	int i, j;

	//////////////////////////////////////////////////////////////////////////
	//	������ ũ�� ���
	//	�ش� ���� �ش��ϴ� �ʵ带 �ɷ�����
	//////////////////////////////////////////////////////////////////////////

	RwV3d v3WorldBegin; v3WorldBegin.x = v3WorldBegin.z = -(float)pWorldParam->WorldSizeHalf; v3WorldBegin.y = 0.f;
	RwV3d v3WorldEnd; v3WorldEnd.x = v3WorldEnd.z = (float)pWorldParam->WorldSizeHalf; v3WorldEnd.y = 0.f;

	std::vector< unsigned int > vecdef_FieldList;
	vecdef_FieldList.reserve( 100 );

	for ( i = 0; i < uiFieldCnt; ++i )
	{

		if ( aruiFieldProperty[i] == uiZoneID )
		{
			vecdef_FieldList.push_back( i );
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	World property ����
	//////////////////////////////////////////////////////////////////////////

	CNaviToolWorldProperty* pWorldProp = m_clObjFactory.CreateObject< CNaviToolWorldProperty >();

	CNaviToolAttrs_WorldProperty WordPropAttr;
	WordPropAttr.uiWorldTblIdx = uiWorldTblIdx;
	WordPropAttr.v3WorldBegin = v3WorldBegin;
	WordPropAttr.v3WorldEnd = v3WorldEnd;
	WordPropAttr.uiFieldCnt = uiFieldCnt;
	WordPropAttr.fFieldSize = (float)pWorldParam->WorldFieldSize;
	WordPropAttr.uiTileCnt = uiTileCnt;
	WordPropAttr.fTileSize = (float)pWorldParam->WorldSectorTileSize;

	if ( !pWorldProp->Create( &WordPropAttr ) )
	{
		DeleteAll();
		return NULL;
	}

	for ( i = 0; i < uiFieldCnt; ++i )
	{
		pWorldProp->SetFieldProperty( i, aruiFieldProperty[i] );
	}

	// lleo52
	// �Ʒ� �ڵ�� ���߿� �ݵ�� Ÿ�� ������ ó���� �� �ֵ��� ���� �ʿ�!!!
	for ( i = 0; i < uiTileCnt; ++i )
	{
		pWorldProp->SetTileProperty( i, aruiTileProperty[i] );
	}

	//////////////////////////////////////////////////////////////////////////
	//	World ����
	//////////////////////////////////////////////////////////////////////////

	CNaviToolWorld* pWorld = m_clObjFactory.CreateObject< CNaviToolWorld >();

	CNaviToolAttrs_World WorldAttr;
	WorldAttr.pWorldProperty = pWorldProp;
	WorldAttr.uiWorldTblIdx = uiWorldTblIdx;

	if ( !pWorld->Create( &WorldAttr ) )
	{
		DeleteAll();
		return NULL;
	}

	////////////////////////////////////////////////////////////////////////////
	////	Zone ����
	////////////////////////////////////////////////////////////////////////////

	CNaviToolZone* pZone = m_clObjFactory.CreateObject< CNaviToolZone >();

	CNaviToolAttrs_Zone ZoneAttr;
	ZoneAttr.pWorldProperty = pWorldProp;
	ZoneAttr.uiZoneID = uiZoneID;

	if ( !pZone->Create( &ZoneAttr ) )
	{
		DeleteAll();
		return NULL;
	}

	pZone->SetParent( pWorld );
	pWorld->AddChild( pZone );


	////////////////////////////////////////////////////////////////////////////
	////	Field ó��
	////////////////////////////////////////////////////////////////////////////

	std::vector< unsigned int >::iterator it = vecdef_FieldList.begin();
	for ( ; it != vecdef_FieldList.end(); ++it )
	{
		unsigned int uiFieldID = *it;

		// Game Field ����
		bool bMustDelField = false;
		if ( !pWorldEntity->GetWorldFieldMgr()->IsFieldLoaded( uiFieldID ) )
		{
			bMustDelField = true;

			if ( !pWorldEntity->GetWorldFieldMgr()->CreateFields( uiFieldID ) )
			{
				DeleteAll();
				return NULL;
			}
		}

		////////////////////////////////////////////////////////////////////////////
		////	Field ����
		////////////////////////////////////////////////////////////////////////////

		CNaviToolField* pField = m_clObjFactory.CreateObject< CNaviToolField >();

		CNaviToolAttrs_Field FieldAttr;
		FieldAttr.pWorldProperty = pWorldProp;
		FieldAttr.uiFieldID = uiFieldID;

		if ( !pField->Create( &FieldAttr ) )
		{
			DeleteAll();
			return NULL;
		}

		//////////////////////////////////////////////////////////////////////////
		//	Sector ó��
		//////////////////////////////////////////////////////////////////////////

		CNtlWorldField* pWorldField = (CNtlWorldField*)pWorldEntity->GetWorldFieldMgr()->GetFields();
		const RwV3d SPos = pWorldField[uiFieldID].GetSPos();
		RwV3d SSectorPos;
		RwInt32 iSectorIdx;

		RwImVertexIndex GeomVertexIndex;
		RwIm3DVertex GeomVertex;

		for ( i = (int)SPos.z; i < (int)SPos.z + pWorldParam->WorldFieldSize; i += pWorldParam->WorldSectorSize )
		{
			for ( j = (int)SPos.x; j < (int)SPos.x + pWorldParam->WorldFieldSize; j += pWorldParam->WorldSectorSize )
			{
				SSectorPos.x = (float)j;
				SSectorPos.z = (float)i;

				iSectorIdx = pWorldEntity->GetWorldFieldMgr()->GetSectorIdx( SSectorPos );

				////////////////////////////////////////////////////////////////////////////
				////	Field�� Vertex ���� ����
				////////////////////////////////////////////////////////////////////////////

				int nVertexSize = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->numVertices;

				for ( int nVertIdx = 0; nVertIdx < nVertexSize; ++nVertIdx )
				{
					RwV3d& v3Vertex = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->morphTarget->verts[nVertIdx];

					GeomVertexIndex = pField->ConvertFieldPosToVertexIndex( v3Vertex );

					GeomVertex.objVertex = v3Vertex;
					GeomVertex.objNormal.x = GeomVertex.objNormal.z = 0.f; GeomVertex.objNormal.y = 1.f;
					GeomVertex.color = 0xffffffff;
					GeomVertex.u = GeomVertex.v = 1.f;

					pField->SetVertex( GeomVertexIndex, GeomVertex );
				}

				////////////////////////////////////////////////////////////////////////////
				////	Field�� Index ���� ����
				////////////////////////////////////////////////////////////////////////////

				int nTriSize = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->numTriangles;

				for ( int nTriIdx = 0; nTriIdx < nTriSize; ++nTriIdx )
				{
					RwV3d& v3Vertex0 = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->morphTarget->verts[pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->triangles[nTriIdx].vertIndex[0]];
					RwV3d& v3Vertex1 = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->morphTarget->verts[pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->triangles[nTriIdx].vertIndex[1]];
					RwV3d& v3Vertex2 = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->morphTarget->verts[pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_pAtomic->geometry->triangles[nTriIdx].vertIndex[2]];

					pField->AddIndex( pField->ConvertFieldPosToVertexIndex( v3Vertex0 ),
									  pField->ConvertFieldPosToVertexIndex( v3Vertex1 ),
									  pField->ConvertFieldPosToVertexIndex( v3Vertex2 ) );
				}

				//////////////////////////////////////////////////////////////////////////
				////	Field�� Model �� Model instance ó��
				//////////////////////////////////////////////////////////////////////////

				vector<CNtlPLEntity*>::iterator itOrnament = pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_vecNtlPLEntityOrnament.begin();
				for ( ; itOrnament != pWorldEntity->GetWorldFieldMgr()->m_pSectors[iSectorIdx].m_vecNtlPLEntityOrnament.end(); ++itOrnament )
				{
					CNtlPLObject* pPLObject = dynamic_cast< CNtlPLObject* >( *itOrnament );
					if ( NULL == pPLObject ) continue;

					// Path�������� �̿��� ���ϱ����� ���ٸ� ��ü�� �������� �ʴ´�
					int nCnt = 0;
					ENTITY_ATOMIC_VEC* pAtomicList = pPLObject->GetAtomicList();
					ENTITY_ATOMIC_VEC::iterator itColAtomic = pAtomicList->begin();
					for ( ; itColAtomic != pAtomicList->end(); ++itColAtomic )
					{
						if ( NTL_COLLISION != RpNtlAtomicGetFlag( (*itColAtomic)->pData ) ) continue;
						nCnt++;
					}
					if ( 0 == nCnt ) continue;

					//////////////////////////////////////////////////////////////////////////
					////	Model instance ����
					//////////////////////////////////////////////////////////////////////////

					CNaviToolModelInstance* pModelInst = m_clObjFactory.CreateObject< CNaviToolModelInstance > ();

					if ( pModelInst )
					{
						CNaviToolAttrs_ModelInstance clModelInstAttr;
						clModelInstAttr.pWorldProperty = pWorldProp;
						RwMatrixCopy( &clModelInstAttr.matLocal, &pPLObject->GetMatrix() );

						if ( !pModelInst->Create( &clModelInstAttr ) )
						{
							DeleteAll();
							return NULL;
						}
					}
					else
					{
						DeleteAll();
						return NULL;
					}

					pModelInst->SetParent( pField );
					pField->AddChild( pModelInst );

					//////////////////////////////////////////////////////////////////////////
					////	Model ����
					//////////////////////////////////////////////////////////////////////////

					CNaviToolModel* pModel = m_clObjFactory.CreateModel( pPLObject->GetName() );

					if ( pModel )
					{
						CNaviToolAttrs_Model clModelAttr;
						clModelAttr.pWorldProperty = pWorldProp;
						strcpy( clModelAttr.szModelName, pPLObject->GetName() );
						clModelAttr.uiModelProperty = 0;

						if ( !pModel->Create( &clModelAttr ) )
						{
							DeleteAll();
							return NULL;
						}

						// ó�� ������ ��쿡�� Vertex, Index list�� �����Ѵ�
						if ( pModel->GetRef() == 1 )
						{
							RwMatrix matOld, matIndentity;
							RwMatrixSetIdentity( &matIndentity );
							RwMatrixCopy( &matOld, &pPLObject->GetMatrix() );
							pPLObject->SetMatrix( matIndentity );

							ENTITY_ATOMIC_VEC* pAtomicList = pPLObject->GetAtomicList();
							ENTITY_ATOMIC_VEC::iterator itColAtomic = pAtomicList->begin();
							for ( ; itColAtomic != pAtomicList->end(); ++itColAtomic )
							{
								SEntityAtomicData* pColAtomicData = *itColAtomic;

								if ( NTL_COLLISION != RpNtlAtomicGetFlag( pColAtomicData->pData ) ) continue;

								unsigned int uiModelAtomicID = pModel->CreateModelAtomic( pColAtomicData->pData->geometry->numVertices, pColAtomicData->pData->geometry->numTriangles * 3, *RwFrameGetMatrix( RpAtomicGetFrame( pColAtomicData->pData ) ) );

								if ( -1 == uiModelAtomicID )
								{
									DeleteAll();
									return NULL;
								}

								for ( int nVertIdx = 0; nVertIdx < pColAtomicData->pData->geometry->numVertices; ++nVertIdx )
								{
									GeomVertex.objVertex = pColAtomicData->pData->geometry->morphTarget->verts[nVertIdx];
									GeomVertex.objNormal.x = GeomVertex.objNormal.z = 0.f; GeomVertex.objNormal.y = 1.f;
									GeomVertex.color = 0xff00ffff;
									GeomVertex.u = GeomVertex.v = 1.f;

									pModel->SetVertex( uiModelAtomicID, nVertIdx, GeomVertex );
								}

								for ( int nTriIdx = 0; nTriIdx < pColAtomicData->pData->geometry->numTriangles; ++nTriIdx )
								{
									pModel->SetIndex( uiModelAtomicID, nTriIdx * 3, pColAtomicData->pData->geometry->triangles[nTriIdx].vertIndex[0] );
									pModel->SetIndex( uiModelAtomicID, nTriIdx * 3 + 1, pColAtomicData->pData->geometry->triangles[nTriIdx].vertIndex[1] );
									pModel->SetIndex( uiModelAtomicID, nTriIdx * 3 + 2, pColAtomicData->pData->geometry->triangles[nTriIdx].vertIndex[2] );
								}
							}

							pPLObject->SetMatrix( matOld );
						}

						pModelInst->AddChild( pModel );
					}
					else
					{
						DeleteAll();
						return NULL;
					}
				}
			}
		}

		pField->SetParent( pZone );
		pZone->AddChild( pField );

		// Game Field ����
		if ( bMustDelField )
		{
			pWorldEntity->GetWorldFieldMgr()->DeleteFields( uiFieldID );
		}
	}

	pZone->BuildDataForPath();

	return pWorld;
}


void CNaviToolObjectBuilder::DeleteAll( void )
{
	m_clObjFactory.DeleteAllObjects();
	m_clObjFactory.DeleteAllModels();
}
