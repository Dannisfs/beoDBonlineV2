#ifndef _NAVI_TOOL_FIELD_H_
#define _NAVI_TOOL_FIELD_H_


#include "NaviToolObject.h"


class CNaviToolWorldProperty;


class CNaviToolField : public CNaviToolObject
{

// Member variables
protected:
	// Attributes
	CNaviToolWorldProperty*				m_pWorldProperty;
	unsigned int						m_uiFieldID;

	// ��� �ӵ� ����� ���� �ӽ� ����
	float								m_fTileSize;
	float								m_fFieldSize;

	// Updated values
	RwV3d								m_v3FieldBegin;
	RwV3d								m_v3FieldEnd;

	int									m_nVertexCnt;
	int									m_nVertexWidthCnt;
	RwIm3DVertex*						m_pVertexList;

	int									m_nIndexCnt;
	int									m_nIndexMaxCnt;
	RwImVertexIndex*					m_pIndexList;


// Constructions and Destructions
protected:
	CNaviToolField( void );
	virtual ~CNaviToolField( void );


// Operations
public:
	CNaviToolWorldProperty*				GetWorldProperty( void );
	void								SetWorldProperty( CNaviToolWorldProperty* pWorldProperty );

	unsigned int						GetFieldID( void ) const;
	void								SetFieldID( unsigned int uiFieldID );

	void								GetFieldRgn( RwV3d& v3FieldBegin, RwV3d& v3FieldEnd ) const;

	int									GetVertexCount( void ) const;
	int									GetVertexWidthCount( void ) const;
	const RwIm3DVertex*					GetVertex( RwImVertexIndex VertIdx ) const;
	void								SetVertex( RwImVertexIndex VertIdx, const RwIm3DVertex& Vertex );
	RwImVertexIndex						ConvertFieldPosToVertexIndex( const RwV3d& v3Pos ) const;

	int									GetIndexCount( void ) const;
	RwImVertexIndex						GetIndex( int nIndexIdx ) const;
	void								AddIndex( const RwImVertexIndex& Index0, const RwImVertexIndex& Index1, const RwImVertexIndex& Index2 );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );
	virtual void						Render( RwCamera* pCamera, const RwMatrix* pParentMatrix );


	friend class CNaviToolObjectFactory;

};


inline CNaviToolWorldProperty* CNaviToolField::GetWorldProperty( void )
{
	return m_pWorldProperty;
}


inline void CNaviToolField::SetWorldProperty( CNaviToolWorldProperty* pWorldProperty )
{
	m_pWorldProperty = pWorldProperty;
}


inline unsigned int CNaviToolField::GetFieldID( void ) const
{
	return m_uiFieldID;
}


inline void CNaviToolField::SetFieldID( unsigned int uiFieldID )
{
	m_uiFieldID = uiFieldID;
}


inline void CNaviToolField::GetFieldRgn( RwV3d& v3FieldBegin, RwV3d& v3FieldEnd ) const
{
	v3FieldBegin = m_v3FieldBegin;
	v3FieldEnd = m_v3FieldEnd;
}


inline int CNaviToolField::GetVertexCount( void ) const
{
	return m_nVertexCnt;
}


inline int CNaviToolField::GetVertexWidthCount( void ) const
{
	return m_nVertexWidthCnt;
}


inline const RwIm3DVertex* CNaviToolField::GetVertex( RwImVertexIndex VertIdx ) const
{
	if ( VertIdx >= m_nVertexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� ���ؽ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiFieldID, m_nVertexCnt, VertIdx );
		return NULL;
	}

	return &m_pVertexList[VertIdx];
}


inline void CNaviToolField::SetVertex( RwImVertexIndex VertIdx, const RwIm3DVertex& Vertex )
{
	if ( VertIdx >= m_nVertexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� ���ؽ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiFieldID, m_nVertexCnt, VertIdx );
		return;
	}

	m_pVertexList[VertIdx] = Vertex;

	m_v3FieldBegin.y = (m_v3FieldBegin.y > Vertex.objVertex.y ? Vertex.objVertex.y : m_v3FieldBegin.y);
	m_v3FieldEnd.y = (m_v3FieldEnd.y < Vertex.objVertex.y ? Vertex.objVertex.y : m_v3FieldEnd.y);
}


inline RwImVertexIndex CNaviToolField::ConvertFieldPosToVertexIndex( const RwV3d& v3Pos ) const
{
	int nVertIdx = (int)(((v3Pos.z - m_v3FieldBegin.z) / m_fTileSize) * m_nVertexWidthCnt + ((v3Pos.x - m_v3FieldBegin.x) / m_fTileSize));

	unsigned int INVALID_CHECK = ~(unsigned int)((RwImVertexIndex)-1);

	if ( nVertIdx & INVALID_CHECK )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] Field position ���� Vertex index�� ��ȯ ����", __FILE__, __FUNCTION__, __LINE__, m_uiFieldID, m_nVertexCnt, nVertIdx );
		return -1;
	}

	return (RwImVertexIndex)nVertIdx;
}


inline int CNaviToolField::GetIndexCount( void ) const
{
	return m_nIndexCnt;
}


inline RwImVertexIndex CNaviToolField::GetIndex( int nIndexIdx ) const
{
	if ( nIndexIdx < 0 || nIndexIdx >= m_nIndexCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiFieldID, m_nIndexCnt, nIndexIdx );
		return -1;
	}

	return m_pIndexList[nIndexIdx];
}


inline void CNaviToolField::AddIndex( const RwImVertexIndex& Index0, const RwImVertexIndex& Index1, const RwImVertexIndex& Index2 )
{
	if ( Index0 >= m_nIndexMaxCnt ||
		 Index1 >= m_nIndexMaxCnt ||
		 Index2 >= m_nIndexMaxCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d, %d, %d] �ε����� �Ҵ�� �Ѱ�ġ�� �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiFieldID, m_nIndexMaxCnt, Index0, Index1, Index2 );
		return;
	}

	m_pIndexList[m_nIndexCnt++] = Index0;
	m_pIndexList[m_nIndexCnt++] = Index1;
	m_pIndexList[m_nIndexCnt++] = Index2;
}


#endif