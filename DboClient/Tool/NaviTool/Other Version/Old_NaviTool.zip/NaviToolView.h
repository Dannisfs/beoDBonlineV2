// NaviToolView.h : interface of the CNaviToolView class
//


#pragma once


class CNaviToolView : public CView
{
protected: // create from serialization only
	CNaviToolView();
	DECLARE_DYNCREATE(CNaviToolView)

// Attributes
public:
	CNaviToolDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CNaviToolView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in NaviToolView.cpp
inline CNaviToolDoc* CNaviToolView::GetDocument() const
   { return reinterpret_cast<CNaviToolDoc*>(m_pDocument); }
#endif
