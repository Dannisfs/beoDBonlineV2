#include "stdafx.h"
#include "DialogManager.h"

#include "CreateProjectDlg.h"
#include "ZoneInfoDlg.h"
#include "OptimizeWorldObjDlg.h"

#include "NaviProject.h"

#include "NaviEvent.h"


CDialogManager* g_pclDlgMng = NULL;


CDialogManager* CDialogManager::GetInstance( void )
{
	return g_pclDlgMng;
}


RwBool CDialogManager::CreateInstance( void )
{
	ASSERT( NULL == g_pclDlgMng );

	g_pclDlgMng = new CDialogManager;
	return g_pclDlgMng->Create();
}


void CDialogManager::DestroyInstance( void )
{
	if ( g_pclDlgMng )
	{
		g_pclDlgMng->Delete();
		delete g_pclDlgMng;
		g_pclDlgMng = NULL;
	}
}


CDialogManager::CDialogManager( void )
{
	m_pCreateProjectDlg = NULL;
	m_pZoneInfoDlg = NULL;
	m_pOptimizeWorldObjDlg = NULL;
}


CDialogManager::~CDialogManager( void )
{
}


bool CDialogManager::Create( void )
{
	LinkMsg( g_EventOpenCreateProjectDlg );

	LinkMsg( g_EventOpenZoneInfoDlg );
	LinkMsg( g_EventCloseZoneInfoDlg );

	LinkMsg( g_EventOpenOptimizedWorldObjectDlg );
	LinkMsg( g_EventCloseOptimizedWorldObjectDlg );

	return true;
}


void CDialogManager::Delete( void )
{
	UnLinkMsg( g_EventOpenCreateProjectDlg );

	UnLinkMsg( g_EventOpenZoneInfoDlg );
	UnLinkMsg( g_EventCloseZoneInfoDlg );

	UnLinkMsg( g_EventOpenOptimizedWorldObjectDlg );
	UnLinkMsg( g_EventCloseOptimizedWorldObjectDlg );
}


void CDialogManager::HandleEvents( RWS::CMsg &pMsg )
{
	if ( pMsg.Id == g_EventOpenCreateProjectDlg )
	{
		if ( m_pCreateProjectDlg ) return;

		if ( CNaviProject::GetInstance()->IsCreated() )
		{
			CString strMsg; strMsg.Format( "�̹� ������ ������Ʈ�� �����մϴ�"  );
			AfxMessageBox( strMsg );
			return;
		}

		m_pCreateProjectDlg = new CCreateProjectDlg;

		if ( IDOK == m_pCreateProjectDlg->DoModal() )
		{
			if ( !CNaviProject::GetInstance()->Create( m_pCreateProjectDlg->m_strProjName,
													   m_pCreateProjectDlg->m_strProjectFolder,
													   m_pCreateProjectDlg->m_dwWorldTblIdx,
													   m_pCreateProjectDlg->m_dwZoneId,
													   m_pCreateProjectDlg->m_strFieldPropertyFile,
													   m_pCreateProjectDlg->m_strTilePropertyFile ) )
			{
				CString strMsg; strMsg.Format( "[%s] ������Ʈ ������ �����߽��ϴ�", m_pCreateProjectDlg->m_strProjName );
				AfxMessageBox( strMsg );

				CNaviProject::GetInstance()->Delete();
			}

			delete m_pCreateProjectDlg;
			m_pCreateProjectDlg = NULL;
		}
	}
	else if ( pMsg.Id == g_EventOpenZoneInfoDlg )
	{
		if ( m_pZoneInfoDlg ) return;

		m_pZoneInfoDlg = new CZoneInfoDlg;

		if ( !m_pZoneInfoDlg->Create() )
		{
			delete m_pZoneInfoDlg;
			m_pZoneInfoDlg = NULL;
		}
	}
	else if ( pMsg.Id == g_EventCloseZoneInfoDlg )
	{
		if ( m_pZoneInfoDlg )
		{
			delete m_pZoneInfoDlg;
			m_pZoneInfoDlg = NULL;
		}
	}
	else if ( pMsg.Id == g_EventOpenOptimizedWorldObjectDlg )
	{
		if ( m_pOptimizeWorldObjDlg ) return;

		m_pOptimizeWorldObjDlg = new COptimizeWorldObjDlg;

		if ( !m_pOptimizeWorldObjDlg->Create() )
		{
			delete m_pOptimizeWorldObjDlg;
			m_pOptimizeWorldObjDlg = NULL;
		}
	}
	else if ( pMsg.Id == g_EventCloseOptimizedWorldObjectDlg )
	{
		if ( m_pOptimizeWorldObjDlg )
		{
			delete m_pOptimizeWorldObjDlg;
			m_pOptimizeWorldObjDlg = NULL;
		}
	}
}
