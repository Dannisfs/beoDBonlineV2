#include "stdafx.h"
#include "NaviToolModel.h"


CNaviToolModel::CNaviToolModel( void )
{
	m_pWorldProperty = NULL;

	m_uiModelProperty = 0;

	m_uiModelAtomicID = 0;
}


CNaviToolModel::~CNaviToolModel( void )
{
	Delete();
}


CNaviToolModel::sModelAtomic* CNaviToolModel::GetModelAtomic( unsigned int uiModelAtomicID )
{
	mapdef_ModelAtomicList::iterator it = m_defModelAtomicList.find( uiModelAtomicID );
	if ( it != m_defModelAtomicList.end() ) return it->second;
	return NULL;
}


unsigned int CNaviToolModel::CreateModelAtomic( unsigned int uiVertexCnt, unsigned int uiIndexCnt, const RwMatrix& matLocal )
{
	sModelAtomic* pModelAtomic = new sModelAtomic;

	RwMatrixCopy( &pModelAtomic->m_matLocal, &matLocal );
	pModelAtomic->m_uiVertexCnt = uiVertexCnt;
	pModelAtomic->m_pVertexList = new RwIm3DVertex[pModelAtomic->m_uiVertexCnt];
	pModelAtomic->m_uiIndexCnt = uiIndexCnt;
	pModelAtomic->m_pIndexList = new RwImVertexIndex[pModelAtomic->m_uiIndexCnt];

	if ( NULL == pModelAtomic->m_pVertexList || NULL == pModelAtomic->m_pIndexList )
	{
		if ( pModelAtomic->m_pVertexList ) delete [] pModelAtomic->m_pVertexList;
		if ( pModelAtomic->m_pIndexList ) delete [] pModelAtomic->m_pIndexList;

		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d] New ����", __FILE__, __FUNCTION__, __LINE__, pModelAtomic->m_uiVertexCnt, pModelAtomic->m_uiIndexCnt );
		return -1;
	}

	m_defModelAtomicList[m_uiModelAtomicID] = pModelAtomic;

	return m_uiModelAtomicID++;
}


void CNaviToolModel::DeleleteModelAtomic( unsigned int uiModelAtomicID )
{
	mapdef_ModelAtomicList::iterator it = m_defModelAtomicList.find( uiModelAtomicID );
	if ( it != m_defModelAtomicList.end() )
	{
		delete [] it->second->m_pVertexList;
		delete [] it->second->m_pIndexList;
		delete it->second;

		m_defModelAtomicList.erase( it );
	}
}


void CNaviToolModel::DeleteAllModelAtomics( void )
{
	mapdef_ModelAtomicList::iterator it = m_defModelAtomicList.begin();
	for ( ; it != m_defModelAtomicList.end(); ++it )
	{
		delete [] it->second->m_pVertexList;
		delete [] it->second->m_pIndexList;
		delete it->second;
	}
	m_defModelAtomicList.clear();
}


bool CNaviToolModel::Create( CNaviToolAttrs* pAttrs )
{
	if ( m_bCreated ) return true;

	CNaviToolAttrs_Model* pModelAttr = dynamic_cast< CNaviToolAttrs_Model* > ( pAttrs );
	if ( NULL == pModelAttr )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �߸��� �Ӽ� ������ �ԷµǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pAttrs ? typeid(pAttrs).name() : "NULL") );
		return false;
	}

	m_pWorldProperty = pModelAttr->pWorldProperty;
	m_strModelName = pModelAttr->szModelName;
	m_uiModelProperty = pModelAttr->uiModelProperty;

	return CNaviToolObject::Create( pAttrs );
}


void CNaviToolModel::Delete( void )
{
	DeleteAllModelAtomics();

	m_uiModelAtomicID = 0;

	m_uiModelProperty = 0;

	m_strModelName.Empty();

	m_pWorldProperty = NULL;

	CNaviToolObject::Delete();
}


void CNaviToolModel::Render( RwCamera* pCamera, const RwMatrix* pParentMatrix )
{
	if ( !m_bCreated ) return;

	RwMatrix matParent, matWorld;

	if ( pParentMatrix )
	{
		RwMatrixCopy( &matParent, pParentMatrix );
	}
	else
	{
		RwMatrixSetIdentity( &matParent );
	}

	RwRenderStateSet( rwRENDERSTATETEXTURERASTER, NULL );
	RwRenderStateSet( rwRENDERSTATESRCBLEND, (void*)rwBLENDONE );
	RwRenderStateSet( rwRENDERSTATEDESTBLEND, (void*)rwBLENDZERO );
	RwRenderStateSet( rwRENDERSTATEFOGENABLE, (void*)FALSE );

	RwD3D9SetRenderState( D3DRS_LIGHTING, FALSE );

	mapdef_ModelAtomicList::iterator it = m_defModelAtomicList.begin();
	for ( ; it != m_defModelAtomicList.end(); ++it )
	{
		sModelAtomic* pModelAtomic = it->second;

		RwMatrixMultiply( &matWorld, &pModelAtomic->m_matLocal, &matParent );

		if ( RwIm3DTransform( pModelAtomic->m_pVertexList, pModelAtomic->m_uiVertexCnt, &matWorld, rwIM3D_VERTEXXYZ|rwIM3D_VERTEXRGBA ) )
		{
			RwIm3DRenderIndexedPrimitive( rwPRIMTYPETRILIST, pModelAtomic->m_pIndexList, pModelAtomic->m_uiIndexCnt );

			RwIm3DEnd();
		}

	}
}
