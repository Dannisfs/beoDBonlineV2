#ifndef _NAVI_TOOL_WORLDPROPERTY_H_
#define _NAVI_TOOL_WORLDPROPERTY_H_


#include "NaviToolObject.h"


class CNaviToolWorldProperty : public CNaviToolObject
{

// Member variables
protected:
	// Attributes
	unsigned int						m_uiWorldTblIdx;

	RwV3d								m_v3WorldBegin;
	RwV3d								m_v3WorldEnd;

	unsigned int						m_uiFieldCnt;		// ���� �󿡼� ��� �ʵ��� ����
	float								m_fFieldSize;		// ���� �󿡼� �ϳ��� �ʵ��� ���� �Ǵ� ������ ���� ���� ũ��( �ʵ�� ����ü )

	unsigned int						m_uiTileCnt;		// ���� �󿡼� ��� Ÿ���� ����
	float								m_fTileSize;		// ���� �󿡼� �ϳ��� Ÿ���� ���� �Ǵ� ������ ���� ���� ũ��( Ÿ���� ����ü )

	// Updated values
	unsigned int*						m_pFieldProperty;
	unsigned int*						m_pTileProperty;


// Constructions and Destructions
public:
	CNaviToolWorldProperty( void );
	virtual ~CNaviToolWorldProperty( void );


// Operations
public:
	unsigned int						GetWorldTblIdx( void ) const;
	void								SetWorldTblIdx( unsigned int uiWorldTblIdx );

	void								GetWorldRgn( RwV3d& v3WorldBegin, RwV3d& v3WorldEnd ) const;
	void								SetWorldRgn( const RwV3d& v3WorldBegin, const RwV3d& v3WorldEnd );

	unsigned int						GetFieldCount( void ) const;
	void								SetFieldCount( unsigned int uiFieldCnt );

	float								GetFieldSize( void ) const;
	void								SetFieldSize( float fFieldSize );

	unsigned int						GetTileCount( void ) const;
	void								SetTileCount( unsigned int uiTileCnt );

	float								GetTileSize( void ) const;
	void								SetTileSize( float fTileSize );

	unsigned int						GetFieldProperty( unsigned int uiFieldID ) const;
	void								SetFieldProperty( unsigned int uiFieldID, unsigned int uiProp );

	unsigned int						GetTileProperty( unsigned int uiTileID ) const;
	void								SetTileProperty( unsigned int uiTileID, unsigned int uiProp );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );


	friend class CNaviToolObjectFactory;

};


inline unsigned int CNaviToolWorldProperty::GetWorldTblIdx( void ) const
{
	return m_uiWorldTblIdx;
}


inline void CNaviToolWorldProperty::SetWorldTblIdx( unsigned int uiWorldTblIdx )
{
	m_uiWorldTblIdx = uiWorldTblIdx;
}


inline void CNaviToolWorldProperty::GetWorldRgn( RwV3d& v3WorldBegin, RwV3d& v3WorldEnd ) const
{
	v3WorldBegin = m_v3WorldBegin;
	v3WorldEnd = m_v3WorldEnd;
}


inline void CNaviToolWorldProperty::SetWorldRgn( const RwV3d& v3WorldBegin, const RwV3d& v3WorldEnd )
{
	m_v3WorldBegin = v3WorldBegin;
	m_v3WorldEnd = v3WorldEnd;
}


inline unsigned int CNaviToolWorldProperty::GetFieldCount( void ) const
{
	return m_uiFieldCnt;
}


inline void CNaviToolWorldProperty::SetFieldCount( unsigned int uiFieldCnt )
{
	m_uiFieldCnt = uiFieldCnt;
}


inline float CNaviToolWorldProperty::GetFieldSize( void ) const
{
	return m_fFieldSize;
}


inline void CNaviToolWorldProperty::SetFieldSize( float fFieldSize )
{
	m_fFieldSize = fFieldSize;
}


inline unsigned int CNaviToolWorldProperty::GetTileCount( void ) const
{
	return m_uiTileCnt;
}


inline void CNaviToolWorldProperty::SetTileCount( unsigned int uiTileCnt )
{
	m_uiTileCnt = uiTileCnt;
}


inline float CNaviToolWorldProperty::GetTileSize( void ) const
{
	return m_fTileSize;
}


inline void CNaviToolWorldProperty::SetTileSize( float fTileSize )
{
	m_fTileSize = fTileSize;
}


inline unsigned int CNaviToolWorldProperty::GetFieldProperty( unsigned int uiFieldID ) const
{
	if ( uiFieldID >= m_uiFieldCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� �ʵ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiWorldTblIdx, m_uiFieldCnt, uiFieldID );
		return 0;
	}

	return m_pFieldProperty[m_uiFieldCnt];
}


inline void CNaviToolWorldProperty::SetFieldProperty( unsigned int uiFieldID, unsigned int uiProp )
{
	if ( uiFieldID >= m_uiFieldCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� �ʵ� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiWorldTblIdx, m_uiFieldCnt, uiFieldID );
		return;
	}

	m_pFieldProperty[m_uiFieldCnt] = uiProp;
}


inline unsigned int CNaviToolWorldProperty::GetTileProperty( unsigned int uiTileID ) const
{
	if ( uiTileID >= m_uiTileCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� Ÿ�� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiWorldTblIdx, m_uiTileCnt, uiTileID );
		return 0;
	}

	return m_pTileProperty[uiTileID];
}


inline void CNaviToolWorldProperty::SetTileProperty( unsigned int uiTileID, unsigned int uiProp )
{
	if ( uiTileID >= m_uiTileCnt )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d, %d, %d] �ε����� Ÿ�� �ִ� ������ �Ѿ���ϴ�", __FILE__, __FUNCTION__, __LINE__, m_uiWorldTblIdx, m_uiTileCnt, uiTileID );
		return;
	}

	m_pTileProperty[uiTileID] = uiProp;
}


#endif