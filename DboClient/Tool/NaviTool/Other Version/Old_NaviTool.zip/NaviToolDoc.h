// NaviToolDoc.h : interface of the CNaviToolDoc class
//


#pragma once


class CNaviToolDoc : public CDocument
{
protected: // create from serialization only
	CNaviToolDoc();
	DECLARE_DYNCREATE(CNaviToolDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CNaviToolDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};
