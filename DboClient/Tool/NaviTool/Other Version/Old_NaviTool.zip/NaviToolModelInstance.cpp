#include "stdafx.h"
#include "NaviToolModelInstance.h"

#include "NaviToolModel.h"


CNaviToolModelInstance::CNaviToolModelInstance( void )
{
	m_pWorldProperty = NULL;
	RwMatrixSetIdentity( &m_matLocal );
}


CNaviToolModelInstance::~CNaviToolModelInstance( void )
{
	Delete();
}


bool CNaviToolModelInstance::Create( CNaviToolAttrs* pAttrs )
{
	if ( m_bCreated ) return true;

	CNaviToolAttrs_ModelInstance* pModelInst = dynamic_cast< CNaviToolAttrs_ModelInstance* > ( pAttrs );
	if ( NULL == pModelInst )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �߸��� �Ӽ� ������ �ԷµǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pAttrs ? typeid(pAttrs).name() : "NULL") );
		return false;
	}

	m_pWorldProperty = pModelInst->pWorldProperty;
	RwMatrixCopy( &m_matLocal, &pModelInst->matLocal );

	return CNaviToolObject::Create( pAttrs );
}


void CNaviToolModelInstance::Delete( void )
{
	RwMatrixSetIdentity( &m_matLocal );

	m_pWorldProperty = NULL;

	CNaviToolObject::Delete();
}


void CNaviToolModelInstance::Render( RwCamera* pCamera, const RwMatrix* pParentMatrix )
{
	if ( !m_bCreated ) return;

	RwMatrix matWorld;

	if ( pParentMatrix )
	{
		RwMatrixMultiply( &matWorld, &m_matLocal, pParentMatrix );
	}
	else
	{
		RwMatrixSetIdentity( &matWorld );
	}

	vecdef_ChildListIT it = BeginChild();
	for ( ; it != EndChild(); ++it )
	{
		CNaviToolModel* pModel = dynamic_cast< CNaviToolModel* > ( *it );

		if ( pModel )
		{
			pModel->Render( pCamera, &matWorld );
		}
		else
		{
			CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] Model instance�� �߸��� �ڽ��� ��ϵǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pModel ? typeid(pModel).name() : "NULL") );
		}
	}
}
