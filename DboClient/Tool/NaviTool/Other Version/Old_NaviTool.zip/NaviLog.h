#ifndef _NAVI_LOG_H_
#define _NAVI_LOG_H_


class CNaviLog
{

// Static
public:
	static CNaviLog*					GetInstance( void );


// Declarations
public:
	typedef std::vector<CString> vecdef_LogList;
	typedef vecdef_LogList::iterator vecdef_LogListIT;


// Member variables
protected:
	vecdef_LogList						m_defLogList;


// Constructions and Destructions
protected:
	CNaviLog( void );
	~CNaviLog( void );


// Operations
public:
	vecdef_LogListIT					BeginLog( void );
	vecdef_LogListIT					EndLog( void );

	void								AddLog( const char* pLog, ... );
	void								ClearLogs( void );

};


#endif