// CreateProjectDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "CreateProjectDlg.h"

#include "DirDialog.h"


// CCreateProjectDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CCreateProjectDlg, CDialog)

CCreateProjectDlg::CCreateProjectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateProjectDlg::IDD, pParent)
	, m_strProjName(_T(""))
	, m_strProjectFolder(_T(""))
	, m_dwWorldTblIdx(0xffffffff)
	, m_dwZoneId(0xffffffff)
	, m_strFieldPropertyFile(_T(""))
	, m_strTilePropertyFile(_T(""))
{

}

CCreateProjectDlg::~CCreateProjectDlg()
{
}

void CCreateProjectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_CREATE_PROJECT_WORLD_PROJECTNAME_EDIT, m_strProjName);
	DDX_Text(pDX, IDC_CREATE_PROJECT_FOLDER_EDIT, m_strProjectFolder);
	DDX_Text(pDX, IDC_CREATE_PROJECT_WORLD_TBLIDX_EDIT, m_dwWorldTblIdx);
	DDX_Text(pDX, IDC_CREATE_PROJECT_WORLD_ZONEID_EDIT, m_dwZoneId);
	DDX_Text(pDX, IDC_CREATE_PROJECT_WORLD_FIELD_PROP_FILE_EDIT, m_strFieldPropertyFile);
	DDX_Text(pDX, IDC_CREATE_PROJECT_WORLD_TILE_PROP_FILE_EDIT, m_strTilePropertyFile);
}


BEGIN_MESSAGE_MAP(CCreateProjectDlg, CDialog)
	ON_BN_CLICKED(IDC_CREATE_PROJECT_FOLDER_BTN, &CCreateProjectDlg::OnBnClickedCreateProjectFolderBtn)
	ON_BN_CLICKED(IDC_CREATE_PROJECT_WORLD_FIELD_PROP_FILE_BTN, &CCreateProjectDlg::OnBnClickedCreateProjectWorldFieldPropFileBtn)
	ON_BN_CLICKED(IDC_CREATE_PROJECT_WORLD_TILE_PROP_FILE_BTN, &CCreateProjectDlg::OnBnClickedCreateProjectWorldTilePropFileBtn)
END_MESSAGE_MAP()


// CCreateProjectDlg �޽��� ó�����Դϴ�.

void CCreateProjectDlg::OnBnClickedCreateProjectFolderBtn()
{
	CDirDialog clDir;

	if ( IDOK == clDir.DoModal() )
	{
		UpdateData( TRUE );
		m_strProjectFolder = clDir.GetPath();
		UpdateData( FALSE );
	}
}

void CCreateProjectDlg::OnBnClickedCreateProjectWorldFieldPropFileBtn()
{
	CFileDialog clFile( TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, "Field property file (*.*)|*.*|", NULL, 0 );
	if ( IDOK == clFile.DoModal() )
	{
		UpdateData( TRUE );
		m_strFieldPropertyFile = clFile.GetPathName();
		UpdateData( FALSE );
	}
}

void CCreateProjectDlg::OnBnClickedCreateProjectWorldTilePropFileBtn()
{
	CFileDialog clFile( TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, "Tile property file (*.*)|*.*|", NULL, 0 );
	if ( IDOK == clFile.DoModal() )
	{
		UpdateData( TRUE );
		m_strTilePropertyFile = clFile.GetPathName();
		UpdateData( FALSE );
	}
}
