// NaviTool.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "MainFrm.h"

#include "NaviToolDoc.h"
#include "NaviToolView.h"

#include "NaviToolStatic.h"

#include "NaviEventHandler.h"
#include "DialogManager.h"
#include "NaviRenderingFramework.h"
#include "NaviPathEngine.h"

#include "NaviToolWorldView.h"
#include "NaviToolPathView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CNaviToolApp

BEGIN_MESSAGE_MAP(CNaviToolApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, &CNaviToolApp::OnAppAbout)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, &CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, &CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, &CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()


// CNaviToolApp construction

CNaviToolApp::CNaviToolApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CNaviToolApp object

CNaviToolApp theApp;


// CNaviToolApp initialization

BOOL CNaviToolApp::InitInstance()
{
	GetCurrentDirectory( NTL_MAX_DIR_PATH, g_szWorkingFolder );

	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));
	LoadStdProfileSettings(4);  // Load standard INI file options (including MRU)
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CNaviToolDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CNaviToolView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);


	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);


	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// Rendering system ����
	if ( !CNaviRenderingFramework::GetInstance()->CreateRenderingSystem( ((CMainFrame*)m_pMainWnd)->GetActiveView()->GetSafeHwnd() ) )
	{
		return FALSE;
	}

	// Path engine ����
	if ( !CNaviPathEngine::GetInstance()->Create() )
	{
		return FALSE;
	}

	// The one and only window has been initialized, so show and update it
	m_pMainWnd->ShowWindow(SW_SHOWMAXIMIZED);
	m_pMainWnd->UpdateWindow();
	((CMainFrame*)m_pMainWnd)->FitToCenterSplitterWnd();

	if ( !((CNaviToolWorldView*)((CMainFrame*)m_pMainWnd)->m_wndSplitter.GetPane( 0, 0 ))->Build() )
	{
		return FALSE;
	}

	if ( !((CNaviToolPathView*)((CMainFrame*)m_pMainWnd)->m_wndSplitter.GetPane( 0, 1 ))->Build() )
	{
		return FALSE;
	}

	// Event handler ����
	if ( !CNaviEventHandler::CreateInstance() )
	{
		return FALSE;
	}

	// Dialog manager ����
	if ( !CDialogManager::CreateInstance() )
	{
		return FALSE;
	}

	// call DragAcceptFiles only if there's a suffix
	//  In an SDI app, this should occur after ProcessShellCommand

	return TRUE;
}

// CNaviToolApp message handlers

// App command to run the dialog
void CNaviToolApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

BOOL CNaviToolApp::OnIdle(LONG lCount)
{
	CNaviRenderingFramework::GetInstance()->UpdateRenderingSystem();

	return TRUE;
}

int CNaviToolApp::ExitInstance()
{
	// Dialog manager ����
	CDialogManager::DestroyInstance();

	// Event handler ����
	CNaviEventHandler::DestroyInstance();

	// Path engine ����
	CNaviPathEngine::GetInstance()->Delete();

	// Rendering system ����
	CNaviRenderingFramework::GetInstance()->DeleteRenderingSystem();

	return CWinApp::ExitInstance();
}
