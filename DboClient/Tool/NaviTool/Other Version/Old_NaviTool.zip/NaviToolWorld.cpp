#include "stdafx.h"
#include "NaviToolWorld.h"


CNaviToolWorld::CNaviToolWorld( void )
{
	m_pWorldProperty = NULL;
	m_uiWorldTblIdx = 0xffffffff;
}


CNaviToolWorld::~CNaviToolWorld( void )
{
	Delete();
}


bool CNaviToolWorld::Create( CNaviToolAttrs* pAttrs )
{
	if ( m_bCreated ) return true;

	CNaviToolAttrs_World* pWorldAttr = dynamic_cast< CNaviToolAttrs_World* > ( pAttrs );
	if ( NULL == pWorldAttr )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �߸��� �Ӽ� ������ �ԷµǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pAttrs ? typeid(pAttrs).name() : "NULL") );
		return false;
	}

	m_pWorldProperty = pWorldAttr->pWorldProperty;
	m_uiWorldTblIdx = pWorldAttr->uiWorldTblIdx;

	return CNaviToolObject::Create( pAttrs );
}

void CNaviToolWorld::Delete( void )
{
	m_uiWorldTblIdx = 0xffffffff;
	m_pWorldProperty = NULL;

	CNaviToolObject::Delete();
}
