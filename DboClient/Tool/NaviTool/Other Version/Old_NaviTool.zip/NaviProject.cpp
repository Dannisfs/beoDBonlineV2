#include "stdafx.h"
#include "NaviProject.h"
#include "NaviToolDefine.h"

#include "NaviRenderingFramework.h"

#include "NaviMainWorldProcess.h"


CNaviProject CNaviProject::s_clProject;


CNaviProject* CNaviProject::GetInstance( void )
{
	return &s_clProject;
}


CNaviProject::CNaviProject( void )
{
	m_bCreated = false;

	m_pWorld = NULL;
}


CNaviProject::~CNaviProject( void )
{
}


bool CNaviProject::Create( const char* pProjName, const char* pProjFolderName, unsigned int uiWorldTblIdx, unsigned int uiZoneID, const char* pFieldPropFile, const char* pTilePropFile )
{
	//////////////////////////////////////////////////////////////////////////
	// �Ķ���� ����
	//////////////////////////////////////////////////////////////////////////

	m_strProjectName = pProjName;
	m_strProjectFolderName = pProjFolderName;
	m_uiWorldTblIdx = uiWorldTblIdx;
	m_uiZoneID = uiZoneID;
	m_strFieldPropFile = pFieldPropFile;
	m_strTilePropFile = pTilePropFile;

	//////////////////////////////////////////////////////////////////////////
	// ���丮 �� ���� �̸� ����
	//////////////////////////////////////////////////////////////////////////

	CString strProjectDir = pProjFolderName;
	strProjectDir += pProjName;

	CString strProjectFileName = strProjectDir;
	strProjectFileName += "\\";
	strProjectFileName += pProjName;
	strProjectFileName += NAVI_TOOL_PROJECT_FILE_EXT;

	//////////////////////////////////////////////////////////////////////////
	// �ش� ������Ʈ�� �����ϴ��� �˻��Ѵ�
	//////////////////////////////////////////////////////////////////////////

	char szDir[4096];
	GetCurrentDirectory( 4096, szDir );

	if ( SetCurrentDirectory( strProjectDir ) )
	{
		SetCurrentDirectory( szDir );

		CString strMsg; strMsg.Format( "[%s] ������Ʈ�� �̹� �����մϴ�", pProjName );
		AfxMessageBox( strMsg );

		Delete();

		return false;
	}
	else
	{
		SetCurrentDirectory( szDir );
	}

	//////////////////////////////////////////////////////////////////////////
	// ������Ʈ ������ �����
	//////////////////////////////////////////////////////////////////////////
	
	if ( !CreateDirectory( strProjectDir, NULL ) )
	{
		CString strMsg; strMsg.Format( "[%s] �ش� ������ ���� �� �����ϴ�", strProjectDir );
		AfxMessageBox( strMsg );

		Delete();

		return false;
	}

	//////////////////////////////////////////////////////////////////////////
	// �Ӽ� ������ �ε��Ѵ�
	//////////////////////////////////////////////////////////////////////////

	if ( !CreateFieldProperty( pFieldPropFile ) )
	{
		CString strMsg; strMsg.Format( "[%s] �ʵ� ������ �о���� �� �����ϴ�", pFieldPropFile );
		AfxMessageBox( strMsg );

		Delete();

		return false;
	}

	if ( !CreateTileProperty( pTilePropFile ) )
	{
		CString strMsg; strMsg.Format( "[%s] Ÿ�� ������ �о���� �� �����ϴ�", pTilePropFile );
		AfxMessageBox( strMsg );

		Delete();

		return false;
	}

	//////////////////////////////////////////////////////////////////////////
	// ���带 �����Ѵ�
	//////////////////////////////////////////////////////////////////////////

	CNaviMainWorldProcess* pMainWorldProcess = (CNaviMainWorldProcess*) CNaviRenderingFramework::GetInstance()->FindProcess( eNAVI_PROCESS_ID_MAIN_PROCESS );
	if ( NULL == pMainWorldProcess )
	{
		CString strMsg; strMsg.Format( "���� ���� ���μ����� ���� ���� �ʾҽ��ϴ�" );
		AfxMessageBox( strMsg );

		Delete();
		return false;
	}

	if ( !pMainWorldProcess->CreateWorld( uiWorldTblIdx ) )
	{
		CString strMsg; strMsg.Format( "[%d] �ش� ���带 ������ �� �����ϴ�", uiWorldTblIdx );
		AfxMessageBox( strMsg );

		Delete();
		return false;
	}

	//////////////////////////////////////////////////////////////////////////
	// ���带 Building�Ѵ�
	//////////////////////////////////////////////////////////////////////////

	RwV3d v3WorldBegin; v3WorldBegin.x = v3WorldBegin.z = (float)-dGET_WORLD_PARAM()->WorldSizeHalf; v3WorldBegin.y = 0.f;
	RwV3d v3WorldEnd; v3WorldEnd.x = v3WorldEnd.z = (float)dGET_WORLD_PARAM()->WorldSizeHalf; v3WorldEnd.y = 0.f;

	m_pWorld = m_clObjectBuilder.BuildFromWorldData( uiWorldTblIdx,
													 uiZoneID,
													 m_nFieldCnt,
													 m_pFieldBuffer,
													 m_nTileCnt,
													 m_pTileBuffer,
													 dGET_WORLD_PARAM(),
													 pMainWorldProcess->GetWorldEntity() );

	//////////////////////////////////////////////////////////////////////////
	// �Ӽ� ������ �����Ѵ�
	//////////////////////////////////////////////////////////////////////////

	DeleteTileProperty();

	DeleteFieldProperty();

	//////////////////////////////////////////////////////////////////////////
	// ������Ʈ ������ �����Ѵ�
	//////////////////////////////////////////////////////////////////////////

	//if ( !Export( strProjectFileName ) )
	//{
	//	CString strMsg; strMsg.Format( "[%s] ������Ʈ ���� ���� ����", strProjectFileName );
	//	AfxMessageBox( strMsg );

	//	Delete();

	//	return false;
	//}

	m_bCreated = true;

	return true;
}


void CNaviProject::Delete( void )
{
	m_bCreated = false;

	m_pWorld = NULL;
}


bool CNaviProject::Import( const char* pProjectFileName )
{
	return true;
}


bool CNaviProject::Export( const char* pProjectFileName )
{
	FILE* pFile = fopen( pProjectFileName, "rb" );
	if ( pFile )
	{
		CString strMsg; strMsg.Format( "[%s] Open ����", pProjectFileName );
		AfxMessageBox( strMsg );

		return false;
	}

	// Header ����
	fwrite( NAVI_TOOL_PROJECT_HEADER, strlen(NAVI_TOOL_PROJECT_HEADER), 1, pFile );

	// Version ����
	fwrite( NAVI_TOOL_PROJECT_VERSION, sizeof( DWORD ), 1, pFile );

	fclose( pFile );

	return true;
}


bool CNaviProject::CreateFieldProperty( const char* pFileName )
{
	FILE* pFile = fopen( pFileName, "r" );
	if ( NULL == pFile ) return false;

	// Field �� ũ�⸦ �о� ����
	fread( &m_nFieldCnt, sizeof(m_nFieldCnt), 1, pFile );

	m_pFieldBuffer = new unsigned int [m_nFieldCnt];

	for ( int i = 0; i < m_nFieldCnt; ++i )
	{
		fread( &m_pFieldBuffer[i], sizeof(unsigned int), 1, pFile );
		m_pFieldBuffer[i] /= 1000;	// Zone ID�� ��� ���� ���
	}

	fclose( pFile );

	return true;
}


void CNaviProject::DeleteFieldProperty( void )
{
	m_nFieldCnt = 0;

	if ( m_pFieldBuffer )
	{
		delete [] m_pFieldBuffer;
		m_pFieldBuffer = NULL;
	}
}


bool CNaviProject::CreateTileProperty( const char* pFileName )
{
	FILE* pFile = fopen( pFileName, "r" );
	if ( NULL == pFile ) return false;

	// Field �� ũ�⸦ �о� ����
	fread( &m_nTileCnt, sizeof(m_nTileCnt), 1, pFile );

	// Field�� Ÿ�� ���� ���
	m_nTileCnt *= NAVI_TOOL_TILE_PER_FIELD;

	m_pTileBuffer = new unsigned int [m_nTileCnt];

	for ( int i = 0; i < m_nTileCnt / NAVI_TOOL_TILE_PER_FIELD; ++i )
	{
		fread( &m_pTileBuffer[i * NAVI_TOOL_TILE_PER_FIELD], sizeof(unsigned int) * NAVI_TOOL_TILE_PER_FIELD, 1, pFile );
	}

	fclose( pFile );

	return true;
}


void CNaviProject::DeleteTileProperty( void )
{
	m_nTileCnt = 0;

	if ( m_pTileBuffer )
	{
		delete [] m_pTileBuffer;
		m_pTileBuffer = NULL;
	}
}