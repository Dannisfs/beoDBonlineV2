// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "NaviTool.h"

#include "MainFrm.h"

#include "NaviToolWorldView.h"
#include "NaviToolPathView.h"

#include "NaviEvent.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(XTP_ID_CUSTOMIZE, OnCustomize)
	ON_MESSAGE(XTPWM_DOCKINGPANE_NOTIFY, OnDockingPaneNotify)
	ON_COMMAND(ID_FILE_CREATEPROJECT, &CMainFrame::OnFileCreateproject)
	ON_COMMAND(ID_FILE_OPENPROJECT, &CMainFrame::OnFileOpenproject)
	ON_COMMAND(ID_FILE_CLOSEPROJECT, &CMainFrame::OnFileCloseproject)
	ON_COMMAND(ID_VIEW_OPENZONEVIEWDIALOG, &CMainFrame::OnViewOpenZoneviewdialog)
	ON_COMMAND(ID_VIEW_CLOSEZONEVIEWDIALOG, &CMainFrame::OnViewCloseZoneviewdialog)
	ON_COMMAND(ID_VIEW_OPENOBJECTDIALOG, &CMainFrame::OnViewOpenObjectdialog)
	ON_COMMAND(ID_VIEW_CLOSEOBJECTDIALOG, &CMainFrame::OnViewCloseObjectdialog)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

static UINT uHideCmds[] =
{
	ID_FILE_PRINT,
	ID_FILE_PRINT_PREVIEW,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}


void CMainFrame::FitToCenterSplitterWnd( void )
{
	CRect rtRgn;
	GetClientRect( &rtRgn );
	m_wndSplitter.SetColumnInfo( 0, rtRgn.Width()/2, 0 );
	m_wndSplitter.SetColumnInfo( 1, rtRgn.Width()/2, 0 );

	m_wndSplitter.RecalcLayout();
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;


	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// Initialize the command bars
	if (!InitCommandBars())
		return -1;

	// Get a pointer to the command bars object.
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if(pCommandBars == NULL)
	{
		TRACE0("Failed to create command bars object.\n");
		return -1;      // fail to create
	}

	// Add the menu bar
	CXTPCommandBar* pMenuBar = pCommandBars->SetMenu(
		_T("Menu Bar"), IDR_MAINFRAME);
	if(pMenuBar == NULL)
	{
		TRACE0("Failed to create menu bar.\n");
		return -1;      // fail to create
	}

	// Create ToolBar
	CXTPToolBar* pToolBar = (CXTPToolBar*)
		pCommandBars->Add(_T("Standard"), xtpBarTop);
	if (!pToolBar || !pToolBar->LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;
	}

	// Set Office 2003 Theme
	CXTPPaintManager::SetTheme(xtpThemeOffice2003);

	// Hide array of commands
	pCommandBars->HideCommands(uHideCmds, _countof(uHideCmds));

	// Set "Always Show Full Menus" option to the FALSE
	pCommandBars->GetCommandBarsOptions()->bAlwaysShowFullMenus = FALSE;

	pCommandBars->GetShortcutManager()->SetAccelerators(IDR_MAINFRAME);

	// Load the previous state for toolbars and menus.
	LoadCommandBars(_T("CommandBars"));

	// Initialize the docking pane manager and set the
	// initial them for the docking panes.  Do this only after all
	// control bars objects have been created and docked.
	m_paneManager.InstallDockingPanes(this);
	// Set Office 2003 Theme
	m_paneManager.SetTheme(xtpPaneThemeOffice2003);

	// Load the previous state for docking panes.
	CXTPDockingPaneLayout layoutNormal(&m_paneManager);
	if (layoutNormal.Load(_T("NormalLayout")))
	{
		m_paneManager.SetLayout(&layoutNormal);
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		 | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE | WS_SYSMENU;

	cs.style |= WS_CLIPCHILDREN|WS_CLIPSIBLINGS;
	return TRUE;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	if ( !m_wndSplitter.CreateStatic(this, 1, 2) )
	{
		return FALSE;
	}

	if ( !m_wndSplitter.CreateView( 0, 0, RUNTIME_CLASS( CNaviToolWorldView ), CSize( 0, 0 ), pContext ) )
	{
		return FALSE;
	}

	if ( !m_wndSplitter.CreateView( 0, 1, RUNTIME_CLASS( CNaviToolPathView ), CSize( 0, 0 ), pContext ) )
	{
		return FALSE;
	}

	CRect rtRgn;
	GetClientRect( &rtRgn );
	m_wndSplitter.SetColumnInfo( 0, rtRgn.Width()/2, 0 );
	m_wndSplitter.SetColumnInfo( 1, rtRgn.Width()/2, 0 );

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers




void CMainFrame::OnClose()
{
	// Save the current state for toolbars and menus.
	SaveCommandBars(_T("CommandBars"));

	// Save the current state for docking panes.
	CXTPDockingPaneLayout layoutNormal(&m_paneManager);
	m_paneManager.GetLayout(&layoutNormal);
	layoutNormal.Save(_T("NormalLayout"));

	CFrameWnd::OnClose();
}


void CMainFrame::OnCustomize()
{
	// Get a pointer to the command bars object.
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if(pCommandBars != NULL)
	{
		// Instanciate the customize dialog object.
		CXTPCustomizeSheet dlg(pCommandBars);

		// Add the keyboard page to the customize dialog.
		CXTPCustomizeKeyboardPage pageKeyboard(&dlg);
		dlg.AddPage(&pageKeyboard);
		pageKeyboard.AddCategories(IDR_MAINFRAME);

		// Add the options page to the customize dialog.
		CXTPCustomizeOptionsPage pageOptions(&dlg);
		dlg.AddPage(&pageOptions);

		// Add the commands page to the customize dialog.
		CXTPCustomizeCommandsPage* pCommands = dlg.GetCommandsPage();
		pCommands->AddCategories(IDR_MAINFRAME);

		// Use the command bar manager to initialize the
		// customize dialog.
		pCommands->InsertAllCommandsCategory();
		pCommands->InsertBuiltInMenus(IDR_MAINFRAME);
		pCommands->InsertNewMenuCategory();

		// Dispaly the dialog.
		dlg.DoModal();
	}
}

LRESULT CMainFrame::OnDockingPaneNotify(WPARAM wParam, LPARAM lParam)
{
	return FALSE;
}

void CMainFrame::OnFileCreateproject()
{
	sEventOpenCreateProjectDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventOpenCreateProjectDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}

void CMainFrame::OnFileOpenproject()
{
}

void CMainFrame::OnFileCloseproject()
{
}

void CMainFrame::OnViewOpenZoneviewdialog()
{
	sEventOpenZoneInfoDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventOpenZoneInfoDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}

void CMainFrame::OnViewCloseZoneviewdialog()
{
	sEventCloseZoneInfoDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventCloseZoneInfoDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}

void CMainFrame::OnViewOpenObjectdialog()
{
	sEventOpenOptimizedWorldObjectDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventOpenOptimizedWorldObjectDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}

void CMainFrame::OnViewCloseObjectdialog()
{
	sEventCloseOptimizedWorldObjectDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventCloseOptimizedWorldObjectDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}
