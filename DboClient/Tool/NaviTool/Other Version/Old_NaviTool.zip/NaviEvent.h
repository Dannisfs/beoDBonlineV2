#ifndef _NAVI_EVENT_H_
#define _NAVI_EVENT_H_


#include "ceventhandler.h"


//////////////////////////////////////////////////////////////////////////

struct sEventOpenCreateProjectDlg
{
};

extern RWS::CEventId g_EventOpenCreateProjectDlg;

//////////////////////////////////////////////////////////////////////////

struct sEventOpenZoneInfoDlg
{
};

extern RWS::CEventId g_EventOpenZoneInfoDlg;

struct sEventCloseZoneInfoDlg
{
};

extern RWS::CEventId g_EventCloseZoneInfoDlg;

//////////////////////////////////////////////////////////////////////////

struct sEventOpenOptimizedWorldObjectDlg
{
};

extern RWS::CEventId g_EventOpenOptimizedWorldObjectDlg;

struct sEventCloseOptimizedWorldObjectDlg
{
};

extern RWS::CEventId g_EventCloseOptimizedWorldObjectDlg;

//////////////////////////////////////////////////////////////////////////


#endif