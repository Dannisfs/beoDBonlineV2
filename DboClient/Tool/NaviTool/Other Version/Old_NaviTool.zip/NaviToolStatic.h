#ifndef _NAVI_STATIC_H_
#define _NAVI_STATIC_H_


extern char g_szWorkingFolder[4096];


#endif