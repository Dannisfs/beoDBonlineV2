// NaviToolPathView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "NaviToolPathView.h"

#include "NaviPathProcess.h"


// CNaviToolPathView

IMPLEMENT_DYNCREATE(CNaviToolPathView, CView)

CNaviToolPathView::CNaviToolPathView()
{
	m_pProcess = new CNaviPathProcess( this );
}

CNaviToolPathView::~CNaviToolPathView()
{
	if ( m_pProcess )
	{
		delete m_pProcess;
		m_pProcess = NULL;
	}
}

bool CNaviToolPathView::Build( void )
{
	return m_pProcess->Create();
}

BEGIN_MESSAGE_MAP(CNaviToolPathView, CView)
END_MESSAGE_MAP()


// CNaviToolPathView �׸����Դϴ�.

void CNaviToolPathView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.
}


// CNaviToolPathView �����Դϴ�.

#ifdef _DEBUG
void CNaviToolPathView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CNaviToolPathView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CNaviToolPathView �޽��� ó�����Դϴ�.
BOOL CNaviToolPathView::PreTranslateMessage(MSG* pMsg)
{
	if ( m_pProcess )
	{
		m_pProcess->WindowProc( pMsg->hwnd, pMsg->message, pMsg->wParam, pMsg->lParam );
	}

	return CView::PreTranslateMessage(pMsg);
}
