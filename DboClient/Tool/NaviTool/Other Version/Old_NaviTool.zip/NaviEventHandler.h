#ifndef _NAVI_EVENTHANDLER_H_
#define _NAVI_EVENTHANDLER_H_


#include "NaviEvent.h"


class CNaviEventHandler : public RWS::CEventHandler
{

public:
	static CNaviEventHandler* GetInstance( void );
	static RwBool CreateInstance( void );
	static void DestroyInstance( void );

public:
	CNaviEventHandler( void );
	~CNaviEventHandler( void );


public:
	RwBool								Create( void );
	void								Destroy( void );

	virtual void						HandleEvents( RWS::CMsg &pMsg );

};



#endif
