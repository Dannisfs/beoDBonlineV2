#pragma once
#include "afxwin.h"
#include "resource.h"


// CCreateProjectDlg ��ȭ �����Դϴ�.

class CCreateProjectDlg : public CDialog
{
	DECLARE_DYNAMIC(CCreateProjectDlg)

public:
	CCreateProjectDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CCreateProjectDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_CREATE_PROJECT_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CString m_strProjName;
	CString m_strProjectFolder;
	DWORD m_dwWorldTblIdx;
	DWORD m_dwZoneId;
	CString m_strFieldPropertyFile;
	CString m_strTilePropertyFile;

public:
	afx_msg void OnBnClickedCreateProjectFolderBtn();
	afx_msg void OnBnClickedCreateProjectWorldFieldPropFileBtn();
	afx_msg void OnBnClickedCreateProjectWorldTilePropFileBtn();
};
