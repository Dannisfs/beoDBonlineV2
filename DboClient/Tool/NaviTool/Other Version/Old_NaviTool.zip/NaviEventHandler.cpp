#include "stdafx.h"
#include "NaviEventHandler.h"


static CNaviEventHandler* g_pclEventHandler = NULL;


CNaviEventHandler* CNaviEventHandler::GetInstance( void )
{
	return g_pclEventHandler;
}

RwBool CNaviEventHandler::CreateInstance( void )
{
	ASSERT( NULL == g_pclEventHandler );

	g_pclEventHandler = new CNaviEventHandler;
	return g_pclEventHandler->Create();
}

void CNaviEventHandler::DestroyInstance( void )
{
	if ( g_pclEventHandler )
	{
		g_pclEventHandler->Destroy();
		delete g_pclEventHandler;
		g_pclEventHandler = NULL;
	}
}


CNaviEventHandler::CNaviEventHandler( void )
{
}


CNaviEventHandler::~CNaviEventHandler( void )
{
}


RwBool CNaviEventHandler::Create( void )
{
	RegisterMsg( g_EventOpenCreateProjectDlg, "g_EventOpenCreateProjectDlg", "sEventOpenCreateProjectDlg");

	RegisterMsg( g_EventOpenZoneInfoDlg, "g_EventOpenZoneInfoDlg", "sEventOpenZoneInfoDlg");
	RegisterMsg( g_EventCloseZoneInfoDlg, "g_EventCloseZoneInfoDlg", "sEventCloseZoneInfoDlg");

	RegisterMsg( g_EventOpenOptimizedWorldObjectDlg, "g_EventOpenOptimizedWorldObjectDlg", "sEventOpenOptimizedWorldObjectDlg");
	RegisterMsg( g_EventCloseOptimizedWorldObjectDlg, "g_EventCloseOptimizedWorldObjectDlg", "sEventCloseOptimizedWorldObjectDlg");

	return TRUE;
}


void CNaviEventHandler::Destroy( void )
{
	UnRegisterMsg( g_EventOpenCreateProjectDlg );

	UnRegisterMsg( g_EventOpenZoneInfoDlg );
	UnRegisterMsg( g_EventCloseZoneInfoDlg );

	UnRegisterMsg( g_EventOpenOptimizedWorldObjectDlg );
	UnRegisterMsg( g_EventCloseOptimizedWorldObjectDlg );
}


void CNaviEventHandler::HandleEvents( RWS::CMsg &pMsg )
{
}


