#ifndef _NAVI_DIALOGMANAGER_H_
#define _NAVI_DIALOGMANAGER_H_


#include "ceventhandler.h"


class CCreateProjectDlg;
class CZoneInfoDlg;
class COptimizeWorldObjDlg;


class CDialogManager : public RWS::CEventHandler
{

public:
	static CDialogManager*				GetInstance( void );
	static RwBool						CreateInstance( void );
	static void							DestroyInstance( void );

protected:
	CCreateProjectDlg*					m_pCreateProjectDlg;
	CZoneInfoDlg*						m_pZoneInfoDlg;
	COptimizeWorldObjDlg*				m_pOptimizeWorldObjDlg;

public:
	CDialogManager( void );
	~CDialogManager( void );


public:
	bool								Create( void );
	void								Delete( void );

	virtual void						HandleEvents( RWS::CMsg &pMsg );

};


#endif