#pragma once


// CZoneViewer �������Դϴ�.


#include "ZoneView.h"


class CZoneViewer : public CFrameWnd
{
	DECLARE_DYNCREATE(CZoneViewer)

protected:
	CZoneView* m_pZoneView;

public:
	CZoneViewer();
	virtual ~CZoneViewer();

public:
	BOOL Create( const CRect& rtRect, CWnd* pParent );

	void SetWorldRegion( float fBeginX, float fEndX, float fBeginZ, float fEndZ );
	void SetMinimap( const CString& strMinimapName );
	BOOL HasField( DWORD dwFieldID );
	void AddField( DWORD dwFieldID );
	void RemoveField( DWORD dwFieldID );
	void ClearAllZoneAttr( void );

protected:
	DECLARE_MESSAGE_MAP()

	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL DestroyWindow();
};


