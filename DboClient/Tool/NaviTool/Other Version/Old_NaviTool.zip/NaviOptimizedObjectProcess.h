#ifndef _NAVI_OPTIMIZEDOBJECTPROCESS_H_
#define _NAVI_OPTIMIZEDOBJECTPROCESS_H_


#include "NaviRenderingProcess.h"


class CNaviOptimizedObjectProcess : public CNaviRenderingProcess
{

// Member variables
protected:


// Constructions and Destructions
public:
	CNaviOptimizedObjectProcess( CWnd* pWnd );
	virtual ~CNaviOptimizedObjectProcess( void );


// Methods
public:
	// Create and Delete
	virtual bool						Create( void );
	virtual void						Delete( void );
	virtual LRESULT						WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam );


// Implementations
protected:
	virtual void						OnDeviceRestore( void );
	virtual void						OnDeviceRelease( void );
	virtual void						OnUpdate( float fTime, float fElapsedTime );

};


#endif