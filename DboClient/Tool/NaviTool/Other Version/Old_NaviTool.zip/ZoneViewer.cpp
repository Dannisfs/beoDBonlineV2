// ZoneInfo.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "ZoneViewer.h"

#include "NtlDebug.h"


// CZoneViewer

IMPLEMENT_DYNCREATE(CZoneViewer, CFrameWnd)

CZoneViewer::CZoneViewer()
{
	m_pZoneView = NULL;
}

CZoneViewer::~CZoneViewer()
{
}


BOOL CZoneViewer::Create( const CRect& rtRect, CWnd* pParent )
{
	return CFrameWnd::Create( NULL, NULL, WS_CHILD|WS_BORDER|WS_VISIBLE, rtRect, pParent );
}

void CZoneViewer::SetWorldRegion( float fStartX, float fEndX, float fStartZ, float fEndZ )
{
	if ( m_pZoneView )
	{
		m_pZoneView->SetWorldRegion( fStartX, fEndX, fStartZ, fEndZ );
	}
}

void CZoneViewer::SetMinimap( const CString& strMinimapName )
{
	if ( m_pZoneView )
	{
		m_pZoneView->SetMinimap( strMinimapName );
	}
}

BOOL CZoneViewer::HasField( DWORD dwFieldID )
{
	if ( m_pZoneView )
	{
		return m_pZoneView->HasField( dwFieldID );
	}
}

void CZoneViewer::AddField( DWORD dwFieldID )
{
	if ( m_pZoneView )
	{
		m_pZoneView->AddField( dwFieldID );
	}
}

void CZoneViewer::RemoveField( DWORD dwFieldID )
{
	if ( m_pZoneView )
	{
		m_pZoneView->RemoveField( dwFieldID );
	}
}

void CZoneViewer::ClearAllZoneAttr( void )
{
	if ( m_pZoneView )
	{
		m_pZoneView->ClearAllZoneAttr();
	}
}


BEGIN_MESSAGE_MAP(CZoneViewer, CFrameWnd)
END_MESSAGE_MAP()


// CZoneViewer �޽��� ó�����Դϴ�.

BOOL CZoneViewer::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	NTL_ASSERT( bRet, "Failed : CFrameWnd::OnCreateClient()" );

	CRect rtRect;
	GetClientRect( rtRect );

	m_pZoneView = new CZoneView;
	bRet = m_pZoneView->Create( NULL, NULL, WS_CHILD|WS_VISIBLE, rtRect, this, 0 );
	NTL_ASSERT( bRet, "Failed : m_pZoneView->Create()" );

	m_pZoneView->OnInitialUpdate();

	return bRet;
}

BOOL CZoneViewer::DestroyWindow()
{
	if ( m_pZoneView )
	{
		delete m_pZoneView;
		m_pZoneView = NULL;
	}

	return CFrameWnd::DestroyWindow();
}
