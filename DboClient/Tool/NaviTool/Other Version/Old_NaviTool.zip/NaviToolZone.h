#ifndef _NAVI_TOOL_ZONE_H_
#define _NAVI_TOOL_ZONE_H_


#include "NaviToolObject.h"


class CNaviToolWorldProperty;


class CNaviToolZone : public CNaviToolObject
{

// Declarations
public:
	typedef const RwIm3DVertex* LPRWIM3DVERTEX;
	typedef std::vector<int> vecdef_IndexList;


// Member variables
protected:
	// Attributes
	CNaviToolWorldProperty*				m_pWorldProperty;
	unsigned int						m_uiZoneID;

	// Updated values
	RwV3d								m_v3ZoneBegin, m_v3ZoneEnd;

	float								m_fTileSize;

	int									m_nVertexCnt;
	int									m_nVertexWidthCnt;
	LPRWIM3DVERTEX*						m_pVertexList;

	vecdef_IndexList					m_defIndexList;


// Constructions and Destructions
public:
	CNaviToolZone( void );
	virtual ~CNaviToolZone( void );


// Operations
public:
	CNaviToolWorldProperty*				GetWorldProperty( void );
	void								SetWorldProperty( CNaviToolWorldProperty* pWorldProperty );

	unsigned int						GetZoneID( void ) const;
	void								SetZoneID( unsigned int uiZoneID );

	void								GetZoneRgn( RwV3d& v3ZoneBegin, RwV3d& v3ZoneEnd );

	int									GetVertexCount( void ) const;
	int									GetVertexWidthCount( void ) const;
	const RwIm3DVertex*					GetVertex( int VertIdx ) const;
	int									ConvertFieldPosToVertexIndex( const RwV3d& v3Pos ) const;

	int									GetIndexCount( void ) const;
	const int							GetIndex( int nIndexIdx ) const;

	virtual void						AddChild( CNaviToolObject* pChild );
	virtual void						RemoveChild( CNaviToolObject* pChild );
	virtual void						RemoveAllChild( void );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );
	virtual void						Render( RwCamera* pCamera, const RwMatrix* pParentMatrix );

	bool								BuildDataForPath( void );


// Implementations
protected:
	void								UpdateZoneRgn( void );


	friend class CNaviToolObjectFactory;

};


inline CNaviToolWorldProperty* CNaviToolZone::GetWorldProperty( void )
{
	return m_pWorldProperty;
}


inline void CNaviToolZone::SetWorldProperty( CNaviToolWorldProperty* pWorldProperty )
{
	m_pWorldProperty = pWorldProperty;
}


inline unsigned int CNaviToolZone::GetZoneID( void ) const
{
	return m_uiZoneID;
}


inline void CNaviToolZone::SetZoneID( unsigned int uiZoneID )
{
	m_uiZoneID = uiZoneID;
}


inline void CNaviToolZone::GetZoneRgn( RwV3d& v3ZoneBegin, RwV3d& v3ZoneEnd )
{
	v3ZoneBegin = m_v3ZoneBegin;
	v3ZoneEnd = m_v3ZoneEnd;
}


inline int CNaviToolZone::GetVertexCount( void ) const
{
	return m_nVertexCnt;
}


inline int CNaviToolZone::GetVertexWidthCount( void ) const
{
	return m_nVertexWidthCnt;
}


inline const RwIm3DVertex* CNaviToolZone::GetVertex( int VertIdx ) const
{
	return m_pVertexList[VertIdx];
}


inline int CNaviToolZone::ConvertFieldPosToVertexIndex( const RwV3d& v3Pos ) const
{
	return (int)(((v3Pos.z - m_v3ZoneBegin.z) / m_fTileSize) * m_nVertexWidthCnt + ((v3Pos.x - m_v3ZoneBegin.x) / m_fTileSize));
}


inline int CNaviToolZone::GetIndexCount( void ) const
{
	return (int)m_defIndexList.size();
}


inline const int CNaviToolZone::GetIndex( int nIndexIdx ) const
{
	return m_defIndexList[nIndexIdx];
}


#endif