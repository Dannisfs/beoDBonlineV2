#ifndef _NAVI_RENDERINGPROCESS_H_
#define _NAVI_RENDERINGPROCESS_H_


#include <rwplcore.h>
#include "NaviToolDefine.h"


class CNtlCamera;


class CNaviRenderingProcess
{

// Declarations
public:
	enum eCAM_FLAGS
	{
		eCAM_FLAGS_ROT					= (1<<0),		// Yaw ȸ��

		eCAM_FLAGS_MOV_FORWARD			= (1<<1),		// Ű���� 'W'
		eCAM_FLAGS_MOV_BACKWARD			= (1<<2),		// Ű���� 'S'
		eCAM_FLAGS_MOV_LEFTWARD			= (1<<3),		// Ű���� 'A'
		eCAM_FLAGS_MOV_RIGHTWARD		= (1<<4)		// Ű���� 'D'
	};


// Member variables
protected:
	static const int					s_nClipSize;

	float								m_fRotVecPerSec;
	float								m_fMoveVecPerSec;

	eNAVI_PROCESS_ID					m_eID;

	CWnd*								m_pWnd;

	bool								m_bSysncView;

	CNtlCamera*							m_pCamera;

	DWORD								m_dwCamControlFlags;
	CPoint								m_ptOldCursorPos;
	CSize								m_szOffset;

	RwMatrix*							m_pMatrix;


// Constructions and Destructions
public:
	CNaviRenderingProcess( eNAVI_PROCESS_ID eID, CWnd* pWnd, bool bSysncView = false );
	virtual ~CNaviRenderingProcess( void );


// Attributes
public:
	CWnd*								GetWnd( void );
	CNtlCamera*							GetCamera( void );

	bool								IsSyncView( void ) const;

	float								GetRotSpeed( void ) const;
	void								SetRotSpeed( float fSpeed );

	float								GetMoveSpeed( void ) const;
	void								SetMoveSpeed( float fSpeed );

	void								MoveCamera( float fX, float fY, float fZ );
	void								MoveCamera( const RwV3d& v3Pos );


// Methods
public:
	// Create and Delete
	virtual bool						Create( void );
	virtual void						Delete( void );
	virtual LRESULT						WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam );


// Implementations
protected:
	virtual void						OnDeviceRestore( void );
	virtual void						OnDeviceRelease( void );
	virtual void						OnUpdate( float fTime, float fElapsedTime );

	void								UpdateSysncView( void );
	void								UpdateSysncView( RwMatrix* pMatrix );


	friend class CNaviRenderingFramework;

};


inline CWnd* CNaviRenderingProcess::GetWnd( void )
{
	return m_pWnd;
}


inline CNtlCamera* CNaviRenderingProcess::GetCamera( void )
{
	return m_pCamera;
}


inline bool CNaviRenderingProcess::IsSyncView( void ) const
{
	return m_bSysncView;
}


inline float CNaviRenderingProcess::GetRotSpeed( void ) const
{
	return m_fRotVecPerSec;
}


inline float CNaviRenderingProcess::GetMoveSpeed( void ) const
{
	return m_fMoveVecPerSec;
}



#endif