#ifndef _NAVI_TOOL_OBJECT_H_
#define _NAVI_TOOL_OBJECT_H_


#include "NaviToolObjectAttrs.h"


class CNaviToolObject
{

// Declarations
public:
	typedef std::vector< CNaviToolObject* > vecdef_ChildList;
	typedef vecdef_ChildList::iterator vecdef_ChildListIT;
	typedef vecdef_ChildList::const_iterator vecdef_ChildListCIT;


// Member variables
protected:
	int									m_nRef;			// ����ī��Ʈ

	CNaviToolObject*					m_pParent;		// �θ�
	vecdef_ChildList					m_defChilds;	// �ڽ�

	GUID								m_ID;			// ���� ���̵�

	bool								m_bCreated;


// Constructions and Destruction
public:
	CNaviToolObject( void );
	virtual ~CNaviToolObject( void );


// Operations
public:
	int									GetRef( void ) const;
	int									AddRef( void );
	int									ReleaseRef( void );

	CNaviToolObject*					GetParent( void );
	void								SetParent( CNaviToolObject* pParent );

	vecdef_ChildListIT					BeginChild( void );
	vecdef_ChildListIT					EndChild( void );
	vecdef_ChildListCIT					BeginChild( void ) const;
	vecdef_ChildListCIT					EndChild( void ) const;
	virtual void						AddChild( CNaviToolObject* pChild );
	virtual void						RemoveChild( CNaviToolObject* pChild );
	virtual void						RemoveAllChild( void );

	const GUID&							GetID( void ) const;
	void								SetID( const GUID& ID );

	GUID								GenerateID( void );
	CString								IDToString( const GUID& ID );
	GUID								StringToID( const CString& strID );

	virtual bool						Create( CNaviToolAttrs* pAttrs );
	virtual void						Delete( void );
	virtual void						Update( float fTime, float fElapsedTime );
	virtual void						Render( RwCamera* pCamera, const RwMatrix* pParentMatrix );

};


inline int CNaviToolObject::GetRef( void ) const
{
	return m_nRef;
}


inline int CNaviToolObject::AddRef( void )
{
	return ++m_nRef;
}


inline int CNaviToolObject::ReleaseRef( void )
{
	return --m_nRef;
}


inline CNaviToolObject* CNaviToolObject::GetParent( void )
{
	return m_pParent;
}


inline void CNaviToolObject::SetParent( CNaviToolObject* pParent )
{
	m_pParent = pParent;
}


inline const GUID& CNaviToolObject::GetID( void ) const
{
	return m_ID;
}


inline void CNaviToolObject::SetID( const GUID& ID )
{
	m_ID = ID;
}


#endif