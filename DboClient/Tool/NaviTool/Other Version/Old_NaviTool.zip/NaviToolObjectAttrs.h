#ifndef _NAVI_TOOL_OBJECTATTRS_H_
#define _NAVI_TOOL_OBJECTATTRS_H_


class CNaviToolWorldProperty;


class CNaviToolAttrs
{
public:
	virtual ~CNaviToolAttrs( void ) { return; }

public:
	void Init( void ) { return; }
};


class CNaviToolAttrs_WorldProperty : public CNaviToolAttrs
{
public:
	unsigned int uiWorldTblIdx;
	RwV3d v3WorldBegin;
	RwV3d v3WorldEnd;
	unsigned int uiFieldCnt;
	float fFieldSize;
	unsigned int uiTileCnt;
	float fTileSize;

public:
	void Init( void )
	{
		uiWorldTblIdx = 0xffffffff;
		v3WorldBegin.x = v3WorldBegin.y = v3WorldBegin.z = FLT_MAX;
		v3WorldEnd.x = v3WorldEnd.y = v3WorldEnd.z = -FLT_MAX;
		uiFieldCnt = 0;
		fFieldSize = 256.f;
		uiTileCnt = 0;
		fTileSize = 4.f;
	}
};


class CNaviToolAttrs_World : public CNaviToolAttrs
{
public:
	CNaviToolWorldProperty* pWorldProperty;
	unsigned int uiWorldTblIdx;

public:
	void Init( void ) { pWorldProperty = NULL; uiWorldTblIdx = 0xffffffff; }
};


class CNaviToolAttrs_Zone : public CNaviToolAttrs
{
public:
	CNaviToolWorldProperty* pWorldProperty;
	unsigned int uiZoneID;

public:
	void Init( void ) { pWorldProperty = NULL; uiZoneID = 0xffffffff; }
};


class CNaviToolAttrs_Field : public CNaviToolAttrs
{
public:
	CNaviToolWorldProperty* pWorldProperty;
	unsigned int uiFieldID;

public:
	void Init( void ) { pWorldProperty = NULL; uiFieldID = 0xffffffff; }
};


class CNaviToolAttrs_ModelInstance : public CNaviToolAttrs
{
public:
	CNaviToolWorldProperty* pWorldProperty;
	RwMatrix matLocal;

public:
	void Init( void ) { pWorldProperty = NULL; RwMatrixSetIdentity( &matLocal ); }
};


class CNaviToolAttrs_Model : public CNaviToolAttrs
{
public:
	CNaviToolWorldProperty* pWorldProperty;
	char szModelName[512];
	unsigned int uiModelProperty;

public:
	void Init( void ) { pWorldProperty = NULL; szModelName[0] = 0; uiModelProperty = 0; }
};


#endif