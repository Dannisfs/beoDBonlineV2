#pragma once


#include "afxwin.h"
#include "afxcmn.h"


class COptimizeFrame;
class CNaviToolModelInstance;
class CNaviToolModel;


// COptimizeWorldObjDlg ��ȭ �����Դϴ�.

class COptimizeWorldObjDlg : public CDialog
{
	DECLARE_DYNAMIC(COptimizeWorldObjDlg)

public:
	struct sModelInfo
	{
		CNaviToolModelInstance* pModelInst;
		CNaviToolModel* pModel;
	};

	typedef std::multimap<std::string, sModelInfo> mapdef_ModelList;

protected:
	mapdef_ModelList m_defModelList;

	COptimizeFrame* m_pSourceView;
	COptimizeFrame* m_pOptimizedView;

public:
	COptimizeWorldObjDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~COptimizeWorldObjDlg();

public:
	BOOL Create( void );

	void Refresh( void );
	void ClearAll( void );

protected:
	void UpdateWorldObjectList( void );

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_OPTIMIZE_WORLD_OBJECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CEdit m_ctrFindString;
	CListCtrl m_ctrFindStringList;
	CTreeCtrl m_ctrWorldObjectList;
	CComboBox m_ctrModelType;
	CComboBox m_ctrOptimizedMethod;


public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedIddFindObjectClearButton();
	afx_msg void OnBnClickedIddOptimizeApplyButton();
	virtual void OnCancel();
};
