#include "stdafx.h"

#include "NaviRenderingProcess.h"

#include "NaviRenderingFramework.h"

#include "NtlCamera.h"
#include "NtlPLGlobal.h"


const int CNaviRenderingProcess::s_nClipSize = 30;


CNaviRenderingProcess::CNaviRenderingProcess( eNAVI_PROCESS_ID eID, CWnd* pWnd, bool bSysncView /*= false*/ )
{
	m_fRotVecPerSec = 1.2f;
	m_fMoveVecPerSec = 1.f;

	m_eID = eID;

	m_pWnd = pWnd;

	m_bSysncView = bSysncView;

	m_pCamera = NULL;

	m_dwCamControlFlags = 0;
	m_ptOldCursorPos.SetPoint( 0, 0 );
	m_szOffset.SetSize( 0, 0 );

	m_pMatrix = NULL;
}


CNaviRenderingProcess::~CNaviRenderingProcess( void )
{
	Delete();
}


void CNaviRenderingProcess::SetRotSpeed( float fSpeed )
{
	m_fRotVecPerSec = fSpeed;
}


void CNaviRenderingProcess::SetMoveSpeed( float fSpeed )
{
	m_fMoveVecPerSec = fSpeed;
}


void CNaviRenderingProcess::MoveCamera( float fX, float fY, float fZ )
{
	if ( m_pCamera )
	{
		RwMatrix* prwMatrix = RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) );

		prwMatrix->pos.x = fX;
		prwMatrix->pos.y = fY;
		prwMatrix->pos.z = fZ;

		RwMatrixUpdate( RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) ) );
		RwFrameUpdateObjects( RwCameraGetFrame( m_pCamera->GetCamera() ) );	

		UpdateSysncView();
	}
}


void CNaviRenderingProcess::MoveCamera( const RwV3d& v3Pos )
{
	if ( m_pCamera )
	{
		RwMatrix* prwMatrix = RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) );

		prwMatrix->pos = v3Pos;

		RwMatrixUpdate( RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) ) );
		RwFrameUpdateObjects( RwCameraGetFrame( m_pCamera->GetCamera() ) );	

		UpdateSysncView();
	}
}


bool CNaviRenderingProcess::Create( void )
{
	m_pCamera = new CNtlCamera;

	CRect rtClientRect;
	m_pWnd->GetClientRect( rtClientRect );
	
	if ( !m_pCamera->Create( rtClientRect.Width(), rtClientRect.Height(), TRUE, 0.1f ) )
	{
		return false;
	}

	m_pMatrix = RwMatrixCreate();

	CNaviRenderingFramework::GetInstance()->AttachProcessList( m_eID, this );

	return true;
}


void CNaviRenderingProcess::Delete( void )
{
	CNaviRenderingFramework::GetInstance()->DetachProcessList( m_eID );

	if ( m_pMatrix )
	{
		RwMatrixDestroy( m_pMatrix );
		m_pMatrix = NULL;
	}

	if ( m_pCamera )
	{
		m_pCamera->Destroy();
		delete m_pCamera;
		m_pCamera = NULL;
	}

	m_pWnd = NULL;
}


LRESULT CNaviRenderingProcess::WindowProc( HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{
	switch ( uiMsg )
	{
	case WM_SIZE:
		{
			if ( m_pCamera )
			{
				CRect rtClientRect;
				m_pWnd->GetClientRect( rtClientRect );

				RwRect rt;
				rt.x = 0;
				rt.y = 0;
				rt.w = rtClientRect.Width();
				rt.h = rtClientRect.Height();

				m_pCamera->SetCameraSize( &rt );
			}
		}
		break;

	case WM_KEYDOWN:
		{
			if ( 'W' == (char)wParam )
			{
				m_dwCamControlFlags |= eCAM_FLAGS_MOV_FORWARD;
			}
			else if ( 'S' == (char)wParam )
			{
				m_dwCamControlFlags |= eCAM_FLAGS_MOV_BACKWARD;
			}
			else if ( 'A' == (char)wParam )
			{
				m_dwCamControlFlags |= eCAM_FLAGS_MOV_LEFTWARD;
			}
			else if ( 'D' == (char)wParam )
			{
				m_dwCamControlFlags |= eCAM_FLAGS_MOV_RIGHTWARD;
			}
		}
		break;

	case WM_KEYUP:
		{
			if ( 'W' == (char)wParam )
			{
				m_dwCamControlFlags &= ~eCAM_FLAGS_MOV_FORWARD;
			}
			else if ( 'S' == (char)wParam )
			{
				m_dwCamControlFlags &= ~eCAM_FLAGS_MOV_BACKWARD;
			}
			else if ( 'A' == (char)wParam )
			{
				m_dwCamControlFlags &= ~eCAM_FLAGS_MOV_LEFTWARD;
			}
			else if ( 'D' == (char)wParam )
			{
				m_dwCamControlFlags &= ~eCAM_FLAGS_MOV_RIGHTWARD;
			}
		}
		break;

	case WM_RBUTTONDOWN:
		{
			m_dwCamControlFlags |= eCAM_FLAGS_ROT;

			m_ptOldCursorPos.SetPoint( LOWORD( lParam ), HIWORD( lParam ) );
			m_szOffset.SetSize( 0, 0 );

			m_pWnd->SetCapture();

			ShowCursor( FALSE );
		}
		break;

	case WM_RBUTTONUP:
		{
			m_pWnd->ClientToScreen( &m_ptOldCursorPos );
			SetCursorPos( m_ptOldCursorPos.x, m_ptOldCursorPos.y );

			ShowCursor( TRUE );

			ReleaseCapture();

			m_dwCamControlFlags &= ~eCAM_FLAGS_ROT;
		}
		break;

	case WM_MOUSEMOVE:
		{
			if ( m_dwCamControlFlags & eCAM_FLAGS_ROT )
			{
				CPoint ptCurPos( LOWORD( lParam ), HIWORD( lParam ) );

				m_szOffset = ptCurPos - m_ptOldCursorPos;

				if ( abs( m_szOffset.cx ) > s_nClipSize )
				{
					m_szOffset.cx = m_szOffset.cx > 0 ? s_nClipSize : -s_nClipSize;
				}
				if ( abs( m_szOffset.cy ) > s_nClipSize )
				{
					m_szOffset.cy = m_szOffset.cy > 0 ? s_nClipSize : -s_nClipSize;
				}

				CPoint ptClipedPos = m_ptOldCursorPos + m_szOffset;

				if ( ptCurPos != ptClipedPos )
				{
					m_pWnd->ClientToScreen( &ptClipedPos );
					SetCursorPos( ptClipedPos.x, ptClipedPos.y );
				}
			}
		}
		break;
	}

	return FALSE;
}


void CNaviRenderingProcess::OnDeviceRestore( void )
{
}


void CNaviRenderingProcess::OnDeviceRelease( void )
{
}


void CNaviRenderingProcess::OnUpdate( float fTime, float fElapsedTime )
{
	RwMatrix* prwMatrix = RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) );

	// Camera rotation ó��

	RwV3d v3Pos = prwMatrix->pos;
	prwMatrix->pos.x = 0.f; prwMatrix->pos.y = 0.f; prwMatrix->pos.z = 0.f;

	if ( m_dwCamControlFlags & eCAM_FLAGS_ROT )
	{
		// Yaw rotation
		RwMatrixRotate( prwMatrix, &CNtlPLGlobal::m_vYAxisV3, -m_szOffset.cx * m_fRotVecPerSec * fElapsedTime, rwCOMBINEPOSTCONCAT );

		// Pitch rotation
		RwMatrixRotate( prwMatrix, &prwMatrix->right, m_szOffset.cy * m_fRotVecPerSec * fElapsedTime, rwCOMBINEPOSTCONCAT );
	}

	prwMatrix->pos = v3Pos;

	// Camera move ó��

	RwV3d v3MoveDir;
	v3MoveDir.x = 0.f; v3MoveDir.y = 0.f; v3MoveDir.z = 0.f;

	if ( m_dwCamControlFlags & eCAM_FLAGS_MOV_FORWARD )
	{
		v3MoveDir = prwMatrix->at;
		RwV3dScale( &v3MoveDir, &v3MoveDir, m_fMoveVecPerSec );
	}

	if ( m_dwCamControlFlags & eCAM_FLAGS_MOV_BACKWARD )
	{
		v3MoveDir = prwMatrix->at;
		RwV3dScale( &v3MoveDir, &v3MoveDir, -m_fMoveVecPerSec );
	}

	if ( m_dwCamControlFlags & eCAM_FLAGS_MOV_LEFTWARD )
	{
		v3MoveDir = prwMatrix->right;
		RwV3dScale( &v3MoveDir, &v3MoveDir, m_fMoveVecPerSec );
	}

	if ( m_dwCamControlFlags & eCAM_FLAGS_MOV_RIGHTWARD )
	{
		v3MoveDir = prwMatrix->right;
		RwV3dScale( &v3MoveDir, &v3MoveDir, -m_fMoveVecPerSec );
	}

	RwV3dAdd( &prwMatrix->pos, &prwMatrix->pos, &v3MoveDir );

	// Update camera

	RwMatrixUpdate( RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) ) );
	RwFrameUpdateObjects( RwCameraGetFrame( m_pCamera->GetCamera() ) );	

	if ( m_dwCamControlFlags ) UpdateSysncView();
}


void CNaviRenderingProcess::UpdateSysncView( void )
{
	if ( !IsSyncView() ) return;

	CNaviRenderingFramework::mapdef_ProcessListIT it = CNaviRenderingFramework::GetInstance()->BeginProcess();
	CNaviRenderingFramework::mapdef_ProcessListIT itEnd = CNaviRenderingFramework::GetInstance()->EndProcess();
	for ( ; it != itEnd; ++it )
	{
		CNaviRenderingProcess* pProcess = it->second;

		if ( pProcess->IsSyncView() && (void*)pProcess != (void*)this )
		{
			pProcess->UpdateSysncView( RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) ) );
		}
	}
}


void CNaviRenderingProcess::UpdateSysncView( RwMatrix* pMatrix )
{
	RwMatrixCopy( RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) ), pMatrix );
	RwMatrixUpdate( RwFrameGetMatrix( RwCameraGetFrame( m_pCamera->GetCamera() ) ) );
	RwFrameUpdateObjects( RwCameraGetFrame( m_pCamera->GetCamera() ) );	
}
