#include "stdafx.h"

#include "NaviRenderingFramework.h"

#include "NtlAtomic.h"
#include "NtlPLMaterialExtWrapper.h"
#include "NtlWorldMaterialPlugin.h"
#include "ntlworldplugin.h"

#include "NaviRenderingProcess.h"

#include "ceventhandler.h"


CNaviRenderingFramework CNaviRenderingFramework::s_clFrameWork;


CNaviRenderingFramework* CNaviRenderingFramework::GetInstance( void )
{
	return &s_clFrameWork;
}


CNaviRenderingFramework::CNaviRenderingFramework( void )
{
	m_hRestore = NULL;
	m_hRelease = NULL;
}


CNaviRenderingFramework::~CNaviRenderingFramework( void )
{
}


bool CNaviRenderingFramework::CreateRenderingSystem( HWND hWnd )
{
	bool bRet = Create( hWnd, false ) ? true : false;

	m_hRestore = CNtlDeviceRestoreHandler::GetInstance()->LinkDeviceRestore( this, &CNaviRenderingFramework::OnDeviceRestore );
	m_hRelease = CNtlDeviceRestoreHandler::GetInstance()->LinkDeviceRelease( this, &CNaviRenderingFramework::OnDeviceRelease );

	//////////////////////////////////////////////////////////////////////////
	// Event handler �ʱ�ȭ
	//////////////////////////////////////////////////////////////////////////

	RWS::CEventHandler::Open();
	RWS::CEventHandler::RegisterStreamChunkHandlers();

	return  bRet;
}


void CNaviRenderingFramework::DeleteRenderingSystem( void )
{
	m_defProcessList.clear();

	RWS::CEventHandler::UnRegisterStreamChunkHandlers();
	RWS::CEventHandler::Close ();

	if ( m_hRestore )
	{
		CNtlDeviceRestoreHandler::GetInstance()->UnLinkDeviceRestore( m_hRestore );
		m_hRestore = NULL;
	}

	if ( m_hRelease )
	{
		CNtlDeviceRestoreHandler::GetInstance()->UnLinkDeviceRelease( m_hRelease );
		m_hRelease = NULL;
	}

	Destroy();
}


void CNaviRenderingFramework::UpdateRenderingSystem( void )
{
	CNtlApplication::Update();
}


CNaviRenderingProcess* CNaviRenderingFramework::FindProcess( eNAVI_PROCESS_ID eID )
{
	mapdef_ProcessList::iterator it = m_defProcessList.find( eID );
	if ( it == m_defProcessList.end() ) return NULL;
	return it->second;
}


void CNaviRenderingFramework::AttachProcessList( eNAVI_PROCESS_ID eID, CNaviRenderingProcess* pProcess )
{
	m_defProcessList[eID] = pProcess;
}


void CNaviRenderingFramework::DetachProcessList( eNAVI_PROCESS_ID eID )
{
	mapdef_ProcessList::iterator it = m_defProcessList.find( eID );
	if ( it != m_defProcessList.end() )
	{
		m_defProcessList.erase( it );
	}
}


int CNaviRenderingFramework::OnDeviceRestore( void )
{
	mapdef_ProcessList::iterator it = m_defProcessList.begin();
	for ( ; it != m_defProcessList.end(); ++it )
	{
		it->second->OnDeviceRestore();
	}

	return 1;
}


int	CNaviRenderingFramework::OnDeviceRelease( void )
{
	mapdef_ProcessList::iterator it = m_defProcessList.begin();
	for ( ; it != m_defProcessList.end(); ++it )
	{
		it->second->OnDeviceRelease();
	}

	return 1;
}


void CNaviRenderingFramework::OnUpdate( float fTime, float fElapsedTime )
{
	mapdef_ProcessList::iterator it = m_defProcessList.begin();
	for ( ; it != m_defProcessList.end(); ++it )
	{
		it->second->OnUpdate( fTime, fElapsedTime );
	}
}


RwBool CNaviRenderingFramework::AttachPlugin( void )
{
	if ( !RpWorldPluginAttach() )
	{
		ASSERT( !"Failed : RpWorldPluginAttach()" );
		return FALSE;
	}

	if ( !RpCollisionPluginAttach() )
	{
		ASSERT( !"Failed : RpCollisionPluginAttach()" );
		return FALSE;
	}

	if ( !RtAnimInitialize() )
	{
		ASSERT( !"Failed : RtAnimInitialize()" );
		return FALSE;
	}

	if ( !RpHAnimPluginAttach() )
	{
		ASSERT( !"Failed : RpHAnimPluginAttach()" );
		return FALSE;
	}

	if ( !RpSkinPluginAttach() )
	{
		ASSERT( !"Failed : RpSkinPluginAttach()" );
		return FALSE;
	}

	if ( !RpToonPluginAttach() )
	{
		ASSERT( !"Failed : RpToonPluginAttach()" );
		return FALSE;
	}

	if ( !RpUserDataPluginAttach() )
	{
		ASSERT( !"Failed : RpUserDataPluginAttach()" );
		return FALSE;
	}

	if ( !RpIdPluginAttach() )
	{
		ASSERT( !"Failed : RpIdPluginAttach()" );
		return FALSE;
	}

	if ( !RpMatFXPluginAttach() )
	{
		ASSERT( !"Failed : RpMatFXPluginAttach()" );
		return FALSE;
	}

	if ( !RpUVAnimPluginAttach())
	{
		ASSERT( !"Failed : RpUVAnimPluginAttach()" );
		return FALSE;
	}

	if ( !RpPTankPluginAttach())
	{
		ASSERT( !"Failed : RpPTankPluginAttach()" );
		return FALSE;
	}

	if ( !RpPrtStdPluginAttach())
	{
		ASSERT( !"Failed : RpPrtStdPluginAttach()" );
		return FALSE;
	}

	if ( !RpPrtAdvPluginAttach())
	{
		ASSERT( !"Failed : RpPrtAdvPluginAttach()" );
		return FALSE;
	}

	if ( !RpNtlAtomicPluginAttach())
	{
		ASSERT( !"Failed : RpNtlAtomicPluginAttach()" );
		return FALSE;
	}

	if ( !NtlMatExtPluginAttach())
	{
		ASSERT( !"Failed : NtlMatExtPluginAttach()" );
		return FALSE;
	}

	if ( !RpNtlWorldMaterialPluginAttach() )
	{
		ASSERT( !"Failed : RpNtlWorldMaterialPluginAttach()" );
		return FALSE;
	}

	if ( !RpNtlWorldAttach() )
	{
		ASSERT( !"Failed : RpNtlWorldAttach()" );
		return FALSE;
	}

	if ( !RpNtlWorldMaterialPluginAttach() )
	{
		ASSERT( !"Failed : RpNtlWorldMaterialPluginAttach()" );
		return FALSE;
	}

	return TRUE;
}


RwBool CNaviRenderingFramework::Update( RwReal fTime, RwReal fElapsedTime )
{
	OnUpdate( fTime, fElapsedTime );

	return TRUE;
}
