// NaviTool.h : main header file for the NaviTool application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CNaviToolApp:
// See NaviTool.cpp for the implementation of this class
//

class CNaviToolApp : public CWinApp
{
// Member variables
protected:

// public
public:
	CNaviToolApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnIdle(LONG lCount);
	virtual int ExitInstance();
};

extern CNaviToolApp theApp;