// ZoneInfoDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "ZoneInfoDlg.h"

#include "NaviEvent.h"


// CZoneInfoDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CZoneInfoDlg, CDialog)

CZoneInfoDlg::CZoneInfoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZoneInfoDlg::IDD, pParent)
{
	m_pclZoneViewer = NULL;
}

CZoneInfoDlg::~CZoneInfoDlg()
{
}

BOOL CZoneInfoDlg::Create( void )
{
	if ( !CDialog::Create( IDD, NULL ) )
	{
		return FALSE;
	}

	ShowWindow( SW_SHOW );

	return TRUE;
}

void CZoneInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ZONEINFO_POS, m_ctrZoneInfoPos);
}


BEGIN_MESSAGE_MAP(CZoneInfoDlg, CDialog)
	ON_BN_CLICKED(IDC_ZONEINFO_LOADMINIMAP, &CZoneInfoDlg::OnBnClickedZoneinfoLoadminimap)
END_MESSAGE_MAP()


// CZoneInfoDlg �޽��� ó�����Դϴ�.

BOOL CZoneInfoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect rtRgn;
	m_ctrZoneInfoPos.GetWindowRect( rtRgn );
	m_ctrZoneInfoPos.ShowWindow( SW_HIDE );
	ScreenToClient( rtRgn );

	//CZoneAttr clAttr;
	//clAttr.m_fBeginX = -2048.f;
	//clAttr.m_fBeginZ = 2048.f;
	//clAttr.m_fEndX = 2048.f;
	//clAttr.m_fEndZ = -2048.f;
	//mapdef_FieldList m_defFieldList;
	//m_defFieldList[1] = CRect( 0, 0, 0, 0 );
	//m_defFieldList[2] = CRect( 0, 0, 0, 0 );
	//m_defFieldList[3] = CRect( 0, 0, 0, 0 );
	//m_defFieldList[4] = CRect( 0, 0, 0, 0 );
	//m_defFieldList[5] = CRect( 0, 0, 0, 0 );

	m_pclZoneViewer = new CZoneViewer;
	m_pclZoneViewer->Create( rtRgn, this );

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BOOL CZoneInfoDlg::DestroyWindow()
{
	if ( m_pclZoneViewer )
	{
		delete m_pclZoneViewer;
		m_pclZoneViewer = NULL;
	}

	return CDialog::DestroyWindow();
}

void CZoneInfoDlg::OnBnClickedZoneinfoLoadminimap()
{
	CFileDialog clFile( TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, "Picture (*.bmp;*.gif;*png)|*.bmp;*.gif;*.png|", NULL, 0 );
	if ( IDOK == clFile.DoModal() )
	{
		if ( m_pclZoneViewer )
		{
			m_pclZoneViewer->SetMinimap( clFile.GetPathName() );
		}
	}
}

void CZoneInfoDlg::OnOK()
{
	CDialog::OnOK();

	sEventCloseZoneInfoDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventCloseZoneInfoDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}

void CZoneInfoDlg::OnCancel()
{
	CDialog::OnCancel();

	sEventCloseZoneInfoDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventCloseZoneInfoDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}

