// OptimizeFrame.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "OptimizeFrame.h"


// COptimizeFrame

IMPLEMENT_DYNCREATE(COptimizeFrame, CFrameWnd)

COptimizeFrame::COptimizeFrame()
{
	m_pView = NULL;
	m_pRuntimeClass = NULL;
}

COptimizeFrame::~COptimizeFrame()
{
}

BOOL COptimizeFrame::Create( const CRect& rtRect, CWnd* pParent, CRuntimeClass* pRuntimeClass )
{
	m_pRuntimeClass = pRuntimeClass;

	return CFrameWnd::Create( NULL, NULL, WS_CHILD|WS_BORDER|WS_VISIBLE, rtRect, pParent );
}


BEGIN_MESSAGE_MAP(COptimizeFrame, CFrameWnd)
END_MESSAGE_MAP()


// COptimizeFrame �޽��� ó�����Դϴ�.

BOOL COptimizeFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bRet = CFrameWnd::OnCreateClient(lpcs, pContext);
	ASSERT( bRet || !"Failed : COptimizeFrame::OnCreateClient()" );

	CRect rtRect;
	GetClientRect( rtRect );

	m_pView = DYNAMIC_DOWNCAST( CView, m_pRuntimeClass->CreateObject() );
	bRet = m_pView->Create( NULL, NULL, WS_CHILD|WS_VISIBLE, rtRect, this, 0 );
	ASSERT( bRet || !"Failed : m_pView->Create()" );

	m_pView->OnInitialUpdate();

	return bRet;
}

BOOL COptimizeFrame::DestroyWindow()
{
	if ( m_pView )
	{
		delete m_pView;
		m_pView = NULL;
	}

	return CFrameWnd::DestroyWindow();
}
