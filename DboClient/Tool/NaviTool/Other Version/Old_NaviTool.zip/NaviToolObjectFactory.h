#ifndef _NAVI_TOOL_OBJECTFACTORY_H_
#define _NAVI_TOOL_OBJECTFACTORY_H_


#include "NaviToolWorld.h"
#include "NaviToolWorldProperty.h"
#include "NaviToolZone.h"
#include "NaviToolField.h"
#include "NaviToolModelInstance.h"
#include "NaviToolModel.h"


class CNaviToolObjectFactory
{

// Declarations
public:
	typedef std::map< std::string, CNaviToolObject* > mapdef_ObjectList;
	typedef std::map< std::string, CNaviToolModel* > mapdef_ModelList;


// Member variables
protected:
	mapdef_ObjectList					m_defObjList;
	mapdef_ModelList					m_defModelList;


// Constructions and Destructions
public:
	CNaviToolObjectFactory( void );
	~CNaviToolObjectFactory( void );


// Operations
public:
	CNaviToolObject*					FindObject( const char* pID );
	template< typename T > T*			CreateObject( const char* pID = NULL );	// CNaviToolModel�� �� �Լ��� �̿��� �����ϸ� �ȵȴ�
	void								DeleteObject( const char* pID );
	void								DeleteAllObjects( void );

	CNaviToolModel*						FindModel( const char* pModelName );
	CNaviToolModel*						CreateModel( const char* pModelName );
	void								DeleteModel( const char* pModelName );
	void								DeleteAllModels( void );
};


template< typename T >
T* CNaviToolObjectFactory::CreateObject( const char* pID /*= NULL*/ )
{
#define INPUT_TYPE_STRING( p )	#p

	std::string strInputType = INPUT_TYPE_STRING( T );
	if ( strInputType == "CNaviToolModel" )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �ش� Ÿ���� �� �Լ��� ����� ������ �� �����ϴ�", __FILE__, __FUNCTION__, __LINE__, strInputType.c_str() );
		return NULL;
	}

	if ( NULL != pID )
	{
		CNaviToolObject* pObj = FindObject( pID );

		if ( NULL != pObj )
		{
			if ( dynamic_cast< T* > ( pObj ) )
			{
				pObj->AddRef();
				return (T*)pObj;
			}
			else
			{
				CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �ش� ������Ʈ�� �ٸ� Ŭ����Ʈ �̹� �����Ǿ� �ֽ��ϴ�", __FILE__, __FUNCTION__, __LINE__, typeid(pObj).name() );
				return NULL;
			}
		}
	}

	T* pRetObj = new T;

	pRetObj->SetID( pRetObj->GenerateID() );
	CString strID = pRetObj->IDToString( pRetObj->GetID() );

	pRetObj->AddRef();

	m_defObjList[(const char*)strID] = pRetObj;

	return pRetObj;
}


#endif