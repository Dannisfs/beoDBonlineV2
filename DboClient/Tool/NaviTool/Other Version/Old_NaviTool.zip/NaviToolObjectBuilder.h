#ifndef _NAVI_TOOL_OBJECTBUILDER_H_
#define _NAVI_TOOL_OBJECTBUILDER_H_


#include "ntlworldcommon.h"
#include "NaviToolObjectFactory.h"


class CNtlPLWorldEntity;


class CNaviToolObjectBuilder
{

// Member variables
protected:
	CNaviToolObjectFactory				m_clObjFactory;


// Constructions and Destructions
public:
	CNaviToolObjectBuilder( void );
	~CNaviToolObjectBuilder( void );


// Operations
public:
	CNaviToolObject*					BuildFromWorldData( unsigned int uiWorldTblIdx,
															unsigned int uiZoneID,
															unsigned int uiFieldCnt,
															unsigned int aruiFieldProperty[],
															unsigned int uiTileCnt,
															unsigned int aruiTileProperty[],
															sNtlWorldParam* pWorldParam,
															CNtlPLWorldEntity* pWorldEntity );

	void								DeleteAll( void );

};

#endif