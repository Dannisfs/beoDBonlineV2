// NaviToolDoc.cpp : implementation of the CNaviToolDoc class
//

#include "stdafx.h"
#include "NaviTool.h"

#include "NaviToolDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CNaviToolDoc

IMPLEMENT_DYNCREATE(CNaviToolDoc, CDocument)

BEGIN_MESSAGE_MAP(CNaviToolDoc, CDocument)
END_MESSAGE_MAP()


// CNaviToolDoc construction/destruction

CNaviToolDoc::CNaviToolDoc()
{
	// TODO: add one-time construction code here

}

CNaviToolDoc::~CNaviToolDoc()
{
}

BOOL CNaviToolDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CNaviToolDoc serialization

void CNaviToolDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CNaviToolDoc diagnostics

#ifdef _DEBUG
void CNaviToolDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNaviToolDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CNaviToolDoc commands
