// MainFrm.h : interface of the CMainFrame class
//


#pragma once

class CMainFrame : public CXTPFrameWnd
{

// Member variables
public:
	CXTSplitterWnd  m_wndSplitter;

protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:
	void FitToCenterSplitterWnd( void );

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CXTPStatusBar  m_wndStatusBar;
	CXTPDockingPaneManager m_paneManager;
	CXTPOfficeBorder<CStatic> m_wndOptions;
	CXTPOfficeBorder<CEdit> m_wndProperties;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnCustomize();
	afx_msg LRESULT OnDockingPaneNotify(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnFileCreateproject();
	afx_msg void OnFileOpenproject();
	afx_msg void OnFileCloseproject();
	afx_msg void OnViewOpenZoneviewdialog();
	afx_msg void OnViewCloseZoneviewdialog();
	afx_msg void OnViewOpenObjectdialog();
	afx_msg void OnViewCloseObjectdialog();
};
