#ifndef _NAVI_PROJECT_H_
#define _NAVI_PROJECT_H_


#include "NaviToolObjectBuilder.h"


class CNaviProject
{

// Static
protected:
	static CNaviProject					s_clProject;


public:
	static CNaviProject*				GetInstance( void );


// Member variables
protected:
	bool								m_bCreated;

	CString								m_strProjectName;
	CString								m_strProjectFolderName;
	unsigned int						m_uiWorldTblIdx;
	unsigned int						m_uiZoneID;
	CString								m_strFieldPropFile;
	CString								m_strTilePropFile;

	int									m_nFieldCnt;
	unsigned int*						m_pFieldBuffer;

	int									m_nTileCnt;
	unsigned int*						m_pTileBuffer;

	CNaviToolObjectBuilder				m_clObjectBuilder;

public:
	CNaviToolObject*					m_pWorld;


// Constructions and Destructions
public:
	CNaviProject( void );
	~CNaviProject( void );


// Attributes
public:
	bool								IsCreated( void ) const;


// Operations
public:
	bool								Create( const char* pProjName, const char* pProjFolderName, unsigned int uiWorldTblIdx, unsigned int uiZoneID, const char* pFieldPropFile, const char* pTilePropFile );
	void								Delete( void );

	bool								Import( const char* pProjectFileName );
	bool								Export( const char* pProjectFileName );


// Implementations
protected:
	bool								CreateFieldProperty( const char* pFileName );
	void								DeleteFieldProperty( void );

	bool								CreateTileProperty( const char* pFileName );
	void								DeleteTileProperty( void );

	bool								Import_00000000( FILE* pFile );
};


inline bool CNaviProject::IsCreated( void ) const
{
	return m_bCreated;
}


#endif