// OptimizeWorldObjDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "OptimizeWorldObjDlg.h"

#include "OptimizeFrame.h"
#include "OptimizeSourceView.h"
#include "OptimizeOptimizedView.h"

#include "NaviToolModelInstance.h"

#include "NaviEvent.h"

#include "NaviProject.h"


// COptimizeWorldObjDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(COptimizeWorldObjDlg, CDialog)

COptimizeWorldObjDlg::COptimizeWorldObjDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptimizeWorldObjDlg::IDD, pParent)
{
	m_pSourceView = NULL;
	m_pOptimizedView = NULL;
}

COptimizeWorldObjDlg::~COptimizeWorldObjDlg()
{
}

BOOL COptimizeWorldObjDlg::Create( void )
{
	if ( !CDialog::Create( IDD, NULL ) )
	{
		return FALSE;
	}

	ShowWindow( SW_SHOW );

	return TRUE;
}

void COptimizeWorldObjDlg::Refresh( void )
{
	ClearAll();

	CNaviToolWorld* pWorld = dynamic_cast<CNaviToolWorld*>(CNaviProject::GetInstance()->m_pWorld);
	if ( NULL == pWorld ) ClearAll();

	CNaviToolZone* pZone = dynamic_cast<CNaviToolZone*>(pWorld->BeginChild() == pWorld->EndChild() ? NULL : *pWorld->BeginChild());
	if ( NULL == pZone ) ClearAll();

	CNaviToolObject::vecdef_ChildListCIT itField = pZone->BeginChild();
	CNaviToolObject::vecdef_ChildListCIT itFieldEnd = pZone->EndChild();
	for ( ; itField != itFieldEnd; ++itField )
	{
		CNaviToolModelInstance* pModelInst = dynamic_cast<CNaviToolModelInstance*>(*itField);
		CNaviToolModel* pModel = dynamic_cast<CNaviToolModel*>(pModelInst->BeginChild() == pModelInst->EndChild() ? NULL : *pModelInst->BeginChild());

		sModelInfo sInfo;
		sInfo.pModelInst = pModelInst;
		sInfo.pModel = pModel;

		m_defModelList.insert( mapdef_ModelList::value_type( (const char*)pModel->GetModelName(), sInfo ) );
	}
}

void COptimizeWorldObjDlg::ClearAll( void )
{
	m_defModelList.clear();
}

void COptimizeWorldObjDlg::UpdateWorldObjectList( void )
{
	m_ctrWorldObjectList.DeleteAllItems();

	CString strName;
	HTREEITEM Item;

	mapdef_ModelList::iterator it = m_defModelList.begin();
	for ( ; it != m_defModelList.end(); ++it )
	{
		const char* pName = it->first.c_str();
		sModelInfo& sInfo = it->second;

		if ( strName == pName )
		{
			m_ctrWorldObjectList.InsertItem( pName, Item );
		}
		else
		{
			strName = pName;

			Item = m_ctrWorldObjectList.InsertItem( pName );
		}
	}
}

void COptimizeWorldObjDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_IDD_FIND_OBJECT_FROM_NAME_EDITOR, m_ctrFindString);
	DDX_Control(pDX, IDC_IDD_FIND_OBJECT_LISTVIEW, m_ctrFindStringList);
	DDX_Control(pDX, IDC_IDD_OPTIMIZE_WORLD_OBJECT_OBJECT_TREEVIEW, m_ctrWorldObjectList);
	DDX_Control(pDX, IDC_IDD_OPTIMIZE_MODEL_TYPE_COMBO, m_ctrModelType);
	DDX_Control(pDX, IDC_IDD_OPTIMIZE_METHOD_COMBO, m_ctrOptimizedMethod);
}


BEGIN_MESSAGE_MAP(COptimizeWorldObjDlg, CDialog)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_IDD_FIND_OBJECT_CLEAR_BUTTON, &COptimizeWorldObjDlg::OnBnClickedIddFindObjectClearButton)
	ON_BN_CLICKED(IDC_IDD_OPTIMIZE_APPLY_BUTTON, &COptimizeWorldObjDlg::OnBnClickedIddOptimizeApplyButton)
END_MESSAGE_MAP()


// COptimizeWorldObjDlg �޽��� ó�����Դϴ�.

BOOL COptimizeWorldObjDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CWnd* pWnd;
	CRect rtRgn;

	pWnd = GetDlgItem( IDD_OPTIMIZE_SOURCE_VIEW );
	pWnd->GetWindowRect( rtRgn );
	pWnd->ShowWindow( SW_HIDE );
	ScreenToClient( rtRgn );

	m_pSourceView = new COptimizeFrame;
	if ( !m_pSourceView->Create( rtRgn, this, RUNTIME_CLASS( COptimizeSourceView ) ) )
	{
		return FALSE;
	}

	pWnd = GetDlgItem( IDD_OPTIMIZE_OPTIMIZEDVIEW );
	pWnd->GetWindowRect( rtRgn );
	pWnd->ShowWindow( SW_HIDE );
	ScreenToClient( rtRgn );

	m_pOptimizedView = new COptimizeFrame;
	if ( !m_pOptimizedView->Create( rtRgn, this, RUNTIME_CLASS( COptimizeOptimizedView ) ) )
	{
		return FALSE;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void COptimizeWorldObjDlg::OnDestroy()
{
	if ( m_pSourceView )
	{
		delete m_pSourceView;
		m_pSourceView = NULL;
	}

	if ( m_pOptimizedView )
	{
		delete m_pOptimizedView;
		m_pOptimizedView = NULL;
	}

	CDialog::OnDestroy();
}

void COptimizeWorldObjDlg::OnBnClickedIddFindObjectClearButton()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}

void COptimizeWorldObjDlg::OnBnClickedIddOptimizeApplyButton()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}

void COptimizeWorldObjDlg::OnCancel()
{
	CDialog::OnCancel();

	sEventCloseOptimizedWorldObjectDlg sData;

	RWS::CMsg msg;
	msg.Id = g_EventCloseOptimizedWorldObjectDlg;
	msg.pData = (void*)(&sData);

	_SendMsg( msg );
}
