// NaviToolWorldView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NaviTool.h"
#include "NaviToolWorldView.h"

#include "NaviMainWorldProcess.h"


// CNaviToolWorldView

IMPLEMENT_DYNCREATE(CNaviToolWorldView, CView)

CNaviToolWorldView::CNaviToolWorldView()
{
	m_pProcess = new CNaviMainWorldProcess( this );
}

CNaviToolWorldView::~CNaviToolWorldView()
{
	if ( m_pProcess )
	{
		delete m_pProcess;
		m_pProcess = NULL;
	}
}

bool CNaviToolWorldView::Build( void )
{
	return m_pProcess->Create();
}


BEGIN_MESSAGE_MAP(CNaviToolWorldView, CView)
END_MESSAGE_MAP()


// CNaviToolWorldView �׸����Դϴ�.

void CNaviToolWorldView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.
}


// CNaviToolWorldView �����Դϴ�.

#ifdef _DEBUG
void CNaviToolWorldView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CNaviToolWorldView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CNaviToolWorldView �޽��� ó�����Դϴ�.

BOOL CNaviToolWorldView::PreTranslateMessage(MSG* pMsg)
{
	if ( m_pProcess )
	{
		m_pProcess->WindowProc( pMsg->hwnd, pMsg->message, pMsg->wParam, pMsg->lParam );
	}

	return CView::PreTranslateMessage(pMsg);
}
