#include "stdafx.h"


CNaviLog* CNaviLog::GetInstance( void )
{
	static CNaviLog s_clLog;
	return &s_clLog;
}


CNaviLog::CNaviLog( void )
{
}


CNaviLog::~CNaviLog( void )
{
	ClearLogs();
}


CNaviLog::vecdef_LogListIT CNaviLog::BeginLog( void )
{
	return m_defLogList.begin();
}


CNaviLog::vecdef_LogListIT CNaviLog::EndLog( void )
{
	return m_defLogList.end();
}


void CNaviLog::AddLog( const char* pLog, ... )
{
	va_list va;
	char szStringBuf[4096];

	va_start( va, pLog );
	vsprintf_s( szStringBuf, 4096, pLog, va );
	va_end( va );

	m_defLogList.push_back( szStringBuf );

	ASSERT( 0 );
}


void CNaviLog::ClearLogs( void )
{
	m_defLogList.clear();
}
