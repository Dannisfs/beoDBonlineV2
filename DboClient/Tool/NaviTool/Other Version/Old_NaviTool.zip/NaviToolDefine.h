#ifndef _NAVI_TOOLDEFINE_H_
#define _NAVI_TOOLDEFINE_H_


static RwV3d g_v3Blank;


#define NAVI_TOOL_PROJECT_HEADER					"NAVI_TOOL_PROJECT_FILE"


#define NAVI_TOOL_PROJECT_VERSION					(0)


#define NAVI_GAME_WORLD_FOLDER						"\\world"
#define NAVI_GAME_WORLD_DATA_PROP_FILE				"#######.gwp"
#define NAVI_GAME_WORLD_DATA_TEXTURE_FOLDER			"\\texture\\ntlwe\\"

#define NAVI_TOOL_PATH_ENGINE_WORKIGN_FOLDER		".\\NaviToolData\\ToolData\\"
#define NAVI_TOOL_3D_CONTENT_NAME					"ContentProcessing3D.dll"


#define NAVI_TOOL_PROJECT_FILE_EXT					".navi"


#define NAVI_TOOL_VERTEX_GAP						(4.f)
#define NAVI_TOOL_TILE_PER_FIELD					(4096)
#define NAVI_TOOL_FIELD_SIZE						(256.f)


enum eNAVI_PROCESS_ID
{
	eNAVI_PROCESS_ID_MAIN_PROCESS,
	eNAVI_PROCESS_ID_PATH_PROCESS,
	eNAVI_PROCESS_ID_SOURCE_OBJECT_PROCESS,
	eNAVI_PROCESS_ID_OPTIMIZED_OBJECT_PROCESS
};


#endif