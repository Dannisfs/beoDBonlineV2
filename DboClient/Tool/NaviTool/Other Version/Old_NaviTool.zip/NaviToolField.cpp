#include "stdafx.h"
#include "NaviToolField.h"

#include "NaviToolWorldProperty.h"


CNaviToolField::CNaviToolField( void )
{
	m_pWorldProperty = NULL;
	m_uiFieldID = 0xffffffff;

	m_fTileSize = 4.f;
	m_fFieldSize = 256.f;

	m_v3FieldBegin.x = m_v3FieldBegin.y = m_v3FieldBegin.z = FLT_MAX;
	m_v3FieldEnd.x = m_v3FieldEnd.y = m_v3FieldEnd.z = -FLT_MAX;

	m_nVertexCnt = 65 * 65;
	m_nVertexWidthCnt = 65;
	m_pVertexList = NULL;

	m_nIndexCnt = 0;
	m_nIndexMaxCnt = 64 * 64 * 2 * 3;
	m_pIndexList = NULL;
}


CNaviToolField::~CNaviToolField( void )
{
	Delete();
}


bool CNaviToolField::Create( CNaviToolAttrs* pAttrs )
{
	if ( m_bCreated ) return true;

	CNaviToolAttrs_Field* pFieldAttr = dynamic_cast< CNaviToolAttrs_Field* > ( pAttrs );
	if ( NULL == pFieldAttr )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%s] �߸��� �Ӽ� ������ �ԷµǾ����ϴ�", __FILE__, __FUNCTION__, __LINE__, (pAttrs ? typeid(pAttrs).name() : "NULL") );
		return false;
	}

	m_pWorldProperty = pFieldAttr->pWorldProperty;
	m_uiFieldID = pFieldAttr->uiFieldID;

	m_fTileSize = m_pWorldProperty->GetTileSize();
	m_fFieldSize = m_pWorldProperty->GetFieldSize();

	RwV3d v3WorldBegin, v3WorldEnd;
	m_pWorldProperty->GetWorldRgn( v3WorldBegin, v3WorldEnd );

	int nWorldFieldWidthCnt = (int)((v3WorldEnd.x - v3WorldBegin.x) / m_fFieldSize);
	int nX = m_uiFieldID % nWorldFieldWidthCnt;
	int nZ = m_uiFieldID / nWorldFieldWidthCnt;

	m_v3FieldBegin.x = v3WorldBegin.x + nX * m_fFieldSize;
	m_v3FieldBegin.z = v3WorldBegin.z + nZ * m_fFieldSize;
	m_v3FieldBegin.y = FLT_MAX;

	m_v3FieldEnd.x = v3WorldBegin.x + (nX + 1) * m_fFieldSize;
	m_v3FieldEnd.z = v3WorldBegin.z + (nZ + 1) * m_fFieldSize;
	m_v3FieldEnd.y = -FLT_MAX;

	m_nVertexCnt = (int)((m_v3FieldEnd.x - m_v3FieldBegin.x) / m_fTileSize + 1.f) * (int)((m_v3FieldEnd.z - m_v3FieldBegin.z) / m_fTileSize + 1.f);
	m_nVertexWidthCnt = (int)((m_v3FieldEnd.x - m_v3FieldBegin.x) / m_fTileSize + 1.f);

	m_pVertexList = new RwIm3DVertex[m_nVertexCnt];
	if ( NULL == m_pVertexList )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d] New ����", __FILE__, __FUNCTION__, __LINE__, m_nVertexCnt );
		return false;
	}

	m_nIndexCnt = 0;
	m_nIndexMaxCnt = (int)((m_v3FieldEnd.x - m_v3FieldBegin.x) / m_fTileSize ) * (int)((m_v3FieldEnd.z - m_v3FieldBegin.z) / m_fTileSize ) * 2 * 3;

	m_pIndexList = new RwImVertexIndex[m_nIndexMaxCnt];
	if ( NULL == m_pIndexList )
	{
		CNaviLog::GetInstance()->AddLog( "[%s, %s, %d] [%d] New ����", __FILE__, __FUNCTION__, __LINE__, m_nIndexMaxCnt );
		return false;
	}

	return CNaviToolObject::Create( pAttrs );
}


void CNaviToolField::Delete( void )
{
	if ( m_pIndexList )
	{
		delete [] m_pIndexList;
		m_pIndexList = NULL;
	}

	m_nIndexMaxCnt = 64 * 64 * 2 * 3;
	m_nIndexCnt = 0;

	if ( m_pVertexList )
	{
		delete [] m_pVertexList;
		m_pVertexList = NULL;
	}

	m_nVertexWidthCnt = 65;
	m_nVertexCnt = 65 * 65;

	m_v3FieldEnd.x = m_v3FieldEnd.y = m_v3FieldEnd.z = -FLT_MAX;
	m_v3FieldBegin.x = m_v3FieldBegin.y = m_v3FieldBegin.z = FLT_MAX;

	m_fFieldSize = 256.f;
	m_fTileSize = 4.f;

	m_uiFieldID = 0xffffffff;
	m_pWorldProperty = NULL;

	CNaviToolObject::Delete();
}


void CNaviToolField::Render( RwCamera* pCamera, const RwMatrix* pParentMatrix )
{
	if ( !m_bCreated ) return;

	RwMatrix matWorld;

	if ( pParentMatrix )
	{
		RwMatrixCopy( &matWorld, pParentMatrix );
	}
	else
	{
		RwMatrixSetIdentity( &matWorld );
	}

	//////////////////////////////////////////////////////////////////////////
	//
	//	Culling
	//
	//////////////////////////////////////////////////////////////////////////

	RwV3d v3Begin, v3End;

	RwV3dTransformPoint( &v3Begin, &m_v3FieldBegin, &matWorld );
	RwV3dTransformPoint( &v3End, &m_v3FieldEnd, &matWorld );

	float fDistX = (v3End.x - v3Begin.x) / 2.f;
	float fDistY = (v3End.y - v3Begin.y) / 2.f;
	float fDistZ = (v3End.z - v3Begin.z) / 2.f;

	// Distance culling

	RwV3d v3Pos = RwFrameGetMatrix( RwCameraGetFrame( pCamera ) )->pos;
	float fDist = (v3Pos.x - (v3Begin.x + fDistX)) * (v3Pos.x - (v3Begin.x + fDistX)) +
				  (v3Pos.z - (v3Begin.z + fDistZ)) * (v3Pos.z - (v3Begin.z + fDistZ));

	if ( fDist > 500.f * 500.f )	// ���� �Ÿ��� 500M �̻��̸� ������ ���� �ʴ´�
	{
		return;
	}

	// Frustum culling

	RwSphere Sphere;
	Sphere.center.x = v3Begin.x + fDistX;
	Sphere.center.y = v3Begin.y + fDistY;
	Sphere.center.z = v3Begin.z + fDistZ;
	Sphere.radius = sqrtf( fDistX * fDistX + fDistY * fDistY + fDistZ * fDistZ );

	if ( rwSPHEREOUTSIDE == RwCameraFrustumTestSphere( pCamera, &Sphere ) )
	{
		return;
	}

	RwRenderStateSet( rwRENDERSTATETEXTURERASTER, NULL );
	RwRenderStateSet( rwRENDERSTATESRCBLEND, (void*)rwBLENDONE );
	RwRenderStateSet( rwRENDERSTATEDESTBLEND, (void*)rwBLENDZERO );
	RwRenderStateSet( rwRENDERSTATEFOGENABLE, (void*)FALSE );

	RwD3D9SetRenderState( D3DRS_LIGHTING, FALSE );

	if ( RwIm3DTransform( m_pVertexList, m_nVertexCnt, &matWorld, rwIM3D_VERTEXXYZ|rwIM3D_VERTEXRGBA ) )
	{
		RwIm3DRenderIndexedPrimitive( rwPRIMTYPETRILIST, m_pIndexList, m_nIndexCnt );

		RwIm3DEnd();
	}

	CNaviToolObject::Render( pCamera, &matWorld );
}